<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('admin');

$db = getDB();
$user = getCurrentUser();
$offices = $db->query("SELECT o.id, o.office_name, o.office_code, d.dept_name 
    FROM offices o 
    LEFT JOIN departments d ON o.department_id = d.id 
    WHERE o.is_active = 1 
    ORDER BY CASE WHEN o.office_code LIKE 'DEAN_%' THEN 1 ELSE 0 END, o.office_name");
$collegeDepts = $db->query("SELECT id, dept_name, dept_code FROM departments WHERE dept_type = 'college' AND is_active = 1 ORDER BY dept_name");
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Workflow - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
    .step-card { cursor: move; }
    .step-card:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    .step-number { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; font-weight: bold; }
    .sortable-ghost { opacity: 0.4; }
    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Administration</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="users.php"><i class="bi bi-people"></i><span> Users</span></a></li>
                <li class="nav-item"><a class="nav-link" href="departments.php"><i class="bi bi-building"></i><span> College Departments</span></a></li>
                <li class="nav-item"><a class="nav-link" href="offices.php"><i class="bi bi-door-open"></i><span> College Offices</span></a></li>
                <li class="nav-item"><a class="nav-link active" href="workflow.php"><i class="bi bi-diagram-3"></i><span> Workflow</span></a></li>
                <li class="nav-item"><a class="nav-link" href="clearance_periods.php"><i class="bi bi-calendar-event"></i><span> Periods</span></a></li>
                <li class="nav-item"><a class="nav-link" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link" href="settings.php"><i class="bi bi-toggles"></i><span> Settings</span></a></li>
                <li class="nav-item"><a class="nav-link" href="audit_logs.php"><i class="bi bi-journal-text"></i><span> Audit Logs</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Header -->
            <?php
            $pageTitle = 'Clearance Workflow';
            $pageIcon = 'bi-diagram-3';
            include __DIR__ . '/../includes/top_header.php';
            ?>

            <!-- Page Content -->
            <div class="page-content animate-fade-in-up">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0"><i class="bi bi-diagram-3 text-maroon me-1"></i> Clearance Workflow</h4>
                    <button class="btn btn-maroon" data-bs-toggle="modal" data-bs-target="#workflowModal" onclick="resetWorkflowForm()">
                        <i class="bi bi-plus-lg"></i> New Workflow
                    </button>
                </div>

                <div class="glass-card-static">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table id="workflowsTable" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Workflow Name</th>
                                        <th>Period</th>
                                        <th>Steps</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="glass-card-static mt-4" id="stepsCard" style="display:none;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="fw-bold" id="stepsTitle">Workflow Steps</span>
                            <button class="btn btn-gold btn-sm" data-bs-toggle="modal" data-bs-target="#stepModal" onclick="resetStepForm()">
                                <i class="bi bi-plus-lg"></i> Add Step
                            </button>
                        </div>
                        <div id="stepsContainer">
                            <div class="text-muted text-center py-4">Select a workflow to manage its steps</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile sidebar backdrop -->
    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <div class="modal fade" id="workflowModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="workflowModalTitle">New Workflow</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="workflowForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="create_workflow">
                        <input type="hidden" name="workflow_id" id="workflow_id">
                        <div class="mb-3">
                            <label class="form-label">Workflow Name</label>
                            <input type="text" class="form-control" name="workflow_name" id="workflow_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Clearance Period (optional)</label>
                            <select class="form-select" name="period_id" id="wf_period_id">
                                <option value="">None</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-maroon">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="stepModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="stepModalTitle">Add Step</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="stepForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="create_step">
                        <input type="hidden" name="step_id" id="step_id">
                        <input type="hidden" name="workflow_id" id="step_workflow_id" value="">
                        <div class="mb-3">
                            <label class="form-label">Office</label>
                            <select class="form-select" name="office_id" id="step_office_id" required>
                                <option value="">Select Office</option>
                                <optgroup label="Standard Offices">
                                <?php $offices->data_seek(0); while($office = $offices->fetch_assoc()):
                                    if (strpos($office['office_code'], 'DEAN_') !== 0): ?>
                                    <option value="<?= $office['id'] ?>"><?= htmlspecialchars($office['office_name']) ?></option>
                                <?php endif; endwhile; ?>
                                </optgroup>
                                <optgroup label="Dynamic Routing">
                                <option value="0" class="dean-college-option">Deans College Department (Auto-routes by employee's college)</option>
                                </optgroup>
                            </select>
                            <small class="text-muted">Select "Deans College Department" to automatically route to the Dean of the employee's college department.</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Order</label>
                            <input type="number" class="form-control" name="step_order" id="step_order" min="1" required>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" name="is_mandatory" id="step_mandatory" value="1" checked>
                            <label class="form-check-label" for="step_mandatory">Mandatory Step</label>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" name="is_dynamic" id="step_dynamic" value="1">
                            <label class="form-check-label" for="step_dynamic">Dynamic (e.g., Dean assignment)</label>
                        </div>
                        <div class="mb-3" id="dynamicFieldDiv" style="display:none;">
                            <label class="form-label">Dynamic Field</label>
                            <input type="text" class="form-control" name="dynamic_field" id="dynamic_field" placeholder="e.g., department_id">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-maroon">Save Step</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
    <script>
    var currentWorkflowId = null;

    $(document).ready(function() {
        loadPeriods();

        var table = $('#workflowsTable').DataTable({
            ajax: { url: 'users_ajax.php', data: { action: 'list_workflows' } },
            columns: [
                { data: 'id' },
                { data: 'workflow_name' },
                { data: 'period_name' },
                { data: 'step_count' },
                { data: 'status' },
                { data: 'actions', orderable: false }
            ],
            order: [[0, 'desc']],
            pageLength: 25
        });

        $('#workflowForm').on('submit', function(e) {
            e.preventDefault();
            $.ajax({
                url: 'users_ajax.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        $('#workflowModal').modal('hide');
                        table.ajax.reload();
                        showToast('success', res.message);
                    } else {
                        showToast('danger', res.message);
                    }
                }
            });
        });

        $('#stepForm').on('submit', function(e) {
            e.preventDefault();
            $.ajax({
                url: 'users_ajax.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        $('#stepModal').modal('hide');
                        loadSteps(currentWorkflowId);
                        showToast('success', res.message);
                    } else {
                        showToast('danger', res.message);
                    }
                }
            });
        });

        $('#step_dynamic').on('change', function() {
            $('#dynamicFieldDiv').toggle(this.checked);
        });

        $('#step_office_id').on('change', function() {
            var opt = $(this).find('option:selected');
            var val = $(this).val();
            var isDeanCollege = opt.hasClass('dean-college-option') || val === '' || val === null;
            if (isDeanCollege) {
                $('#step_dynamic').prop('checked', true).trigger('change');
                $('#dynamic_field').val('department_id');
            } else if (!isDeanCollege && $('#dynamic_field').val() === 'department_id') {
                $('#step_dynamic').prop('checked', false).trigger('change');
                $('#dynamic_field').val('');
            }
        });

        $('#step_office_id').trigger('change');

    });

    function loadPeriods() {
        $.ajax({
            url: 'users_ajax.php',
            data: { action: 'list_periods_select' },
            dataType: 'json',
            success: function(res) {
                var sel = $('#wf_period_id');
                sel.find('option:not(:first)').remove();
                if (res.data) {
                    res.data.forEach(function(p) {
                        sel.append('<option value="' + p.id + '">' + p.period_name + '</option>');
                    });
                }
            }
        });
    }

    function loadSteps(workflowId) {
        currentWorkflowId = workflowId;
        if (!workflowId) {
            $('#stepsCard').hide();
            return;
        }
        $('#stepsCard').show();
        $('#step_workflow_id').val(workflowId);
        $.ajax({
            url: 'users_ajax.php',
            data: { action: 'list_steps', workflow_id: workflowId },
            dataType: 'json',
            success: function(res) {
                var container = $('#stepsContainer');
                var html = '';
                if (res.data && res.data.length > 0) {
                    var sorted = res.data.sort(function(a, b) { return a.step_order - b.step_order; });
                    sorted.forEach(function(step) {
                        html += '<div class="card step-card mb-2 border" data-step-id="' + step.id + '">';
                        html += '<div class="card-body py-2 d-flex align-items-center justify-content-between">';
                        html += '<div class="d-flex align-items-center">';
                        html += '<span class="step-number bg-maroon-gradient text-white rounded-circle me-3">' + step.step_order + '</span>';
                        html += '<div><strong>' + step.office_name + '</strong>';
                        html += '<br><small>' + (step.is_mandatory ? '<span class="badge bg-success me-1">Mandatory</span>' : '<span class="badge bg-secondary me-1">Optional</span>');
                        if (step.is_dynamic) html += '<span class="badge bg-info">Dynamic: ' + (step.dynamic_field || '') + '</span>';
                        html += '</small></div></div>';
                        html += '<div>';
                        html += '<button class="btn btn-sm btn-outline-maroon me-1" onclick="editStep(' + step.id + ')"><i class="bi bi-pencil"></i></button>';
                        html += '<button class="btn btn-sm btn-outline-gold" onclick="deleteStep(' + step.id + ')"><i class="bi bi-trash"></i></button>';
                        html += '</div></div></div>';
                    });
                } else {
                    html = '<div class="text-muted text-center py-4">No steps defined yet. Click "Add Step" to begin.</div>';
                }
                container.html(html);
                initSortable();
            }
        });
    }

    function initSortable() {
        var container = document.getElementById('stepsContainer');
        Sortable.create(container, {
            handle: '.step-card',
            animation: 150,
            ghostClass: 'sortable-ghost',
            onEnd: function(evt) {
                var stepIds = [];
                container.querySelectorAll('.step-card').forEach(function(card) {
                    stepIds.push($(card).data('step-id'));
                });
                $.ajax({
                    url: 'users_ajax.php',
                    type: 'POST',
                    data: { action: 'reorder_steps', workflow_id: currentWorkflowId, step_ids: stepIds },
                    dataType: 'json',
                    success: function(res) {
                        if (res.success) {
                            loadSteps(currentWorkflowId);
                            showToast('success', 'Steps reordered');
                        }
                    }
                });
            }
        });
    }

    function resetWorkflowForm() {
        $('#workflowForm')[0].reset();
        $('#workflow_id').val('');
        $('#workflowModalTitle').text('New Workflow');
        $('[name="action"]').val('create_workflow');
        $('#stepsCard').hide();
    }

    function editWorkflow(id) {
        $.ajax({
            url: 'users_ajax.php',
            data: { action: 'get_workflow', workflow_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    var w = res.data;
                    $('#workflow_id').val(w.id);
                    $('#workflow_name').val(w.workflow_name);
                    $('#wf_period_id').val(w.period_id || '');
                    $('#workflowModalTitle').text('Edit Workflow');
                    $('[name="action"]').val('update_workflow');
                    $('#workflowModal').modal('show');
                }
            }
        });
    }

    function toggleWorkflow(id) {
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'toggle_workflow', workflow_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#workflowsTable').DataTable().ajax.reload();
                    showToast('success', res.message);
                }
            }
        });
    }

    function deleteWorkflow(id) {
        if (!confirm('Delete this workflow and all its steps?')) return;
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'delete_workflow', workflow_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#workflowsTable').DataTable().ajax.reload();
                    if (currentWorkflowId === id) { $('#stepsCard').hide(); currentWorkflowId = null; }
                    showToast('success', res.message);
                }
            }
        });
    }

    function manageSteps(id, name) {
        $('#stepsTitle').text('Steps: ' + name);
        loadSteps(id);
    }

    function resetStepForm() {
        if (!currentWorkflowId) { showToast('warning', 'Select a workflow first'); return; }
        $('#stepForm')[0].reset();
        $('#step_id').val('');
        $('#step_order').val('');
        $('#stepModalTitle').text('Add Step');
        $('[name="action"]').val('create_step');
    }

    function editStep(id) {
        $.ajax({
            url: 'users_ajax.php',
            data: { action: 'get_step', step_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    var s = res.data;
                    $('#step_id').val(s.id);
                    $('#step_workflow_id').val(s.workflow_id);
                    $('#step_office_id').val(s.office_id);
                    $('#step_order').val(s.step_order);
                    $('#step_mandatory').prop('checked', s.is_mandatory == 1);
                    $('#step_dynamic').prop('checked', s.is_dynamic == 1).trigger('change');
                    $('#dynamic_field').val(s.dynamic_field || '');
                    $('#stepModalTitle').text('Edit Step');
                    $('[name="action"]').val('update_step');
                    $('#stepModal').modal('show');
                }
            }
        });
    }

    function deleteStep(id) {
        if (!confirm('Remove this step?')) return;
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'delete_step', step_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    loadSteps(currentWorkflowId);
                    showToast('success', res.message);
                }
            }
        });
    }

    function showToast(type, message) {
        var bg = type === 'success' ? 'bg-success' : (type === 'warning' ? 'bg-warning' : 'bg-danger');
        var toast = '<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div class="toast align-items-center text-white ' + bg + ' border-0 show" role="alert"><div class="d-flex"><div class="toast-body">' + message + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>';
        $('body').append(toast);
        setTimeout(function() { $(toast).remove(); }, 3000);
    }
    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
