<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('admin');

$db = getDB();
$user = getCurrentUser();
require_once __DIR__ . '/../includes/header.php';

$depts = $db->query("SELECT id, dept_name, dept_code FROM departments ORDER BY dept_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clearance Monitoring - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Administration</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="users.php"><i class="bi bi-people"></i><span> Users</span></a></li>
                <li class="nav-item"><a class="nav-link" href="departments.php"><i class="bi bi-building"></i><span> College Departments</span></a></li>
                <li class="nav-item"><a class="nav-link" href="offices.php"><i class="bi bi-door-open"></i><span> College Offices</span></a></li>
                <li class="nav-item"><a class="nav-link" href="workflow.php"><i class="bi bi-diagram-3"></i><span> Workflow</span></a></li>
                <li class="nav-item"><a class="nav-link" href="clearance_periods.php"><i class="bi bi-calendar-event"></i><span> Periods</span></a></li>
                <li class="nav-item"><a class="nav-link active" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link" href="settings.php"><i class="bi bi-toggles"></i><span> Settings</span></a></li>
                <li class="nav-item"><a class="nav-link" href="audit_logs.php"><i class="bi bi-journal-text"></i><span> Audit Logs</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Header -->
            <?php
            $pageTitle = 'Monitoring';
            $pageIcon = 'bi-bar-chart-steps';
            include __DIR__ . '/../includes/top_header.php';
            ?>

            <!-- Page Content -->
            <div class="page-content animate-fade-in-up">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0"><i class="bi bi-bar-chart-steps text-maroon me-1"></i> Clearance Monitoring</h4>
                    <button class="btn btn-outline-maroon" onclick="location.reload()"><i class="bi bi-arrow-clockwise"></i> Refresh</button>
                </div>

                <div class="row g-3 mb-4 stagger-children" id="statsCards">
                    <div class="col-md-3 col-6">
                        <div class="stat-card bg-maroon-gradient text-white">
                            <div class="stat-icon bg-white bg-opacity-25"><i class="bi bi-people"></i></div>
                            <div class="stat-value" id="statTotal">0</div>
                            <div class="stat-label text-white-50">Total Employees</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stat-card" style="background: linear-gradient(135deg, #1565C0, #1976D2); color: white;">
                            <div class="stat-icon bg-white bg-opacity-25"><i class="bi bi-file-check"></i></div>
                            <div class="stat-value" id="statActive">0</div>
                            <div class="stat-label text-white-50">With Clearance</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stat-card" style="background: linear-gradient(135deg, #F9A825, #FBC02D); color: #333;">
                            <div class="stat-icon bg-white bg-opacity-25"><i class="bi bi-hourglass"></i></div>
                            <div class="stat-value" id="statInProgress">0</div>
                            <div class="stat-label text-dark-50">In Progress</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stat-card" style="background: linear-gradient(135deg, #2E7D32, #388E3C); color: white;">
                            <div class="stat-icon bg-white bg-opacity-25"><i class="bi bi-check-circle"></i></div>
                            <div class="stat-value" id="statCompleted">0</div>
                            <div class="stat-label text-white-50">Completed</div>
                        </div>
                    </div>
                </div>

                <div class="glass-card-static">
                    <div class="card-body p-0">
                        <div class="p-3 border-bottom">
                            <div class="row g-2 align-items-center">
                                <div class="col-md-4">
                                    <select class="form-select form-select-sm" id="filterDept">
                                        <option value="">All Departments</option>
                                        <?php while ($d = $depts->fetch_assoc()): ?>
                                        <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['dept_name']) ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-select form-select-sm" id="filterType">
                                        <option value="">All Employee Types</option>
                                        <option value="regular_instructor">Regular Instructor</option>
                                        <option value="visiting_lecturer">Visiting Lecturer</option>
                                        <option value="non_teaching">Non-Teaching Staff</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-select form-select-sm" id="filterStatus">
                                        <option value="">All Statuses</option>
                                        <option value="in_progress">In Progress</option>
                                        <option value="completed">Completed</option>
                                        <option value="pending">Pending</option>
                                        <option value="rejected">Rejected</option>
                                        <option value="revoked">Revoked</option>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <button class="btn btn-sm btn-outline-maroon w-100" id="applyFilters"><i class="bi bi-funnel"></i> Filter</button>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0" id="monitoringTable" style="font-size:0.85rem;">
                                <thead>
                                    <tr>
                                        <th>Employee</th>
                                        <th>ID</th>
                                        <th>Type</th>
                                        <th>Department</th>
                                        <th>Clearance</th>
                                        <th>Status</th>
                                        <th>Progress</th>
                                        <th>Current Office</th>
                                        <th>Submitted</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile sidebar backdrop -->
    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
    var table;
    $(document).ready(function() {
        loadStats();
        table = $('#monitoringTable').DataTable({
            processing: true,
            serverSide: false,
            ajax: {
                url: 'monitoring_ajax.php',
                data: function(d) {
                    d.action = 'list_all';
                    d.dept_id = $('#filterDept').val();
                    d.employee_type = $('#filterType').val();
                    d.status = $('#filterStatus').val();
                }
            },
            columns: [
                { data: 'employee_name' },
                { data: 'employee_id' },
                { data: 'employee_type' },
                { data: 'department' },
                { data: 'clearance_code' },
                { data: 'status' },
                { data: 'progress' },
                { data: 'current_office' },
                { data: 'submitted' },
                { data: 'actions', orderable: false }
            ],
            order: [[3, 'asc'], [0, 'asc']],
            pageLength: 25,
            language: { search: 'Search employees:' }
        });

        $('#applyFilters').on('click', function() {
            loadStats();
            table.ajax.reload();
        });

        $('#monitoringTable').on('draw.dt', function() {
            updateAutoRefresh();
        });

    });

    function loadStats() {
        $.get('monitoring_ajax.php', {
            action: 'stats',
            dept_id: $('#filterDept').val()
        }, function(res) {
            if (res.success) {
                $('#statTotal').text(res.total_employees);
                $('#statActive').text(res.with_clearance);
                $('#statInProgress').text(res.in_progress);
                $('#statCompleted').text(res.completed);
            }
        });
    }

    var refreshTimer;
    function updateAutoRefresh() {
        clearTimeout(refreshTimer);
        refreshTimer = setTimeout(function() {
            loadStats();
            table.ajax.reload(null, false);
        }, 15000);
    }
    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
