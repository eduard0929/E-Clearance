<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/dean_office.php';
requireLogin();
requireRole('admin');
header('Content-Type: application/json');

$db = getDB();
$action = $_REQUEST['action'] ?? '';

if ($action === 'list') {
    $users = $db->query("
        SELECT u.*, r.role_name 
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        ORDER BY u.created_at DESC
    ");
    $data = [];
    while ($row = $users->fetch_assoc()) {
        $actions = '
            <button class="btn btn-sm btn-outline-primary" onclick="editUser(' . $row['id'] . ')"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-outline-warning" onclick="toggleStatus(' . $row['id'] . ')"><i class="bi bi-' . ($row['is_active'] ? 'pause' : 'play') . '"></i></button>
            <button class="btn btn-sm btn-outline-danger" onclick="deleteUser(' . $row['id'] . ')"><i class="bi bi-trash"></i></button>
        ';
        $fullName = htmlspecialchars($row['first_name'] . ($row['middle_name'] ? ' ' . $row['middle_name'] . ' ' : ' ') . $row['last_name']);
        if (!empty($row['profile_image'])) {
            $avatarUrl = assetUrl($row['profile_image']);
            $avatarHtml = '<img src="' . htmlspecialchars($avatarUrl) . '" alt="Avatar" class="rounded-circle me-2" style="width: 28px; height: 28px; object-fit: cover;">';
        } else {
            $initials = strtoupper(substr($row['first_name'],0,1)) . strtoupper(substr($row['last_name'],0,1));
            $avatarHtml = '<span class="d-inline-flex align-items-center justify-content-center rounded-circle me-2 bg-secondary text-white fw-bold text-center" style="width: 28px; height: 28px; font-size: 0.75rem; vertical-align: middle;">' . htmlspecialchars($initials) . '</span>';
        }
        $fullNameWithAvatar = '<div class="d-flex align-items-center">' . $avatarHtml . '<span>' . $fullName . '</span></div>';

        $data[] = [
            'id' => $row['id'],
            'username' => htmlspecialchars($row['username']),
            'full_name' => $fullNameWithAvatar,
            'email' => htmlspecialchars($row['email'] ?? ''),
            'gmail_address' => htmlspecialchars($row['gmail_address'] ?? ''),
            'role_name' => ucfirst($row['role_name']),
            'status' => $row['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>',
            'last_login' => $row['last_login'] ? formatDate($row['last_login']) : 'Never',
            'actions' => $actions
        ];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'get') {
    $userId = (int)($_REQUEST['user_id'] ?? 0);
    $stmt = $db->prepare("
        SELECT u.*, r.role_name, sp.office_id, sp.designation, sp.department_id,
               o.office_name, o.office_code, o.department_id AS office_dept_id,
               e.id as emp_id, e.department_id as employee_dept_id, e.employee_id as emp_code, e.position_title, e.employee_type
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        LEFT JOIN signatory_profiles sp ON sp.user_id = u.id
        LEFT JOIN offices o ON sp.office_id = o.id
        LEFT JOIN employees e ON e.user_id = u.id
        WHERE u.id = ?
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    if ($user) {
        $user['is_dean_college'] = isDeanCollegeOffice($user['office_name'] ?? null, $user['office_code'] ?? null);
        if ($user['is_dean_college'] && empty($user['department_id']) && !empty($user['office_dept_id'])) {
            $user['department_id'] = $user['office_dept_id'];
        }
        echo json_encode(['success' => true, 'data' => $user]);
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
    exit;
}

if ($action === 'create') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $firstName = trim($_POST['first_name'] ?? '');
    $middleName = trim($_POST['middle_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $gmail = trim($_POST['gmail_address'] ?? '');
    $roleId = (int)($_POST['role_id'] ?? 0);

    if (empty($username) || empty($password) || empty($firstName) || empty($lastName) || empty($roleId)) {
        echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
        exit;
    }

    $check = $db->prepare("SELECT id FROM users WHERE username = ?");
    $check->bind_param("s", $username);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Username already exists']);
        exit;
    }

    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO users (username, password, first_name, middle_name, last_name, email, gmail_address, role_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssi", $username, $hashed, $firstName, $middleName, $lastName, $email, $gmail, $roleId);
    if ($stmt->execute()) {
        $userId = $db->insert_id;

        $roleStmt = $db->prepare("SELECT role_name FROM roles WHERE id = ?");
        $roleStmt->bind_param("i", $roleId);
        $roleStmt->execute();
        $roleName = $roleStmt->get_result()->fetch_assoc()['role_name'];

        if ($roleName === 'signatory') {
            $officeId = (int)($_POST['office_id'] ?? 0);
            $designation = trim($_POST['designation'] ?? '');
            $deptId = !empty($_POST['dean_department_id']) ? (int)$_POST['dean_department_id'] : null;
            $officeId = resolveSignatoryOfficeId($db, $officeId, $deptId);
            if ($deptId && !$officeId) {
                echo json_encode(['success' => false, 'message' => 'Could not assign dean office for the selected college department']);
                exit;
            }
            if ($officeId) {
                $sp = $db->prepare("INSERT INTO signatory_profiles (user_id, office_id, designation, department_id) VALUES (?, ?, ?, ?)");
                $sp->bind_param("iisi", $userId, $officeId, $designation, $deptId);
                $sp->execute();
            }
        } elseif ($roleName === 'employee') {
            $deptId = !empty($_POST['employee_dept_id']) ? (int)$_POST['employee_dept_id'] : null;
            $empId = trim($_POST['employee_id'] ?? '');
            $position = trim($_POST['position_title'] ?? '');
            $empType = $_POST['employee_type'] ?? 'regular_instructor';
            
            if ($deptId) {
                $deptCheckStmt = $db->prepare("SELECT id FROM departments WHERE id = ?");
                $deptCheckStmt->bind_param("i", $deptId);
                $deptCheckStmt->execute();
                $deptCheck = $deptCheckStmt->get_result();
                if (!$deptCheck || $deptCheck->num_rows === 0) {
                    echo json_encode(['success' => false, 'message' => 'Selected department does not exist']);
                    exit;
                }
            }
            
            if ($empId) {
                $empCheckStmt = $db->prepare("SELECT id FROM employees WHERE employee_id = ?");
                $empCheckStmt->bind_param("s", $empId);
                $empCheckStmt->execute();
                $empCheck = $empCheckStmt->get_result();
                if ($empCheck && $empCheck->num_rows > 0) {
                    echo json_encode(['success' => false, 'message' => 'Employee ID already exists']);
                    exit;
                }
            }
            
            $empStmt = $db->prepare("INSERT INTO employees (user_id, employee_id, department_id, position_title, employee_type) VALUES (?, ?, ?, ?, ?)");
            $empStmt->bind_param("isiss", $userId, $empId, $deptId, $position, $empType);
            if (!$empStmt->execute()) {
                echo json_encode(['success' => false, 'message' => 'Failed to create employee record: ' . $empStmt->error]);
                exit;
            }
        }

        logAudit('create', 'users', "Created user: $username ($roleName)");
        echo json_encode(['success' => true, 'message' => 'User created successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create user']);
    }
    exit;
}

if ($action === 'update') {
    $userId = (int)($_POST['user_id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $firstName = trim($_POST['first_name'] ?? '');
    $middleName = trim($_POST['middle_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $gmail = trim($_POST['gmail_address'] ?? '');
    $roleId = (int)($_POST['role_id'] ?? 0);

    if (empty($username) || empty($firstName) || empty($lastName) || empty($roleId)) {
        echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
        exit;
    }

    $check = $db->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
    $check->bind_param("si", $username, $userId);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Username already exists']);
        exit;
    }

    if (!empty($password)) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE users SET username=?, password=?, first_name=?, middle_name=?, last_name=?, email=?, gmail_address=?, role_id=? WHERE id=?");
        $stmt->bind_param("sssssssii", $username, $hashed, $firstName, $middleName, $lastName, $email, $gmail, $roleId, $userId);
    } else {
        $stmt = $db->prepare("UPDATE users SET username=?, first_name=?, middle_name=?, last_name=?, email=?, gmail_address=?, role_id=? WHERE id=?");
        $stmt->bind_param("ssssssii", $username, $firstName, $middleName, $lastName, $email, $gmail, $roleId, $userId);
    }

    if ($stmt->execute()) {
        $roleStmt = $db->prepare("SELECT role_name FROM roles WHERE id = ?");
        $roleStmt->bind_param("i", $roleId);
        $roleStmt->execute();
        $roleName = $roleStmt->get_result()->fetch_assoc()['role_name'];

        if ($roleName === 'signatory') {
            $officeId = (int)($_POST['office_id'] ?? 0);
            $designation = trim($_POST['designation'] ?? '');
            $deptId = !empty($_POST['dean_department_id']) ? (int)$_POST['dean_department_id'] : null;
            $officeId = resolveSignatoryOfficeId($db, $officeId, $deptId);
            if ($deptId && !$officeId) {
                echo json_encode(['success' => false, 'message' => 'Could not assign dean office for the selected college department']);
                exit;
            }
            $existingStmt = $db->prepare("SELECT id FROM signatory_profiles WHERE user_id = ?");
            $existingStmt->bind_param("i", $userId);
            $existingStmt->execute();
            $existing = $existingStmt->get_result();
            if ($existing->num_rows > 0) {
                $sp = $db->prepare("UPDATE signatory_profiles SET office_id=?, designation=?, department_id=? WHERE user_id=?");
                $sp->bind_param("isii", $officeId, $designation, $deptId, $userId);
                $sp->execute();
            } elseif ($officeId) {
                $sp = $db->prepare("INSERT INTO signatory_profiles (user_id, office_id, designation, department_id) VALUES (?, ?, ?, ?)");
                $sp->bind_param("iisi", $userId, $officeId, $designation, $deptId);
                $sp->execute();
            }
        } elseif ($roleName === 'employee') {
            $deptId = !empty($_POST['employee_dept_id']) ? (int)$_POST['employee_dept_id'] : null;
            $empId = trim($_POST['employee_id'] ?? '');
            $position = trim($_POST['position_title'] ?? '');
            $empType = $_POST['employee_type'] ?? 'regular_instructor';
            
            if ($deptId) {
                $deptCheckStmt = $db->prepare("SELECT id FROM departments WHERE id = ?");
                $deptCheckStmt->bind_param("i", $deptId);
                $deptCheckStmt->execute();
                $deptCheck = $deptCheckStmt->get_result();
                if (!$deptCheck || $deptCheck->num_rows === 0) {
                    echo json_encode(['success' => false, 'message' => 'Selected department does not exist']);
                    exit;
                }
            }
            
            if ($empId) {
                $empCheckStmt = $db->prepare("SELECT id FROM employees WHERE employee_id = ? AND user_id != ?");
                $empCheckStmt->bind_param("si", $empId, $userId);
                $empCheckStmt->execute();
                $empCheck = $empCheckStmt->get_result();
                if ($empCheck && $empCheck->num_rows > 0) {
                    echo json_encode(['success' => false, 'message' => 'Employee ID already exists']);
                    exit;
                }
            }
            
            $existingEmpStmt = $db->prepare("SELECT id FROM employees WHERE user_id = ?");
            $existingEmpStmt->bind_param("i", $userId);
            $existingEmpStmt->execute();
            $existingEmp = $existingEmpStmt->get_result();
            if ($existingEmp->num_rows > 0) {
                $empStmt = $db->prepare("UPDATE employees SET employee_id=?, department_id=?, position_title=?, employee_type=? WHERE user_id=?");
                $empStmt->bind_param("sisis", $empId, $deptId, $position, $empType, $userId);
            } else {
                $empStmt = $db->prepare("INSERT INTO employees (user_id, employee_id, department_id, position_title, employee_type) VALUES (?, ?, ?, ?, ?)");
                $empStmt->bind_param("isiss", $userId, $empId, $deptId, $position, $empType);
            }
            if (!$empStmt->execute()) {
                echo json_encode(['success' => false, 'message' => 'Failed to update employee record: ' . $empStmt->error]);
                exit;
            }
        } else {
            $delSp = $db->prepare("DELETE FROM signatory_profiles WHERE user_id = ?");
            $delSp->bind_param("i", $userId);
            $delSp->execute();
            $delEmp = $db->prepare("DELETE FROM employees WHERE user_id = ?");
            $delEmp->bind_param("i", $userId);
            $delEmp->execute();
        }

        logAudit('update', 'users', "Updated user: $username");
        echo json_encode(['success' => true, 'message' => 'User updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update user']);
    }
    exit;
}

if ($action === 'toggle_status') {
    $userId = (int)($_POST['user_id'] ?? 0);
    $currentStmt = $db->prepare("SELECT is_active, username FROM users WHERE id = ?");
    $currentStmt->bind_param("i", $userId);
    $currentStmt->execute();
    $current = $currentStmt->get_result()->fetch_assoc();
    if (!$current) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    $newStatus = $current['is_active'] ? 0 : 1;
    $stmt = $db->prepare("UPDATE users SET is_active = ? WHERE id = ?");
    $stmt->bind_param("ii", $newStatus, $userId);
    if ($stmt->execute()) {
        $action = $newStatus ? 'activated' : 'deactivated';
        logAudit('update', 'users', "{$action} user: {$current['username']}");
        echo json_encode(['success' => true, 'message' => 'User ' . ($newStatus ? 'activated' : 'deactivated') . ' successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to toggle user status']);
    }
    exit;
}

if ($action === 'delete') {
    $userId = (int)($_POST['user_id'] ?? 0);
    $userStmt = $db->prepare("SELECT username FROM users WHERE id = ?");
    $userStmt->bind_param("i", $userId);
    $userStmt->execute();
    $user = $userStmt->get_result()->fetch_assoc();
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    if ($stmt->execute()) {
        logAudit('delete', 'users', "Deleted user: {$user['username']}");
        echo json_encode(['success' => true, 'message' => 'User deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete user']);
    }
    exit;
}

// === DEPARTMENT CRUD ===
if ($action === 'list_depts') {
    $result = $db->query("SELECT * FROM departments ORDER BY created_at DESC");
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $actions = '
            <button class="btn btn-sm btn-outline-primary" onclick="editDept(' . $row['id'] . ')"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-outline-warning" onclick="toggleDept(' . $row['id'] . ')"><i class="bi bi-' . ($row['is_active'] ? 'pause' : 'play') . '"></i></button>
            <button class="btn btn-sm btn-outline-danger" onclick="deleteDept(' . $row['id'] . ')"><i class="bi bi-trash"></i></button>
        ';
        $data[] = [
            'id' => $row['id'],
            'dept_name' => htmlspecialchars($row['dept_name']),
            'dept_code' => htmlspecialchars($row['dept_code'] ?? ''),
            'dept_type' => ucfirst($row['dept_type']),
            'status' => $row['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>',
            'actions' => $actions
        ];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'list_college_depts') {
    $result = $db->query("SELECT * FROM departments WHERE dept_type = 'college' ORDER BY dept_name ASC");
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $actions = '
            <button class="btn btn-sm btn-outline-primary" onclick="editDept(' . $row['id'] . ')"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-outline-warning" onclick="toggleDept(' . $row['id'] . ')"><i class="bi bi-' . ($row['is_active'] ? 'pause' : 'play') . '"></i></button>
            <button class="btn btn-sm btn-outline-danger" onclick="deleteDept(' . $row['id'] . ')"><i class="bi bi-trash"></i></button>
        ';
        $deptName = htmlspecialchars($row['dept_name']);
        $deptCode = $row['dept_code'] ?? '';
        $prefix = getDeanOfficePrefix($row['dept_name'], $row['dept_code'] ?? '');
        $data[] = [
            'id' => $row['id'],
            'dept_name' => $deptName . '<br><small class="text-muted">' . $prefix . ', ' . $deptName . '</small>',
            'dept_code' => htmlspecialchars($row['dept_code'] ?? ''),
            'status' => $row['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>',
            'actions' => $actions
        ];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'get_dept') {
    $id = (int)($_REQUEST['dept_id'] ?? 0);
    $stmt = $db->prepare("SELECT * FROM departments WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    echo json_encode($row ? ['success' => true, 'data' => $row] : ['success' => false, 'message' => 'Not found']);
    exit;
}

if ($action === 'create_dept') {
    $name = trim($_POST['dept_name'] ?? '');
    $code = trim($_POST['dept_code'] ?? '');
    $type = $_POST['dept_type'] ?? 'college';
    if (empty($name)) { echo json_encode(['success' => false, 'message' => 'Name is required']); exit; }
    $db->begin_transaction();
    try {
        $stmt = $db->prepare("INSERT INTO departments (dept_name, dept_code, dept_type) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $code, $type);
        $stmt->execute();
        $deptId = $db->insert_id;
        $prefix = getDeanOfficePrefix($name, $code);
        $officeName = $prefix . ', ' . $name;
        $isDeanType = !in_array($prefix, ['Director', 'Principal', 'OIC-Dean'], true);
        $officeCode = $isDeanType ? 'DEAN_' . ($code ?: strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $name), 0, 6))) : strtoupper($code ?: substr(preg_replace('/[^a-zA-Z0-9]/', '', $name), 0, 6)) . '_HEAD';
        $offStmt = $db->prepare("INSERT IGNORE INTO offices (office_name, office_code, department_id) VALUES (?, ?, ?)");
        $offStmt->bind_param("ssi", $officeName, $officeCode, $deptId);
        $offStmt->execute();
        $db->commit();
        logAudit('create', 'departments', "Created department: $name with Dean office: $officeName");
        echo json_encode(['success' => true, 'message' => 'College department and Dean office created']);
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to create: ' . $e->getMessage()]);
    }
    exit;
}

if ($action === 'update_dept') {
    $id = (int)($_POST['dept_id'] ?? 0);
    $name = trim($_POST['dept_name'] ?? '');
    $code = trim($_POST['dept_code'] ?? '');
    $type = $_POST['dept_type'] ?? 'college';
    if (empty($name)) { echo json_encode(['success' => false, 'message' => 'Name is required']); exit; }
    $db->begin_transaction();
    try {
        $stmt = $db->prepare("UPDATE departments SET dept_name=?, dept_code=?, dept_type=? WHERE id=?");
        $stmt->bind_param("sssi", $name, $code, $type, $id);
        $stmt->execute();
        if ($type === 'college') {
            $prefix = getDeanOfficePrefix($name, $code);
            $officeName = $prefix . ', ' . $name;
            $isDeanType = !in_array($prefix, ['Director', 'Principal', 'OIC-Dean'], true);
            $officeCode = $isDeanType ? 'DEAN_' . ($code ?: strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $name), 0, 6))) : strtoupper($code ?: substr(preg_replace('/[^a-zA-Z0-9]/', '', $name), 0, 6)) . '_HEAD';
            $offStmt = $db->prepare("UPDATE offices SET office_name=?, office_code=? WHERE department_id=? AND office_code LIKE 'DEAN_%'");
            $offStmt->bind_param("ssi", $officeName, $officeCode, $id);
            $offStmt->execute();
            if ($offStmt->affected_rows === 0) {
                $offStmt2 = $db->prepare("INSERT IGNORE INTO offices (office_name, office_code, department_id) VALUES (?, ?, ?)");
                $offStmt2->bind_param("ssi", $officeName, $officeCode, $id);
                $offStmt2->execute();
            }
        }
        $db->commit();
        logAudit('update', 'departments', "Updated department: $name");
        echo json_encode(['success' => true, 'message' => 'College department and Dean office updated']);
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to update']);
    }
    exit;
}

if ($action === 'toggle_dept') {
    $id = (int)($_POST['dept_id'] ?? 0);
    $currentStmt = $db->prepare("SELECT is_active, dept_type FROM departments WHERE id = ?");
    $currentStmt->bind_param("i", $id);
    $currentStmt->execute();
    $current = $currentStmt->get_result()->fetch_assoc();
    if (!$current) { echo json_encode(['success' => false, 'message' => 'Not found']); exit; }
    $new = $current['is_active'] ? 0 : 1;
    $updateStmt = $db->prepare("UPDATE departments SET is_active = ? WHERE id = ?");
    $updateStmt->bind_param("ii", $new, $id);
    $updateStmt->execute();
    if ($current['dept_type'] === 'college') {
        $offStmt = $db->prepare("UPDATE offices SET is_active = ? WHERE department_id = ? AND office_code LIKE 'DEAN_%'");
        $offStmt->bind_param("ii", $new, $id);
        $offStmt->execute();
    }
    logAudit('update', 'departments', 'Toggled department status');
    echo json_encode(['success' => true, 'message' => 'Status updated']);
    exit;
}

if ($action === 'delete_dept') {
    $id = (int)($_POST['dept_id'] ?? 0);
    $db->begin_transaction();
    try {
        $offStmt = $db->prepare("DELETE FROM offices WHERE department_id = ? AND office_code LIKE 'DEAN_%'");
        $offStmt->bind_param("i", $id);
        $offStmt->execute();
        $stmt = $db->prepare("DELETE FROM departments WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $db->commit();
        logAudit('delete', 'departments', "Deleted department ID: $id and its Dean office");
        echo json_encode(['success' => true, 'message' => 'Department and Dean office deleted']);
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to delete']);
    }
    exit;
}

// === OFFICE CRUD ===
if ($action === 'list_offices') {
    $result = $db->query("SELECT o.*, d.dept_name FROM offices o LEFT JOIN departments d ON o.department_id = d.id ORDER BY o.created_at DESC");
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $actions = '
            <button class="btn btn-sm btn-outline-primary" onclick="editOffice(' . $row['id'] . ')"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-outline-warning" onclick="toggleOffice(' . $row['id'] . ')"><i class="bi bi-' . ($row['is_active'] ? 'pause' : 'play') . '"></i></button>
            <button class="btn btn-sm btn-outline-danger" onclick="deleteOffice(' . $row['id'] . ')"><i class="bi bi-trash"></i></button>
        ';
        $oname = $row['office_name'];
        if (stripos($oname, 'Registrar') !== false) $group = 'Student Records/Grades';
        elseif (stripos($oname, 'Cashier') !== false || stripos($oname, 'Accountant') !== false) $group = 'Financial';
        elseif (stripos($oname, 'Library') !== false || stripos($oname, 'Learning Commons') !== false) $group = 'Library';
        elseif (stripos($oname, 'Supply') !== false || stripos($oname, 'Property') !== false) $group = 'Property';
        elseif (stripos($oname, 'Administrative') !== false || $oname === 'Chief Administrative Officer') $group = 'Administrative';
        elseif (stripos($oname, 'VP for Admin') !== false) $group = 'Administrative';
        elseif (stripos($oname, 'VP for Academic') !== false || stripos($oname, 'VP for Research') !== false || stripos($oname, 'Legal') !== false || stripos($oname, 'VP for Student') !== false) $group = 'Recommending Approval';
        elseif (stripos($oname, 'President') !== false) $group = 'Approved By';
        else $group = 'Other';
        $data[] = [
            'id' => $row['id'],
            'office_name' => htmlspecialchars($oname),
            'office_code' => htmlspecialchars($row['office_code'] ?? ''),
            'hierarchy' => '<span class="badge bg-maroon">' . htmlspecialchars($group) . '</span>',
            'dept_name' => htmlspecialchars($row['dept_name'] ?? '<span class="text-muted">N/A</span>'),
            'status' => $row['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>',
            'actions' => $actions
        ];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'get_office') {
    $id = (int)($_REQUEST['office_id'] ?? 0);
    $stmt = $db->prepare("SELECT * FROM offices WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    echo json_encode($row ? ['success' => true, 'data' => $row] : ['success' => false, 'message' => 'Not found']);
    exit;
}

if ($action === 'create_office') {
    $name = trim($_POST['office_name'] ?? '');
    $code = trim($_POST['office_code'] ?? '');
    $deptId = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
    if (empty($name)) { echo json_encode(['success' => false, 'message' => 'Name is required']); exit; }
    $stmt = $db->prepare("INSERT INTO offices (office_name, office_code, department_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $name, $code, $deptId);
    if ($stmt->execute()) {
        logAudit('create', 'offices', "Created office: $name");
        echo json_encode(['success' => true, 'message' => 'Office created']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create']);
    }
    exit;
}

if ($action === 'update_office') {
    $id = (int)($_POST['office_id'] ?? 0);
    $name = trim($_POST['office_name'] ?? '');
    $code = trim($_POST['office_code'] ?? '');
    $deptId = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
    if (empty($name)) { echo json_encode(['success' => false, 'message' => 'Name is required']); exit; }
    $stmt = $db->prepare("UPDATE offices SET office_name=?, office_code=?, department_id=? WHERE id=?");
    $stmt->bind_param("ssii", $name, $code, $deptId, $id);
    if ($stmt->execute()) {
        logAudit('update', 'offices', "Updated office: $name");
        echo json_encode(['success' => true, 'message' => 'Office updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update']);
    }
    exit;
}

if ($action === 'toggle_office') {
    $id = (int)($_POST['office_id'] ?? 0);
    $currentStmt = $db->prepare("SELECT is_active FROM offices WHERE id = ?");
    $currentStmt->bind_param("i", $id);
    $currentStmt->execute();
    $current = $currentStmt->get_result()->fetch_assoc();
    if (!$current) { echo json_encode(['success' => false, 'message' => 'Not found']); exit; }
    $new = $current['is_active'] ? 0 : 1;
    $updateStmt = $db->prepare("UPDATE offices SET is_active = ? WHERE id = ?");
    $updateStmt->bind_param("ii", $new, $id);
    $updateStmt->execute();
    logAudit('update', 'offices', 'Toggled office status');
    echo json_encode(['success' => true, 'message' => 'Status updated']);
    exit;
}

if ($action === 'delete_office') {
    $id = (int)($_POST['office_id'] ?? 0);
    $stmt = $db->prepare("DELETE FROM offices WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        logAudit('delete', 'offices', "Deleted office ID: $id");
        echo json_encode(['success' => true, 'message' => 'Office deleted']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete']);
    }
    exit;
}

// === WORKFLOW CRUD ===
if ($action === 'list_workflows') {
    $result = $db->query("
        SELECT w.*, cp.period_name,
        (SELECT COUNT(*) FROM workflow_steps WHERE workflow_id = w.id) as step_count
        FROM clearance_workflow w
        LEFT JOIN clearance_periods cp ON w.period_id = cp.id
        ORDER BY w.created_at DESC
    ");
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $actions = '
            <button class="btn btn-sm btn-outline-info" onclick="manageSteps(' . $row['id'] . ', \'' . htmlspecialchars(addslashes($row['workflow_name'])) . '\')" title="Manage Steps"><i class="bi bi-diagram-3"></i></button>
            <button class="btn btn-sm btn-outline-primary" onclick="editWorkflow(' . $row['id'] . ')"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-outline-warning" onclick="toggleWorkflow(' . $row['id'] . ')"><i class="bi bi-' . ($row['is_active'] ? 'pause' : 'play') . '"></i></button>
            <button class="btn btn-sm btn-outline-danger" onclick="deleteWorkflow(' . $row['id'] . ')"><i class="bi bi-trash"></i></button>
        ';
        $data[] = [
            'id' => $row['id'],
            'workflow_name' => htmlspecialchars($row['workflow_name']),
            'period_name' => htmlspecialchars($row['period_name'] ?? 'All Periods'),
            'step_count' => (int)$row['step_count'],
            'status' => $row['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>',
            'actions' => $actions
        ];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'get_workflow') {
    $id = (int)($_REQUEST['workflow_id'] ?? 0);
    $stmt = $db->prepare("SELECT * FROM clearance_workflow WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    echo json_encode($row ? ['success' => true, 'data' => $row] : ['success' => false, 'message' => 'Not found']);
    exit;
}

if ($action === 'create_workflow') {
    $name = trim($_POST['workflow_name'] ?? '');
    $periodId = !empty($_POST['period_id']) ? (int)$_POST['period_id'] : null;
    if (empty($name)) { echo json_encode(['success' => false, 'message' => 'Name is required']); exit; }
    $stmt = $db->prepare("INSERT INTO clearance_workflow (workflow_name, period_id) VALUES (?, ?)");
    $stmt->bind_param("si", $name, $periodId);
    if ($stmt->execute()) {
        logAudit('create', 'workflow', "Created workflow: $name");
        echo json_encode(['success' => true, 'message' => 'Workflow created']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create']);
    }
    exit;
}

if ($action === 'update_workflow') {
    $id = (int)($_POST['workflow_id'] ?? 0);
    $name = trim($_POST['workflow_name'] ?? '');
    $periodId = !empty($_POST['period_id']) ? (int)$_POST['period_id'] : null;
    if (empty($name)) { echo json_encode(['success' => false, 'message' => 'Name is required']); exit; }
    $stmt = $db->prepare("UPDATE clearance_workflow SET workflow_name=?, period_id=? WHERE id=?");
    $stmt->bind_param("sii", $name, $periodId, $id);
    if ($stmt->execute()) {
        logAudit('update', 'workflow', "Updated workflow: $name");
        echo json_encode(['success' => true, 'message' => 'Workflow updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update']);
    }
    exit;
}

if ($action === 'toggle_workflow') {
    $id = (int)($_POST['workflow_id'] ?? 0);
    $currentStmt = $db->prepare("SELECT is_active FROM clearance_workflow WHERE id = ?");
    $currentStmt->bind_param("i", $id);
    $currentStmt->execute();
    $current = $currentStmt->get_result()->fetch_assoc();
    if (!$current) { echo json_encode(['success' => false, 'message' => 'Not found']); exit; }
    $new = $current['is_active'] ? 0 : 1;
    $updateStmt = $db->prepare("UPDATE clearance_workflow SET is_active = ? WHERE id = ?");
    $updateStmt->bind_param("ii", $new, $id);
    $updateStmt->execute();
    logAudit('update', 'workflow', 'Toggled workflow status');
    echo json_encode(['success' => true, 'message' => 'Status updated']);
    exit;
}

if ($action === 'delete_workflow') {
    $id = (int)($_POST['workflow_id'] ?? 0);
    $stmt = $db->prepare("DELETE FROM clearance_workflow WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        logAudit('delete', 'workflow', "Deleted workflow ID: $id");
        echo json_encode(['success' => true, 'message' => 'Workflow deleted']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete']);
    }
    exit;
}

// === WORKFLOW STEPS ===
if ($action === 'list_steps') {
    $wfId = (int)($_REQUEST['workflow_id'] ?? 0);
    $stmt = $db->prepare("
        SELECT ws.*, o.office_name 
        FROM workflow_steps ws 
        LEFT JOIN offices o ON ws.office_id = o.id 
        WHERE ws.workflow_id = ? 
        ORDER BY ws.step_order ASC
    ");
    $stmt->bind_param("i", $wfId);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $officeName = $row['office_name'] ? htmlspecialchars($row['office_name']) : 'Deans College Department (Auto)';
        $data[] = [
            'id' => $row['id'],
            'workflow_id' => $row['workflow_id'],
            'office_id' => $row['office_id'],
            'office_name' => $officeName,
            'step_order' => (int)$row['step_order'],
            'is_mandatory' => (int)$row['is_mandatory'],
            'is_dynamic' => (int)$row['is_dynamic'],
            'dynamic_field' => $row['dynamic_field'] ?? ''
        ];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'get_step') {
    $id = (int)($_REQUEST['step_id'] ?? 0);
    $stmt = $db->prepare("SELECT * FROM workflow_steps WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    echo json_encode($row ? ['success' => true, 'data' => $row] : ['success' => false, 'message' => 'Not found']);
    exit;
}

if ($action === 'create_step') {
    $wfId = (int)($_POST['workflow_id'] ?? 0);
    $officeId = (int)($_POST['office_id'] ?? 0);
    $order = (int)($_POST['step_order'] ?? 0);
    $mandatory = isset($_POST['is_mandatory']) ? 1 : 0;
    $dynamic = isset($_POST['is_dynamic']) ? 1 : 0;
    $dynamicField = trim($_POST['dynamic_field'] ?? '');
    if (empty($wfId)) { echo json_encode(['success' => false, 'message' => 'Required fields missing']); exit; }
    if ($officeId === 0) { $officeId = null; }
    $db->begin_transaction();
    try {
        $stmt = $db->prepare("INSERT INTO workflow_steps (workflow_id, office_id, step_order, is_mandatory, is_dynamic, dynamic_field) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiiiis", $wfId, $officeId, $order, $mandatory, $dynamic, $dynamicField);
        $stmt->execute();
        $newStepId = $db->insert_id;
        syncStepToClearances($db, $wfId, $newStepId, 'added');
        $db->commit();
        logAudit('create', 'workflow', 'Added workflow step');
        echo json_encode(['success' => true, 'message' => 'Step added']);
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to add step: ' . $e->getMessage()]);
    }
    exit;
}

if ($action === 'update_step') {
    $id = (int)($_POST['step_id'] ?? 0);
    $officeId = (int)($_POST['office_id'] ?? 0);
    $order = (int)($_POST['step_order'] ?? 0);
    $mandatory = isset($_POST['is_mandatory']) ? 1 : 0;
    $dynamic = isset($_POST['is_dynamic']) ? 1 : 0;
    $dynamicField = trim($_POST['dynamic_field'] ?? '');
    if ($officeId === 0) { $officeId = null; }
    $db->begin_transaction();
    try {
        $wfStmt = $db->prepare("SELECT workflow_id FROM workflow_steps WHERE id = ?");
        $wfStmt->bind_param("i", $id);
        $wfStmt->execute();
        $wfRow = $wfStmt->get_result()->fetch_assoc();
        $wfId = $wfRow ? (int)$wfRow['workflow_id'] : 0;
        $stmt = $db->prepare("UPDATE workflow_steps SET office_id=?, step_order=?, is_mandatory=?, is_dynamic=?, dynamic_field=? WHERE id=?");
        $stmt->bind_param("iiiisi", $officeId, $order, $mandatory, $dynamic, $dynamicField, $id);
        $stmt->execute();
        if ($wfId) reorderWorkflowSteps($db, $wfId);
        $db->commit();
        echo json_encode(['success' => true, 'message' => 'Step updated']);
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to update step']);
    }
    exit;
}

if ($action === 'delete_step') {
    $id = (int)($_POST['step_id'] ?? 0);
    $db->begin_transaction();
    try {
        $wfStmt = $db->prepare("SELECT workflow_id FROM workflow_steps WHERE id = ?");
        $wfStmt->bind_param("i", $id);
        $wfStmt->execute();
        $wfRow = $wfStmt->get_result()->fetch_assoc();
        $wfId = $wfRow ? (int)$wfRow['workflow_id'] : 0;
        syncStepToClearances($db, $wfId, $id, 'deleted');
        $stmt = $db->prepare("DELETE FROM workflow_steps WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($wfId) {
            reorderWorkflowSteps($db, $wfId);
            updateClearanceTotalSteps($db, $wfId);
        }
        $db->commit();
        echo json_encode(['success' => true, 'message' => 'Step removed']);
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to remove step']);
    }
    exit;
}

if ($action === 'reorder_steps') {
    $wfId = (int)($_POST['workflow_id'] ?? 0);
    $stepIds = $_POST['step_ids'] ?? [];
    if (is_array($stepIds)) {
        $db->begin_transaction();
        try {
            $reorderStmt = $db->prepare("UPDATE workflow_steps SET step_order = ? WHERE id = ? AND workflow_id = ?");
            foreach ($stepIds as $idx => $stepId) {
                $order = $idx + 1;
                $sid = (int)$stepId;
                $reorderStmt->bind_param("iii", $order, $sid, $wfId);
                $reorderStmt->execute();
            }
            updateClearanceTotalSteps($db, $wfId);
            $db->commit();
            echo json_encode(['success' => true, 'message' => 'Steps reordered']);
        } catch (Exception $e) {
            $db->rollback();
            echo json_encode(['success' => false, 'message' => 'Failed to reorder']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid data']);
    }
    exit;
}

// === CLEARANCE PERIODS ===
if ($action === 'list_periods') {
    $result = $db->query("SELECT * FROM clearance_periods ORDER BY created_at DESC");
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $actions = '
            <button class="btn btn-sm btn-outline-primary" onclick="editPeriod(' . $row['id'] . ')"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-outline-warning" onclick="togglePeriod(' . $row['id'] . ')"><i class="bi bi-' . ($row['is_active'] ? 'pause' : 'play') . '"></i></button>
            <button class="btn btn-sm btn-outline-danger" onclick="deletePeriod(' . $row['id'] . ')"><i class="bi bi-trash"></i></button>
        ';
        $statusMap = ['pending' => 'secondary', 'active' => 'success', 'closed' => 'danger'];
        $data[] = [
            'id' => $row['id'],
            'period_name' => htmlspecialchars($row['period_name']),
            'academic_year' => htmlspecialchars($row['academic_year'] ?? ''),
            'semester' => htmlspecialchars($row['semester'] ?? ''),
            'start_date' => $row['start_date'],
            'end_date' => $row['end_date'],
            'status_badge' => '<span class="badge bg-' . ($statusMap[$row['status']] ?? 'secondary') . '">' . ucfirst($row['status']) . '</span>',
            'is_active' => $row['is_active'] ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-secondary">No</span>',
            'actions' => $actions
        ];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'list_periods_select') {
    $result = $db->query("SELECT id, period_name FROM clearance_periods WHERE is_active = 1 OR status = 'active' ORDER BY created_at DESC");
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = ['id' => $row['id'], 'period_name' => htmlspecialchars($row['period_name'])];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'get_period') {
    $id = (int)($_REQUEST['period_id'] ?? 0);
    $stmt = $db->prepare("SELECT * FROM clearance_periods WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    echo json_encode($row ? ['success' => true, 'data' => $row] : ['success' => false, 'message' => 'Not found']);
    exit;
}

if ($action === 'create_period') {
    $name = trim($_POST['period_name'] ?? '');
    $ay = trim($_POST['academic_year'] ?? '');
    $sem = trim($_POST['semester'] ?? '');
    $start = $_POST['start_date'] ?? '';
    $end = $_POST['end_date'] ?? '';
    $status = $_POST['status'] ?? 'pending';
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    if (empty($name) || empty($start) || empty($end)) { echo json_encode(['success' => false, 'message' => 'Required fields missing']); exit; }
    if ($isActive) $db->query("UPDATE clearance_periods SET is_active = 0");
    $stmt = $db->prepare("INSERT INTO clearance_periods (period_name, academic_year, semester, start_date, end_date, is_active, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssis", $name, $ay, $sem, $start, $end, $isActive, $status);
    if ($stmt->execute()) {
        logAudit('create', 'periods', "Created period: $name");
        echo json_encode(['success' => true, 'message' => 'Period created']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create']);
    }
    exit;
}

if ($action === 'update_period') {
    $id = (int)($_POST['period_id'] ?? 0);
    $name = trim($_POST['period_name'] ?? '');
    $ay = trim($_POST['academic_year'] ?? '');
    $sem = trim($_POST['semester'] ?? '');
    $start = $_POST['start_date'] ?? '';
    $end = $_POST['end_date'] ?? '';
    $status = $_POST['status'] ?? 'pending';
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    if (empty($name) || empty($start) || empty($end)) { echo json_encode(['success' => false, 'message' => 'Required fields missing']); exit; }
    if ($isActive) $db->query("UPDATE clearance_periods SET is_active = 0");
    $stmt = $db->prepare("UPDATE clearance_periods SET period_name=?, academic_year=?, semester=?, start_date=?, end_date=?, is_active=?, status=? WHERE id=?");
    $stmt->bind_param("sssssisi", $name, $ay, $sem, $start, $end, $isActive, $status, $id);
    if ($stmt->execute()) {
        logAudit('update', 'periods', "Updated period: $name");
        echo json_encode(['success' => true, 'message' => 'Period updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update']);
    }
    exit;
}

if ($action === 'toggle_period') {
    $id = (int)($_POST['period_id'] ?? 0);
    $currentStmt = $db->prepare("SELECT is_active FROM clearance_periods WHERE id = ?");
    $currentStmt->bind_param("i", $id);
    $currentStmt->execute();
    $current = $currentStmt->get_result()->fetch_assoc();
    if (!$current) { echo json_encode(['success' => false, 'message' => 'Not found']); exit; }
    $db->query("UPDATE clearance_periods SET is_active = 0");
    $new = $current['is_active'] ? 0 : 1;
    $updateStmt = $db->prepare("UPDATE clearance_periods SET is_active = ? WHERE id = ?");
    $updateStmt->bind_param("ii", $new, $id);
    $updateStmt->execute();
    logAudit('update', 'periods', 'Toggled period active status');
    echo json_encode(['success' => true, 'message' => 'Status updated']);
    exit;
}

if ($action === 'delete_period') {
    $id = (int)($_POST['period_id'] ?? 0);
    $stmt = $db->prepare("DELETE FROM clearance_periods WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        logAudit('delete', 'periods', "Deleted period ID: $id");
        echo json_encode(['success' => true, 'message' => 'Period deleted']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete']);
    }
    exit;
}

// === AUDIT LOGS ===
if ($action === 'list_logs') {
    $draw = (int)($_REQUEST['draw'] ?? 1);
    $start = (int)($_REQUEST['start'] ?? 0);
    $length = (int)($_REQUEST['length'] ?? 50);
    $searchVal = $_REQUEST['search']['value'] ?? '';
    $orderCol = (int)($_REQUEST['order'][0]['column'] ?? 0);
    $orderDir = strtolower($_REQUEST['order'][0]['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
    $cols = ['id', 'username', 'role_name', 'action_type', 'module', 'description', 'ip_address', 'created_at'];
    $orderBy = $cols[$orderCol] ?? 'id';

    $filterUser = trim($_REQUEST['filter_user'] ?? '');
    $filterAction = trim($_REQUEST['filter_action'] ?? '');
    $filterModule = trim($_REQUEST['filter_module'] ?? '');
    $filterDate = trim($_REQUEST['filter_date'] ?? '');

    $where = [];
    $params = [];
    $types = '';

    if ($filterUser !== '') {
        $where[] = "username LIKE ?";
        $params[] = "%$filterUser%";
        $types .= "s";
    }
    if ($filterAction !== '') {
        $where[] = "action_type = ?";
        $params[] = $filterAction;
        $types .= "s";
    }
    if ($filterModule !== '') {
        $where[] = "module = ?";
        $params[] = $filterModule;
        $types .= "s";
    }
    if ($filterDate !== '') {
        $where[] = "DATE(created_at) = ?";
        $params[] = $filterDate;
        $types .= "s";
    }
    if ($searchVal !== '') {
        $where[] = "(username LIKE ? OR action_type LIKE ? OR module LIKE ? OR description LIKE ? OR ip_address LIKE ?)";
        $s = "%$searchVal%";
        $params = array_merge($params, [$s, $s, $s, $s, $s]);
        $types .= "sssss";
    }

    $whereClause = count($where) ? 'WHERE ' . implode(' AND ', $where) : '';

    $countStmt = $db->prepare("SELECT COUNT(*) as total FROM audit_logs $whereClause");
    if (!empty($params)) {
        $countStmt->bind_param($types, ...$params);
    }
    $countStmt->execute();
    $totalFiltered = $countStmt->get_result()->fetch_assoc()['total'];
    $totalAll = $db->query("SELECT COUNT(*) as total FROM audit_logs")->fetch_assoc()['total'];

    $stmt = $db->prepare("SELECT * FROM audit_logs $whereClause ORDER BY $orderBy $orderDir LIMIT ? OFFSET ?");
    $allParams = array_merge($params, [$length, $start]);
    $allTypes = $types . "ii";
    $stmt->bind_param($allTypes, ...$allParams);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = [
            'id' => $row['id'],
            'username' => htmlspecialchars($row['username'] ?? ''),
            'role_name' => htmlspecialchars($row['role_name'] ?? ''),
            'action_type' => '<span class="badge bg-' . ($row['action_type'] === 'login' ? 'info' : ($row['action_type'] === 'create' ? 'success' : ($row['action_type'] === 'delete' ? 'danger' : ($row['action_type'] === 'update' ? 'warning' : 'secondary')))) . '">' . htmlspecialchars($row['action_type']) . '</span>',
            'module' => htmlspecialchars($row['module'] ?? ''),
            'description' => htmlspecialchars($row['description'] ?? ''),
            'ip_address' => htmlspecialchars($row['ip_address'] ?? ''),
            'created_at' => formatDate($row['created_at'])
        ];
    }

    echo json_encode([
        'draw' => $draw,
        'recordsTotal' => $totalAll,
        'recordsFiltered' => $totalFiltered,
        'data' => $data
    ]);
    exit;
}

function reorderWorkflowSteps($db, $wfId)
{
    if (!$wfId) return;
    $stmt = $db->prepare("SELECT id FROM workflow_steps WHERE workflow_id = ? ORDER BY step_order ASC, id ASC");
    $stmt->bind_param("i", $wfId);
    $stmt->execute();
    $steps = $stmt->get_result();
    $order = 0;
    $updateStmt = $db->prepare("UPDATE workflow_steps SET step_order = ? WHERE id = ?");
    while ($step = $steps->fetch_assoc()) {
        $order++;
        $updateStmt->bind_param("ii", $order, $step['id']);
        $updateStmt->execute();
    }
}

function updateClearanceTotalSteps($db, $wfId)
{
    if (!$wfId) return;
    $countStmt = $db->prepare("SELECT COUNT(*) as total FROM workflow_steps WHERE workflow_id = ?");
    $countStmt->bind_param("i", $wfId);
    $countStmt->execute();
    $total = (int)$countStmt->get_result()->fetch_assoc()['total'];
    $updateStmt = $db->prepare("UPDATE clearance_requests SET total_steps = ? WHERE workflow_id = ? AND status = 'in_progress'");
    $updateStmt->bind_param("ii", $total, $wfId);
    $updateStmt->execute();
}

function syncStepToClearances($db, $wfId, $stepId, $action)
{
    if (!$wfId || !$stepId) return;

    if ($action === 'added') {
        $stepStmt = $db->prepare("SELECT office_id, step_order, is_dynamic, dynamic_field FROM workflow_steps WHERE id = ?");
        $stepStmt->bind_param("i", $stepId);
        $stepStmt->execute();
        $step = $stepStmt->get_result()->fetch_assoc();
        if (!$step) return;
        $stepOrder = (int)$step['step_order'];

        $crStmt = $db->prepare("
            SELECT cr.id as clearance_id, cr.current_step, cr.employee_id, e.department_id, e.user_id
            FROM clearance_requests cr
            JOIN employees e ON cr.employee_id = e.id
            WHERE cr.workflow_id = ? AND cr.status IN ('in_progress', 'pending')
        ");
        $crStmt->bind_param("i", $wfId);
        $crStmt->execute();
        $clearances = $crStmt->get_result();

        while ($cr = $clearances->fetch_assoc()) {
            if ((int)$cr['current_step'] > $stepOrder) continue;
            $empDeptId = $cr['department_id'] ? (int)$cr['department_id'] : null;
            $sigUsers = [];
            $isDynamic = (int)($step['is_dynamic'] ?? 0);
            $dynamicField = $step['dynamic_field'] ?? '';
            $officeId = $step['office_id'];

            if ($isDynamic && (empty($dynamicField) || $dynamicField === 'department_id') && $empDeptId) {
                if (!$officeId) {
                    $sigStmt = $db->prepare("
                        SELECT sp.user_id FROM signatory_profiles sp
                        JOIN offices o ON sp.office_id = o.id
                        WHERE o.office_code LIKE 'DEAN_%' AND sp.department_id = ? AND sp.is_active = 1
                    ");
                    $sigStmt->bind_param("i", $empDeptId);
                } else {
                    $sigStmt = $db->prepare("
                        SELECT sp.user_id FROM signatory_profiles sp
                        WHERE sp.office_id = ? AND sp.department_id = ? AND sp.is_active = 1
                    ");
                    $sigStmt->bind_param("ii", $officeId, $empDeptId);
                }
                $sigStmt->execute();
                while ($s = $sigStmt->get_result()->fetch_assoc()) {
                    $sigUsers[] = (int)$s['user_id'];
                }
            } elseif (!$isDynamic && $officeId) {
                $sigStmt = $db->prepare("
                    SELECT sp.user_id FROM signatory_profiles sp
                    WHERE sp.office_id = ? AND sp.is_active = 1
                ");
                $sigStmt->bind_param("i", $officeId);
                $sigStmt->execute();
                while ($s = $sigStmt->get_result()->fetch_assoc()) {
                    $sigUsers[] = (int)$s['user_id'];
                }
            }

            foreach ($sigUsers as $sigUserId) {
                $checkStmt = $db->prepare("
                    SELECT id FROM clearance_signatures 
                    WHERE clearance_id = ? AND step_id = ? AND signatory_id = ?
                ");
                $checkStmt->bind_param("iii", $cr['clearance_id'], $stepId, $sigUserId);
                $checkStmt->execute();
                if ($checkStmt->get_result()->num_rows === 0) {
                    $insertStmt = $db->prepare("
                        INSERT INTO clearance_signatures (clearance_id, step_id, signatory_id, action) 
                        VALUES (?, ?, ?, 'pending')
                    ");
                    $insertStmt->bind_param("iii", $cr['clearance_id'], $stepId, $sigUserId);
                    $insertStmt->execute();
                    createNotification($sigUserId, 'New Signature Required', 
                        'A new step has been added to your pending clearance.', 
                        'info', '../signatory/pending.php');
                }
            }
        }
        updateClearanceTotalSteps($db, $wfId);
    }

    if ($action === 'deleted') {
        $deleteStmt = $db->prepare("
            DELETE FROM clearance_signatures 
            WHERE step_id = ? AND action = 'pending'
        ");
        $deleteStmt->bind_param("i", $stepId);
        $deleteStmt->execute();
        $updateStmt = $db->prepare("
            UPDATE clearance_signatures SET action = 'orphaned' 
            WHERE step_id = ? AND action IN ('signed', 'rejected', 'returned')
        ");
        $updateStmt->bind_param("i", $stepId);
        $updateStmt->execute();
    }
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
