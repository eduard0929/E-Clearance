<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireAnyRole(['admin', 'signatory']);
header('Content-Type: application/json');

$db = getDB();
$user = getCurrentUser();
$userId = $user['id'];
$userRole = getCurrentRole();

$action = $_REQUEST['action'] ?? '';

if ($action === 'list_all') {
    $deptFilter = (int)($_GET['dept_id'] ?? 0);
    $typeFilter = $_GET['employee_type'] ?? '';
    $statusFilter = $_GET['status'] ?? '';

    $where = [];
    $params = [];
    $types = '';

    if ($deptFilter > 0) {
        $where[] = "e.department_id = ?";
        $params[] = $deptFilter;
        $types .= 'i';
    }
    if ($typeFilter !== '') {
        $where[] = "e.employee_type = ?";
        $params[] = $typeFilter;
        $types .= 's';
    }
    if ($statusFilter !== '') {
        $where[] = "cr.status = ?";
        $params[] = $statusFilter;
        $types .= 's';
    }
    $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $empTypeMap = [
        'regular_instructor' => 'Regular Instructor',
        'visiting_lecturer' => 'Visiting Lecturer',
        'non_teaching' => 'Non-Teaching Staff'
    ];
    $statusBadge = [
        'draft' => 'secondary',
        'pending' => 'secondary',
        'in_progress' => 'warning',
        'completed' => 'success',
        'rejected' => 'danger',
        'revoked' => 'danger'
    ];

    if ($userRole === 'signatory') {
        $stmt = $db->prepare("SELECT sp.office_id, o.office_name FROM signatory_profiles sp JOIN offices o ON sp.office_id = o.id WHERE sp.user_id = ? AND sp.is_active = 1");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $profile = $stmt->get_result()->fetch_assoc();
        $officeId = $profile['office_id'] ?? 0;
    }

    $sql = "
        SELECT 
            e.id as emp_record_id,
            e.employee_id,
            e.employee_type,
            e.position_title,
            u.first_name,
            u.middle_name,
            u.last_name,
            d.id as dept_id,
            d.dept_name,
            d.dept_code,
            cr.id as clearance_id,
            cr.clearance_code,
            cr.status as clearance_status,
            cr.current_step,
            cr.total_steps,
            cr.submitted_at,
            cr.completed_at,
            (SELECT COUNT(*) FROM clearance_signatures cs2 WHERE cs2.clearance_id = cr.id AND cs2.action = 'signed') as signed_steps,
            (SELECT o2.office_name FROM clearance_signatures cs3 
             JOIN workflow_steps ws2 ON cs3.step_id = ws2.id 
             JOIN offices o2 ON ws2.office_id = o2.id 
             WHERE cs3.clearance_id = cr.id AND cs3.action = 'pending' 
             ORDER BY ws2.step_order LIMIT 1) as current_office
        FROM employees e
        JOIN users u ON e.user_id = u.id
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN clearance_requests cr ON cr.employee_id = e.id AND cr.id = (
            SELECT MAX(cr2.id) FROM clearance_requests cr2 WHERE cr2.employee_id = e.id
        )
        $whereClause
        ORDER BY d.dept_name, e.employee_type, u.last_name
    ";
    $stmt = $db->prepare($sql);
    if ($types) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $typeLabel = $empTypeMap[$row['employee_type']] ?? ucfirst(str_replace('_', ' ', $row['employee_type']));
        $status = $row['clearance_status'] ?? 'none';
        $badgeColor = $statusBadge[$status] ?? 'secondary';
        $statusLabel = $status === 'none' ? 'No Clearance' : ucfirst(str_replace('_', ' ', $status));

        if ($status === 'in_progress' || $status === 'pending') {
            $progress = $row['total_steps'] > 0 ? round(($row['signed_steps'] / $row['total_steps']) * 100) : 0;
        } elseif ($status === 'completed') {
            $progress = 100;
        } else {
            $progress = 0;
        }

        $stepInfo = $row['clearance_id'] ? $row['signed_steps'] . '/' . $row['total_steps'] . ' signed' : '—';
        $currentOffice = $row['current_office'] ?? '—';

        $empMid = $row['middle_name'] ?? '';
        $empMidInit = $empMid ? ' ' . $empMid . ' ' : ' ';

        $data[] = [
            'employee_name' => htmlspecialchars($row['first_name'] . $empMidInit . $row['last_name']),
            'employee_id' => htmlspecialchars($row['employee_id'] ?? '—'),
            'employee_type' => htmlspecialchars($typeLabel),
            'department' => htmlspecialchars($row['dept_name'] ?? 'Unassigned'),
            'position' => htmlspecialchars($row['position_title'] ?? '—'),
            'clearance_code' => $row['clearance_code'] ? '<code>' . htmlspecialchars($row['clearance_code']) . '</code>' : '<span class="text-muted">—</span>',
            'status' => $row['clearance_id']
                ? '<span class="badge bg-' . $badgeColor . '">' . $statusLabel . '</span>'
                : '<span class="badge bg-secondary">No Clearance</span>',
            'progress' => $row['clearance_id']
                ? '<div class="progress" style="height:6px;"><div class="progress-bar bg-' . ($status === 'completed' ? 'success' : 'warning') . '" style="width:' . $progress . '%"></div></div><small class="text-muted">' . $stepInfo . '</small>'
                : '<span class="text-muted">—</span>',
            'current_office' => htmlspecialchars($currentOffice),
            'submitted' => $row['submitted_at'] ? formatDate($row['submitted_at']) : '—',
            'actions' => $row['clearance_id']
                ? '<a href="' . BASE_URL . 'employee/certificate.php?id=' . $row['clearance_id'] . '" target="_blank" class="btn btn-sm btn-outline-info" title="View Certificate"><i class="bi bi-file-earmark-text"></i></a>'
                : '—'
        ];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'stats') {
    $deptFilter = (int)($_GET['dept_id'] ?? 0);

    if ($deptFilter > 0) {
        $stmt = $db->prepare("SELECT COUNT(*) as c FROM employees e WHERE e.department_id = ?");
        $stmt->bind_param("i", $deptFilter);
        $stmt->execute();
        $total = $stmt->get_result()->fetch_assoc()['c'];

        $stmt = $db->prepare("SELECT COUNT(DISTINCT e.id) as c FROM employees e JOIN clearance_requests cr ON cr.employee_id = e.id WHERE e.department_id = ?");
        $stmt->bind_param("i", $deptFilter);
        $stmt->execute();
        $withClearance = $stmt->get_result()->fetch_assoc()['c'];

        $stmt = $db->prepare("SELECT COUNT(DISTINCT e.id) as c FROM employees e JOIN clearance_requests cr ON cr.employee_id = e.id AND cr.status = 'completed' WHERE e.department_id = ?");
        $stmt->bind_param("i", $deptFilter);
        $stmt->execute();
        $completed = $stmt->get_result()->fetch_assoc()['c'];

        $stmt = $db->prepare("SELECT COUNT(DISTINCT e.id) as c FROM employees e JOIN clearance_requests cr ON cr.employee_id = e.id AND cr.status IN ('in_progress','pending') WHERE e.department_id = ?");
        $stmt->bind_param("i", $deptFilter);
        $stmt->execute();
        $inProgress = $stmt->get_result()->fetch_assoc()['c'];
    } else {
        $total = $db->query("SELECT COUNT(*) as c FROM employees e")->fetch_assoc()['c'];
        $withClearance = $db->query("SELECT COUNT(DISTINCT e.id) as c FROM employees e JOIN clearance_requests cr ON cr.employee_id = e.id")->fetch_assoc()['c'];
        $completed = $db->query("SELECT COUNT(DISTINCT e.id) as c FROM employees e JOIN clearance_requests cr ON cr.employee_id = e.id AND cr.status = 'completed'")->fetch_assoc()['c'];
        $inProgress = $db->query("SELECT COUNT(DISTINCT e.id) as c FROM employees e JOIN clearance_requests cr ON cr.employee_id = e.id AND cr.status IN ('in_progress','pending')")->fetch_assoc()['c'];
    }
    $pendingSteps = $db->query("SELECT COUNT(*) as c FROM clearance_signatures cs JOIN clearance_requests cr ON cs.clearance_id = cr.id WHERE cs.action = 'pending'")->fetch_assoc()['c'];

    echo json_encode([
        'success' => true,
        'total_employees' => $total,
        'with_clearance' => $withClearance,
        'completed' => $completed,
        'in_progress' => $inProgress,
        'pending_signatures' => $pendingSteps
    ]);
    exit;
}

if ($action === 'departments') {
    $result = $db->query("SELECT id, dept_name, dept_code FROM departments ORDER BY dept_name");
    $depts = [];
    while ($d = $result->fetch_assoc()) {
        $depts[] = $d;
    }
    echo json_encode(['data' => $depts]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
