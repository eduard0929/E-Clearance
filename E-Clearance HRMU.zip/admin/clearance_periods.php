<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('admin');

$db = getDB();
$user = getCurrentUser();
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clearance Periods - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Administration</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="users.php"><i class="bi bi-people"></i><span> Users</span></a></li>
                <li class="nav-item"><a class="nav-link" href="departments.php"><i class="bi bi-building"></i><span> College Departments</span></a></li>
                <li class="nav-item"><a class="nav-link" href="offices.php"><i class="bi bi-door-open"></i><span> College Offices</span></a></li>
                <li class="nav-item"><a class="nav-link" href="workflow.php"><i class="bi bi-diagram-3"></i><span> Workflow</span></a></li>
                <li class="nav-item"><a class="nav-link active" href="clearance_periods.php"><i class="bi bi-calendar-event"></i><span> Periods</span></a></li>
                <li class="nav-item"><a class="nav-link" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link" href="settings.php"><i class="bi bi-toggles"></i><span> Settings</span></a></li>
                <li class="nav-item"><a class="nav-link" href="audit_logs.php"><i class="bi bi-journal-text"></i><span> Audit Logs</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Header -->
            <?php
            $pageTitle = 'Clearance Periods';
            $pageIcon = 'bi-calendar-event';
            include __DIR__ . '/../includes/top_header.php';
            ?>

            <!-- Page Content -->
            <div class="page-content animate-fade-in-up">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0"><i class="bi bi-calendar-event text-maroon me-1"></i> Clearance Periods</h4>
                    <button class="btn btn-maroon" data-bs-toggle="modal" data-bs-target="#periodModal" onclick="resetPeriodForm()">
                        <i class="bi bi-plus-lg"></i> New Period
                    </button>
                </div>

                <div class="glass-card-static">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table id="periodsTable" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Period Name</th>
                                        <th>Academic Year</th>
                                        <th>Semester</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Active</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile sidebar backdrop -->
    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <div class="modal fade" id="periodModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="periodModalTitle">New Period</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="periodForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="create_period">
                        <input type="hidden" name="period_id" id="period_id">
                        <div class="mb-3">
                            <label class="form-label">Period Name</label>
                            <input type="text" class="form-control" name="period_name" id="period_name" required>
                        </div>
                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Academic Year</label>
                                <input type="text" class="form-control" name="academic_year" id="academic_year" placeholder="e.g., 2025-2026">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Semester</label>
                                <select class="form-select" name="semester" id="semester">
                                    <option value="">Select</option>
                                    <option value="1st Semester">1st Semester</option>
                                    <option value="2nd Semester">2nd Semester</option>
                                    <option value="Summer">Summer</option>
                                </select>
                            </div>
                        </div>
                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Start Date</label>
                                <input type="date" class="form-control" name="start_date" id="start_date" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">End Date</label>
                                <input type="date" class="form-control" name="end_date" id="end_date" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" id="period_status">
                                <option value="pending">Pending</option>
                                <option value="active">Active</option>
                                <option value="closed">Closed</option>
                            </select>
                        </div>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="is_active" id="period_is_active" value="1">
                            <label class="form-check-label" for="period_is_active">Set as Active Period</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-maroon">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
    $(document).ready(function() {
        var table = $('#periodsTable').DataTable({
            ajax: { url: 'users_ajax.php', data: { action: 'list_periods' } },
            columns: [
                { data: 'id' },
                { data: 'period_name' },
                { data: 'academic_year' },
                { data: 'semester' },
                { data: 'start_date' },
                { data: 'end_date' },
                { data: 'status_badge' },
                { data: 'is_active' },
                { data: 'actions', orderable: false }
            ],
            order: [[0, 'desc']],
            pageLength: 25
        });

        $('#periodForm').on('submit', function(e) {
            e.preventDefault();
            $.ajax({
                url: 'users_ajax.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        $('#periodModal').modal('hide');
                        table.ajax.reload();
                        showToast('success', res.message);
                    } else {
                        showToast('danger', res.message);
                    }
                }
            });
        });

    });

    function resetPeriodForm() {
        $('#periodForm')[0].reset();
        $('#period_id').val('');
        $('#periodModalTitle').text('New Period');
        $('[name="action"]').val('create_period');
    }

    function editPeriod(id) {
        $.ajax({
            url: 'users_ajax.php',
            data: { action: 'get_period', period_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    var p = res.data;
                    $('#period_id').val(p.id);
                    $('#period_name').val(p.period_name);
                    $('#academic_year').val(p.academic_year);
                    $('#semester').val(p.semester);
                    $('#start_date').val(p.start_date);
                    $('#end_date').val(p.end_date);
                    $('#period_status').val(p.status);
                    $('#period_is_active').prop('checked', p.is_active == 1);
                    $('#periodModalTitle').text('Edit Period');
                    $('[name="action"]').val('update_period');
                    $('#periodModal').modal('show');
                }
            }
        });
    }

    function togglePeriod(id) {
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'toggle_period', period_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#periodsTable').DataTable().ajax.reload();
                    showToast('success', res.message);
                }
            }
        });
    }

    function deletePeriod(id) {
        if (!confirm('Delete this clearance period?')) return;
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'delete_period', period_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#periodsTable').DataTable().ajax.reload();
                    showToast('success', res.message);
                } else {
                    showToast('danger', res.message);
                }
            }
        });
    }

    function showToast(type, message) {
        var bg = type === 'success' ? 'bg-success' : 'bg-danger';
        var toast = '<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div class="toast align-items-center text-white ' + bg + ' border-0 show" role="alert"><div class="d-flex"><div class="toast-body">' + message + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>';
        $('body').append(toast);
        setTimeout(function() { $(toast).remove(); }, 3000);
    }
    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
