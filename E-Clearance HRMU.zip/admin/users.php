<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('admin');

$db = getDB();
$user = getCurrentUser();
require_once __DIR__ . '/../includes/dean_office.php';
$roles = $db->query("SELECT id, role_name FROM roles ORDER BY role_name");
$offices = $db->query("SELECT o.id, o.office_name, d.dept_name 
    FROM offices o 
    LEFT JOIN departments d ON o.department_id = d.id 
    WHERE o.is_active = 1 
    ORDER BY o.office_name");
$collegeDepts = $db->query("
    SELECT d.id, d.dept_name, d.dept_code, o.id AS office_id, o.office_name
    FROM departments d
    LEFT JOIN offices o ON o.department_id = d.id AND o.is_active = 1
        AND (
            o.office_code LIKE 'DEAN_%'
            OR o.office_name LIKE 'Dean, %'
            OR o.office_name LIKE 'Director, %'
            OR o.office_name LIKE 'Principal, %'
            OR o.office_name LIKE 'OIC-Dean, %'
        )
    WHERE d.is_active = 1 AND d.dept_type = 'college'
    ORDER BY d.dept_name
");
$departments = $db->query("SELECT id, dept_name FROM departments WHERE is_active = 1 AND dept_type = 'college' ORDER BY dept_name");
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>

        <!-- Main Content -->
        <div class="main-content">
            <?php
            $pageTitle = 'User Management';
            $pageIcon = 'bi-people';
            include __DIR__ . '/../includes/top_header.php';
            ?>

            <!-- Page Content -->
            <div class="page-content animate-fade-in-up">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0"><i class="bi bi-people text-maroon me-1"></i> User Management</h4>
                    <button class="btn btn-maroon" data-bs-toggle="modal" data-bs-target="#userModal" onclick="resetForm()">
                        <i class="bi bi-plus-lg"></i> New User
                    </button>
                </div>

                <div class="glass-card-static">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table id="usersTable" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Gmail</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                        <th>Last Login</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile sidebar backdrop -->
    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <div class="modal fade" id="userModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="userForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="create">
                        <input type="hidden" name="user_id" id="user_id">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Username</label>
                                <input type="text" class="form-control" name="username" id="username" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Password</label>
                                <div class="password-wrapper">
                                    <input type="password" class="form-control" name="password" id="password">
                                    <button type="button" class="password-toggle-btn" tabindex="-1"><i class="bi bi-eye"></i></button>
                                </div>
                                <small class="text-muted">Leave blank to keep current password when editing</small>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">First Name</label>
                                <input type="text" class="form-control" name="first_name" id="first_name" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Middle Name</label>
                                <input type="text" class="form-control" name="middle_name" id="middle_name">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Last Name</label>
                                <input type="text" class="form-control" name="last_name" id="last_name" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Role</label>
                                <select class="form-select" name="role_id" id="role_id" required>
                                    <option value="">Select Role</option>
                                    <?php while($role = $roles->fetch_assoc()): ?>
                                    <option value="<?= $role['id'] ?>"><?= ucfirst($role['role_name']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" id="email">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Gmail Address</label>
                                <input type="email" class="form-control" name="gmail_address" id="gmail_address">
                            </div>
                        </div>
                        <div class="row g-3 mt-2" id="signatoryFields" style="display:none;">
                            <div class="col-md-6">
                                <label class="form-label">Signatory Assignment</label>
                                <select class="form-select" id="signatory_assignment">
                                    <option value="standard">Standard Office</option>
                                    <option value="dean_college">Dean of College</option>
                                </select>
                            </div>
                            <div class="col-md-6" id="standardOfficeField">
                                <label class="form-label">Office Assignment</label>
                                <select class="form-select" name="office_id" id="office_id">
                                    <option value="">Select Office</option>
                                    <?php $offices->data_seek(0); while($office = $offices->fetch_assoc()):
                                        $oname = $office['office_name'];
                                        if (!isDeanCollegeOffice($oname)): ?>
                                        <option value="<?= $office['id'] ?>"><?= htmlspecialchars($oname) ?></option>
                                    <?php endif; endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6" id="deanDeptField" style="display:none;">
                                <label class="form-label">College Department</label>
                                <select class="form-select" name="dean_department_id" id="dean_department_id">
                                    <option value="">Select College Department</option>
                                    <?php $collegeDepts->data_seek(0); while($dept = $collegeDepts->fetch_assoc()):
                                        $prefix = getDeanOfficePrefix($dept['dept_name'], $dept['dept_code'] ?? '');
                                        $deanLabel = $prefix . ', ' . $dept['dept_name'];
                                        $officeId = $dept['office_id'] ?? '';
                                    ?>
                                    <option value="<?= $dept['id'] ?>" data-office-id="<?= $officeId ?>" data-dean-label="<?= htmlspecialchars($deanLabel) ?>">
                                        <?= htmlspecialchars($dept['dept_name']) ?> — <?= htmlspecialchars($deanLabel) ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                                <small class="text-muted">The dean office is assigned automatically based on the college department</small>
                                <input type="hidden" name="office_id" id="dean_office_id" value="" disabled>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Designation</label>
                                <input type="text" class="form-control" name="designation" id="designation" placeholder="e.g., Registrar">
                            </div>
                        </div>
                        <div class="row g-3 mt-2" id="employeeFields" style="display:none;">
                            <div class="col-md-4">
                                <label class="form-label">Department</label>
                                <select class="form-select" name="employee_dept_id" id="employee_dept_id">
                                    <option value="">Select Department</option>
                                    <?php $departments->data_seek(0); while($dept = $departments->fetch_assoc()): ?>
                                    <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['dept_name']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Employee ID</label>
                                <input type="text" class="form-control" name="employee_id" id="employee_id">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Position</label>
                                <input type="text" class="form-control" name="position_title" id="position_title">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Employee Type</label>
                                <select class="form-select" name="employee_type" id="employee_type">
                                    <option value="regular_instructor">Regular Instructor</option>
                                    <option value="visiting_lecturer">Visiting Lecturer (VL)</option>
                                    <option value="non_teaching">Non-Teaching Personnel</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-maroon" id="submitBtn">Save User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
    $(document).ready(function() {
        var table = $('#usersTable').DataTable({
            serverSide: false,
            ajax: {
                url: 'users_ajax.php',
                data: { action: 'list' }
            },
            columns: [
                { data: 'id', defaultContent: '' },
                { data: 'username', defaultContent: '' },
                { data: 'full_name', defaultContent: '' },
                { data: 'email', defaultContent: '' },
                { data: 'gmail_address', defaultContent: '' },
                { data: 'role_name', defaultContent: '' },
                { data: 'status', defaultContent: '' },
                { data: 'last_login', defaultContent: '' },
                { data: 'actions', orderable: false, defaultContent: '' }
            ],
            order: [[0, 'desc']],
            pageLength: 25,
            columnDefs: [
                { targets: '_all', defaultContent: '' }
            ]
        });

        $('#role_id').on('change', function() {
            var role = $(this).find('option:selected').text().toLowerCase();
            if (role === 'signatory') {
                $('#signatoryFields').show();
                $('#employeeFields').hide();
                $('#signatory_assignment').trigger('change');
            } else if (role === 'employee') {
                $('#employeeFields').show();
                $('#signatoryFields').hide();
            } else {
                $('#signatoryFields').hide();
                $('#employeeFields').hide();
            }
        });

        $('#signatory_assignment').on('change', function() {
            var assignment = $(this).val();
            if (assignment === 'dean_college') {
                $('#standardOfficeField').hide();
                $('#deanDeptField').show();
                $('#office_id').prop('disabled', true).val('');
                $('#dean_office_id').prop('disabled', false);
                $('#dean_department_id').trigger('change');
            } else {
                $('#standardOfficeField').show();
                $('#deanDeptField').hide();
                $('#office_id').prop('disabled', false);
                $('#dean_office_id').prop('disabled', true).val('');
                $('#dean_department_id').val('');
            }
        });

        $('#dean_department_id').on('change', function() {
            var opt = $(this).find('option:selected');
            var officeId = opt.data('office-id') || '';
            var deanLabel = opt.data('dean-label') || '';
            $('#dean_office_id').val(officeId);
            if (deanLabel && !$('#designation').val()) {
                $('#designation').attr('placeholder', deanLabel);
            }
        });

        $('#userForm').on('submit', function(e) {
            e.preventDefault();
            if ($('#signatory_assignment').val() === 'dean_college') {
                if (!$('#dean_department_id').val()) {
                    showToast('danger', 'Please select a college department for the dean');
                    return;
                }
            }
            var data = new FormData(this);
            $.ajax({
                url: 'users_ajax.php',
                type: 'POST',
                data: data,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        $('#userModal').modal('hide');
                        table.ajax.reload();
                        showToast('success', res.message);
                    } else {
                        showToast('danger', res.message);
                    }
                },
                error: function() {
                    showToast('danger', 'Request failed');
                }
            });
        });

    });

    function resetForm() {
        $('#userForm')[0].reset();
        $('#user_id').val('');
        $('#password').prop('required', true);
        $('#modalTitle').text('New User');
        $('#submitBtn').text('Save User');
        $('#signatoryFields').hide();
        $('#employeeFields').hide();
        $('#signatory_assignment').val('standard');
        $('#office_id').prop('disabled', false);
        $('#dean_office_id').prop('disabled', true).val('');
        $('#standardOfficeField').show();
        $('#deanDeptField').hide();
        $('[name="action"]').val('create');
    }

    function editUser(id) {
        $.ajax({
            url: 'users_ajax.php',
            data: { action: 'get', user_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    var u = res.data;
                    $('#user_id').val(u.id);
                    $('#username').val(u.username);
                    $('#password').removeAttr('required');
                    $('#first_name').val(u.first_name);
                    $('#middle_name').val(u.middle_name);
                    $('#last_name').val(u.last_name);
                    $('#email').val(u.email);
                    $('#gmail_address').val(u.gmail_address);
                    $('#role_id').val(u.role_id).trigger('change');
                    if (u.office_id) {
                        if (u.is_dean_college) {
                            $('#signatory_assignment').val('dean_college').trigger('change');
                            if (u.department_id) {
                                $('#dean_department_id').val(u.department_id).trigger('change');
                            }
                        } else {
                            $('#signatory_assignment').val('standard').trigger('change');
                            $('#office_id').val(u.office_id);
                        }
                    }
                    if (u.designation) $('#designation').val(u.designation);
                    if (u.employee_id) $('#employee_id').val(u.employee_id);
                    if (u.position_title) $('#position_title').val(u.position_title);
                    if (u.employee_dept_id) $('#employee_dept_id').val(u.employee_dept_id);
                    if (u.employee_type) $('#employee_type').val(u.employee_type);
                    $('#modalTitle').text('Edit User');
                    $('#submitBtn').text('Update User');
                    $('[name="action"]').val('update');
                    $('#userModal').modal('show');
                } else {
                    showToast('danger', res.message);
                }
            }
        });
    }

    function toggleStatus(id) {
        if (!confirm('Toggle user status?')) return;
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'toggle_status', user_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#usersTable').DataTable().ajax.reload();
                    showToast('success', res.message);
                } else {
                    showToast('danger', res.message);
                }
            }
        });
    }

    function deleteUser(id) {
        if (!confirm('Are you sure you want to delete this user? This cannot be undone.')) return;
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'delete', user_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#usersTable').DataTable().ajax.reload();
                    showToast('success', res.message);
                } else {
                    showToast('danger', res.message);
                }
            }
        });
    }

    function showToast(type, message) {
        var bg = type === 'success' ? 'bg-success' : 'bg-danger';
        var toast = '<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div class="toast align-items-center text-white ' + bg + ' border-0 show" role="alert"><div class="d-flex"><div class="toast-body">' + message + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>';
        $('body').append(toast);
        setTimeout(function() { $(toast).remove(); }, 3000);
    }
    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
