<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('admin');

$db = getDB();
$user = getCurrentUser();
$role = $user['role_name'];
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Departments - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Administration</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="users.php"><i class="bi bi-people"></i><span> Users</span></a></li>
                <li class="nav-item"><a class="nav-link active" href="departments.php"><i class="bi bi-building"></i><span> College Departments</span></a></li>
                <li class="nav-item"><a class="nav-link" href="offices.php"><i class="bi bi-door-open"></i><span> College Offices</span></a></li>
                <li class="nav-item"><a class="nav-link" href="workflow.php"><i class="bi bi-diagram-3"></i><span> Workflow</span></a></li>
                <li class="nav-item"><a class="nav-link" href="clearance_periods.php"><i class="bi bi-calendar-event"></i><span> Periods</span></a></li>
                <li class="nav-item"><a class="nav-link" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link" href="settings.php"><i class="bi bi-toggles"></i><span> Settings</span></a></li>
                <li class="nav-item"><a class="nav-link" href="audit_logs.php"><i class="bi bi-journal-text"></i><span> Audit Logs</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Header -->
            <?php
            $pageTitle = 'College Departments';
            $pageIcon = 'bi-building';
            include __DIR__ . '/../includes/top_header.php';
            ?>

            <!-- Page Content -->
            <div class="page-content animate-fade-in-up">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0"><i class="bi bi-building text-maroon me-1"></i> College Departments</h4>
                    <button class="btn btn-maroon" data-bs-toggle="modal" data-bs-target="#deptModal" onclick="resetDeptForm()">
                        <i class="bi bi-plus-lg"></i> New College Department
                    </button>
                </div>

                <div class="glass-card-static">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table id="deptsTable" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>College Department</th>
                                        <th>Code</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile sidebar backdrop -->
    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <div class="modal fade" id="deptModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deptModalTitle">New College Department</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="deptForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="create_dept">
                        <input type="hidden" name="dept_id" id="dept_id">
                        <input type="hidden" name="dept_type" value="college">
                        <div class="mb-3">
                            <label class="form-label">College Department Name</label>
                            <input type="text" class="form-control" name="dept_name" id="dept_name" required>
                            <small class="text-muted">e.g. College of Information and Computing Science</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Department Code</label>
                            <input type="text" class="form-control" name="dept_code" id="dept_code" placeholder="e.g. CICS">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Dean Designation</label>
                            <input type="text" class="form-control" id="dean_designation" placeholder="e.g. Dean, College of ..." readonly>
                            <small class="text-muted">Auto-generated from department name</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-maroon">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
    function updateDeanDesignation() {
        var name = $('#dept_name').val().trim();
        var code = $('#dept_code').val().trim().toUpperCase();
        if (name) {
            var prefix = 'Dean';
            if (name.indexOf('Department') !== -1 || name.indexOf('NSTP') !== -1 || code === 'NSTP' || name.indexOf('National Service') !== -1) prefix = 'Director';
            if (name.indexOf('Senior High School') !== -1 || code === 'SHS') prefix = 'Principal';
            if (name.indexOf('School of Business') !== -1 || code === 'SBA') prefix = 'OIC-Dean';
            $('#dean_designation').val(prefix + ', ' + name);
        } else {
            $('#dean_designation').val('');
        }
    }

    $(document).ready(function() {
        var table = $('#deptsTable').DataTable({
            ajax: { url: 'users_ajax.php', data: { action: 'list_college_depts' } },
            columns: [
                { data: 'id' },
                { data: 'dept_name' },
                { data: 'dept_code' },
                { data: 'status' },
                { data: 'actions', orderable: false }
            ],
            order: [[0, 'desc']],
            pageLength: 25
        });

        $('#dept_name, #dept_code').on('input', updateDeanDesignation);

        $('#deptForm').on('submit', function(e) {
            e.preventDefault();
            $.ajax({
                url: 'users_ajax.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        $('#deptModal').modal('hide');
                        table.ajax.reload();
                        showToast('success', res.message);
                    } else {
                        showToast('danger', res.message);
                    }
                }
            });
        });

    });

    function resetDeptForm() {
        $('#deptForm')[0].reset();
        $('#dept_id').val('');
        $('#deptModalTitle').text('New College Department');
        $('[name="action"]').val('create_dept');
        $('#dean_designation').val('');
    }

    function editDept(id) {
        $.ajax({
            url: 'users_ajax.php',
            data: { action: 'get_dept', dept_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    var d = res.data;
                    $('#dept_id').val(d.id);
                    $('#dept_name').val(d.dept_name);
                    $('#dept_code').val(d.dept_code);
                    $('#deptModalTitle').text('Edit College Department');
                    $('[name="action"]').val('update_dept');
                    updateDeanDesignation();
                    $('#deptModal').modal('show');
                }
            }
        });
    }

    function toggleDept(id) {
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'toggle_dept', dept_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#deptsTable').DataTable().ajax.reload();
                    showToast('success', res.message);
                }
            }
        });
    }

    function deleteDept(id) {
        if (!confirm('Delete this department?')) return;
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'delete_dept', dept_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#deptsTable').DataTable().ajax.reload();
                    showToast('success', res.message);
                } else {
                    showToast('danger', res.message);
                }
            }
        });
    }

    function showToast(type, message) {
        var bg = type === 'success' ? 'bg-success' : 'bg-danger';
        var toast = '<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div class="toast align-items-center text-white ' + bg + ' border-0 show" role="alert"><div class="d-flex"><div class="toast-body">' + message + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>';
        $('body').append(toast);
        setTimeout(function() { $(toast).remove(); }, 3000);
    }
    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
