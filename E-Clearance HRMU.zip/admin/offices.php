<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('admin');

$db = getDB();
$user = getCurrentUser();
$departments = $db->query("SELECT id, dept_name FROM departments WHERE is_active = 1 AND dept_type = 'college' ORDER BY dept_name");
require_once __DIR__ . '/../includes/header.php';
$officeGroups = [
    'Student Records/Grades' => ['Registrar Office'],
    'Financial' => ['Cashier Office', 'University Accountant'],
    'Library' => ['Learning Commons Center'],
    'Property' => ['Supply and Property Management Unit'],
    'Administrative' => ['Chief Administrative Officer', 'VP for Admin and Finance'],
    'Recommending Approval' => ['VP for Academic Affairs', 'VP for Research and Extension', 'Legal Officer', 'VP for Student Affairs and Services'],
    'Approved By' => ['President']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offices - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Administration</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="users.php"><i class="bi bi-people"></i><span> Users</span></a></li>
                <li class="nav-item"><a class="nav-link" href="departments.php"><i class="bi bi-building"></i><span> College Departments</span></a></li>
                <li class="nav-item"><a class="nav-link active" href="offices.php"><i class="bi bi-door-open"></i><span> College Offices</span></a></li>
                <li class="nav-item"><a class="nav-link" href="workflow.php"><i class="bi bi-diagram-3"></i><span> Workflow</span></a></li>
                <li class="nav-item"><a class="nav-link" href="clearance_periods.php"><i class="bi bi-calendar-event"></i><span> Periods</span></a></li>
                <li class="nav-item"><a class="nav-link" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link" href="settings.php"><i class="bi bi-toggles"></i><span> Settings</span></a></li>
                <li class="nav-item"><a class="nav-link" href="audit_logs.php"><i class="bi bi-journal-text"></i><span> Audit Logs</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Header -->
            <?php
            $pageTitle = 'Offices';
            $pageIcon = 'bi-door-open';
            include __DIR__ . '/../includes/top_header.php';
            ?>

            <!-- Page Content -->
            <div class="page-content animate-fade-in-up">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0"><i class="bi bi-door-open text-maroon me-1"></i> College Offices</h4>
                    <p class="text-muted mb-0 small">Manage clearance signatory offices. Assign each office to a College Department and configure their approval hierarchy in <a href="workflow.php">Workflow</a>.</p>
                    <button class="btn btn-maroon" data-bs-toggle="modal" data-bs-target="#officeModal" onclick="resetOfficeForm()">
                        <i class="bi bi-plus-lg"></i> New Office
                    </button>
                </div>

                <div class="glass-card-static">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table id="officesTable" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Office Name</th>
                                        <th>Code</th>
                                        <th>Group</th>
                                        <th>College Department</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile sidebar backdrop -->
    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <div class="modal fade" id="officeModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="officeModalTitle">New Office</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="officeForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="create_office">
                        <input type="hidden" name="office_id" id="office_id">
                        <div class="mb-3">
                            <label class="form-label">Office Name</label>
                            <input type="text" class="form-control" name="office_name" id="office_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Office Code</label>
                            <input type="text" class="form-control" name="office_code" id="office_code">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">College Department</label>
                            <select class="form-select" name="department_id" id="ofc_department_id">
                                <option value="">None (General Office)</option>
                                <?php $departments->data_seek(0); while($dept = $departments->fetch_assoc()): ?>
                                <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['dept_name']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-maroon">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
    $(document).ready(function() {
        var table = $('#officesTable').DataTable({
            ajax: { url: 'users_ajax.php', data: { action: 'list_offices' } },
            columns: [
                { data: 'id' },
                { data: 'office_name' },
                { data: 'office_code' },
                { data: 'hierarchy' },
                { data: 'dept_name' },
                { data: 'status' },
                { data: 'actions', orderable: false }
            ],
            order: [[0, 'desc']],
            pageLength: 25
        });

        $('#officeForm').on('submit', function(e) {
            e.preventDefault();
            $.ajax({
                url: 'users_ajax.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        $('#officeModal').modal('hide');
                        table.ajax.reload();
                        showToast('success', res.message);
                    } else {
                        showToast('danger', res.message);
                    }
                }
            });
        });

    });

    function resetOfficeForm() {
        $('#officeForm')[0].reset();
        $('#office_id').val('');
        $('#officeModalTitle').text('New Office');
        $('[name="action"]').val('create_office');
    }

    function editOffice(id) {
        $.ajax({
            url: 'users_ajax.php',
            data: { action: 'get_office', office_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    var o = res.data;
                    $('#office_id').val(o.id);
                    $('#office_name').val(o.office_name);
                    $('#office_code').val(o.office_code);
                    $('#ofc_department_id').val(o.department_id || '');
                    $('#officeModalTitle').text('Edit Office');
                    $('[name="action"]').val('update_office');
                    $('#officeModal').modal('show');
                }
            }
        });
    }

    function toggleOffice(id) {
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'toggle_office', office_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#officesTable').DataTable().ajax.reload();
                    showToast('success', res.message);
                }
            }
        });
    }

    function deleteOffice(id) {
        if (!confirm('Delete this office?')) return;
        $.ajax({
            url: 'users_ajax.php',
            type: 'POST',
            data: { action: 'delete_office', office_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#officesTable').DataTable().ajax.reload();
                    showToast('success', res.message);
                } else {
                    showToast('danger', res.message);
                }
            }
        });
    }

    function showToast(type, message) {
        var bg = type === 'success' ? 'bg-success' : 'bg-danger';
        var toast = '<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div class="toast align-items-center text-white ' + bg + ' border-0 show" role="alert"><div class="d-flex"><div class="toast-body">' + message + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>';
        $('body').append(toast);
        setTimeout(function() { $(toast).remove(); }, 3000);
    }
    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
