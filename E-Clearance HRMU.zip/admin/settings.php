<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('admin');

$db = getDB();
$user = getCurrentUser();
require_once __DIR__ . '/../includes/header.php';

$settings = [];
$result = $db->query("SELECT setting_key, setting_value FROM system_settings");
while ($row = $result->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $keys = [
        'university_name', 'system_name',
        'smtp_host', 'smtp_port', 'smtp_username', 'smtp_password', 'smtp_encryption', 'from_email', 'from_name',
        'dean_workflow_enabled', 'qr_enabled', 'signature_required'
    ];
    foreach ($keys as $key) {
        $val = $_POST[$key] ?? '';
        $stmt = $db->prepare("INSERT INTO system_settings (setting_key, setting_value, setting_group) VALUES (?, ?, 'general') ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->bind_param("sss", $key, $val, $val);
        $stmt->execute();
    }
    logAudit('update', 'settings', 'System settings updated');
    echo json_encode(['success' => true, 'message' => 'Settings saved successfully']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Administration</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="users.php"><i class="bi bi-people"></i><span> Users</span></a></li>
                <li class="nav-item"><a class="nav-link" href="departments.php"><i class="bi bi-building"></i><span> College Departments</span></a></li>
                <li class="nav-item"><a class="nav-link" href="offices.php"><i class="bi bi-door-open"></i><span> College Offices</span></a></li>
                <li class="nav-item"><a class="nav-link" href="workflow.php"><i class="bi bi-diagram-3"></i><span> Workflow</span></a></li>
                <li class="nav-item"><a class="nav-link" href="clearance_periods.php"><i class="bi bi-calendar-event"></i><span> Periods</span></a></li>
                <li class="nav-item"><a class="nav-link" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link active" href="settings.php"><i class="bi bi-toggles"></i><span> Settings</span></a></li>
                <li class="nav-item"><a class="nav-link" href="audit_logs.php"><i class="bi bi-journal-text"></i><span> Audit Logs</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Header -->
            <?php
            $pageTitle = 'System Settings';
            $pageIcon = 'bi-toggles';
            include __DIR__ . '/../includes/top_header.php';
            ?>

            <!-- Page Content -->
            <div class="page-content animate-fade-in-up">
                <h4 class="fw-bold mb-4"><i class="bi bi-toggles text-maroon me-1"></i> System Settings</h4>

                <form id="settingsForm">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="glass-card-static mb-4">
                                <div class="card-body">
                                    <h5 class="fw-bold mb-3"><i class="bi bi-building text-maroon me-1"></i> General</h5>
                                    <div class="mb-3">
                                        <label class="form-label">University Name</label>
                                        <input type="text" class="form-control" name="university_name" value="<?= htmlspecialchars($settings['university_name'] ?? '') ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">System Name</label>
                                        <input type="text" class="form-control" name="system_name" value="<?= htmlspecialchars($settings['system_name'] ?? '') ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Workflow Enabled</label>
                                        <select class="form-select" name="dean_workflow_enabled">
                                            <option value="1" <?= ($settings['dean_workflow_enabled'] ?? '1') == '1' ? 'selected' : '' ?>>Enabled</option>
                                            <option value="0" <?= ($settings['dean_workflow_enabled'] ?? '1') == '0' ? 'selected' : '' ?>>Disabled</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="glass-card-static">
                                <div class="card-body">
                                    <h5 class="fw-bold mb-3"><i class="bi bi-shield-check text-maroon me-1"></i> Security</h5>
                                    <div class="mb-3">
                                        <label class="form-label">QR Code Verification</label>
                                        <select class="form-select" name="qr_enabled">
                                            <option value="1" <?= ($settings['qr_enabled'] ?? '1') == '1' ? 'selected' : '' ?>>Enabled</option>
                                            <option value="0" <?= ($settings['qr_enabled'] ?? '1') == '0' ? 'selected' : '' ?>>Disabled</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Signature Required</label>
                                        <select class="form-select" name="signature_required">
                                            <option value="1" <?= ($settings['signature_required'] ?? '1') == '1' ? 'selected' : '' ?>>Required</option>
                                            <option value="0" <?= ($settings['signature_required'] ?? '1') == '0' ? 'selected' : '' ?>>Optional</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="glass-card-static">
                                <div class="card-body">
                                    <h5 class="fw-bold mb-3"><i class="bi bi-envelope text-maroon me-1"></i> SMTP / Email Configuration</h5>
                                    <div class="mb-3">
                                        <label class="form-label">SMTP Host</label>
                                        <input type="text" class="form-control" name="smtp_host" value="<?= htmlspecialchars($settings['smtp_host'] ?? '') ?>" placeholder="smtp.gmail.com">
                                    </div>
                                    <div class="row g-3 mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">SMTP Port</label>
                                            <input type="number" class="form-control" name="smtp_port" value="<?= htmlspecialchars($settings['smtp_port'] ?? '587') ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Encryption</label>
                                            <select class="form-select" name="smtp_encryption">
                                                <option value="tls" <?= ($settings['smtp_encryption'] ?? 'tls') == 'tls' ? 'selected' : '' ?>>TLS</option>
                                                <option value="ssl" <?= ($settings['smtp_encryption'] ?? '') == 'ssl' ? 'selected' : '' ?>>SSL</option>
                                                <option value="none" <?= ($settings['smtp_encryption'] ?? '') == 'none' ? 'selected' : '' ?>>None</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">SMTP Username</label>
                                        <input type="text" class="form-control" name="smtp_username" value="<?= htmlspecialchars($settings['smtp_username'] ?? '') ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">SMTP Password</label>
                                        <div class="password-wrapper">
                                            <input type="password" class="form-control" name="smtp_password" value="<?= htmlspecialchars($settings['smtp_password'] ?? '') ?>">
                                            <button type="button" class="password-toggle-btn" tabindex="-1"><i class="bi bi-eye"></i></button>
                                        </div>
                                    </div>
                                    <div class="row g-3 mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">From Email</label>
                                            <input type="email" class="form-control" name="from_email" value="<?= htmlspecialchars($settings['from_email'] ?? '') ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">From Name</label>
                                            <input type="text" class="form-control" name="from_name" value="<?= htmlspecialchars($settings['from_name'] ?? 'HRMU Clearance System') ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-maroon btn-lg"><i class="bi bi-save"></i> Save Settings</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Mobile sidebar backdrop -->
    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $('#settingsForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: 'settings.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    showToast('success', res.message);
                } else {
                    showToast('danger', res.message);
                }
            }
        });
    });

    $(document).ready(function() {
    });

    function showToast(type, message) {
        var bg = type === 'success' ? 'bg-success' : 'bg-danger';
        var toast = '<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div class="toast align-items-center text-white ' + bg + ' border-0 show" role="alert"><div class="d-flex"><div class="toast-body">' + message + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>';
        $('body').append(toast);
        setTimeout(function() { $(toast).remove(); }, 3000);
    }
    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
