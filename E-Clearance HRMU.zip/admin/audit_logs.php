<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('admin');

$db = getDB();
$user = getCurrentUser();
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Logs - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Administration</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="users.php"><i class="bi bi-people"></i><span> Users</span></a></li>
                <li class="nav-item"><a class="nav-link" href="departments.php"><i class="bi bi-building"></i><span> College Departments</span></a></li>
                <li class="nav-item"><a class="nav-link" href="offices.php"><i class="bi bi-door-open"></i><span> College Offices</span></a></li>
                <li class="nav-item"><a class="nav-link" href="workflow.php"><i class="bi bi-diagram-3"></i><span> Workflow</span></a></li>
                <li class="nav-item"><a class="nav-link" href="clearance_periods.php"><i class="bi bi-calendar-event"></i><span> Periods</span></a></li>
                <li class="nav-item"><a class="nav-link" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link" href="settings.php"><i class="bi bi-toggles"></i><span> Settings</span></a></li>
                <li class="nav-item"><a class="nav-link active" href="audit_logs.php"><i class="bi bi-journal-text"></i><span> Audit Logs</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Header -->
            <?php
            $pageTitle = 'Audit Logs';
            $pageIcon = 'bi-journal-text';
            include __DIR__ . '/../includes/top_header.php';
            ?>

            <!-- Page Content -->
            <div class="page-content animate-fade-in-up">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0"><i class="bi bi-journal-text text-maroon me-1"></i> Audit Logs</h4>
                </div>

                <div class="glass-card-static">
                    <div class="card-body">
                        <div class="row g-3 mb-3">
                            <div class="col-md-3">
                                <input type="text" class="form-control" id="filterUser" placeholder="Filter by username">
                            </div>
                            <div class="col-md-2">
                                <select class="form-select" id="filterAction">
                                    <option value="">All Actions</option>
                                    <option value="login">Login</option>
                                    <option value="create">Create</option>
                                    <option value="update">Update</option>
                                    <option value="delete">Delete</option>
                                    <option value="sign">Sign</option>
                                    <option value="reject">Reject</option>
                                    <option value="verify">Verify</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <select class="form-select" id="filterModule">
                                    <option value="">All Modules</option>
                                    <option value="auth">Auth</option>
                                    <option value="users">Users</option>
                                    <option value="clearance">Clearance</option>
                                    <option value="settings">Settings</option>
                                    <option value="workflow">Workflow</option>
                                    <option value="departments">Departments</option>
                                    <option value="offices">Offices</option>
                                    <option value="periods">Periods</option>
                                    <option value="verification">Verification</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input type="date" class="form-control" id="filterDate">
                            </div>
                            <div class="col-md-1">
                                <button class="btn btn-outline-maroon w-100" onclick="clearFilters()"><i class="bi bi-x-lg"></i></button>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table id="logsTable" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Role</th>
                                        <th>Action</th>
                                        <th>Module</th>
                                        <th>Description</th>
                                        <th>IP Address</th>
                                        <th>Timestamp</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile sidebar backdrop -->
    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
    $(document).ready(function() {
        var table = $('#logsTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: 'users_ajax.php',
                data: function(d) {
                    d.action = 'list_logs';
                    d.filter_user = $('#filterUser').val();
                    d.filter_action = $('#filterAction').val();
                    d.filter_module = $('#filterModule').val();
                    d.filter_date = $('#filterDate').val();
                }
            },
            columns: [
                { data: 'id' },
                { data: 'username' },
                { data: 'role_name' },
                { data: 'action_type' },
                { data: 'module' },
                { data: 'description' },
                { data: 'ip_address' },
                { data: 'created_at' }
            ],
            order: [[0, 'desc']],
            pageLength: 50,
            lengthMenu: [[25, 50, 100, 200], [25, 50, 100, 200]]
        });

        $('#filterUser, #filterAction, #filterModule, #filterDate').on('change keyup', function() {
            table.draw();
        });

    });

    function clearFilters() {
        $('#filterUser, #filterAction, #filterModule, #filterDate').val('');
        $('#logsTable').DataTable().draw();
    }
    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
