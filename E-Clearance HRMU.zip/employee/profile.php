<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
redirect(BASE_URL . 'profile.php');
