<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/clearance_display.php';
requireLogin();
header('Content-Type: application/json');

$action = $_REQUEST['action'] ?? '';
if ($action === 'get_certificate') {
    requireAnyRole(['employee', 'admin', 'signatory']);
} else {
    requireRole('employee');
}

$db = getDB();
$user = getCurrentUser();
$userId = (int)$user['id'];
$role = getCurrentRole();
$empId = null;
$empDeptId = null;

if ($role === 'employee') {
    $stmt = $db->prepare("SELECT id, department_id FROM employees WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $emp = $stmt->get_result()->fetch_assoc();
    if (!$emp) {
        echo json_encode(['success' => false, 'message' => 'Employee record not found']);
        exit;
    }
    $empId = (int)$emp['id'];
    $empDeptId = $emp['department_id'] ? (int)$emp['department_id'] : null;
}

if ($action === 'list') {
    $stmt = $db->prepare("
        SELECT cr.*, cp.period_name
        FROM clearance_requests cr
        JOIN clearance_periods cp ON cr.period_id = cp.id
        WHERE cr.employee_id = ?
        ORDER BY cr.created_at DESC
    ");
    $stmt->bind_param("i", $empId);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $statusMap = [
            'draft' => 'secondary',
            'pending' => 'secondary',
            'in_progress' => 'warning',
            'completed' => 'success',
            'rejected' => 'danger',
            'revoked' => 'danger'
        ];
        $statusLabel = ucfirst(str_replace('_', ' ', $row['status']));
        $progress = $row['total_steps'] > 0 ? round(($row['current_step'] / $row['total_steps']) * 100) : 0;
        $actions = '<button class="btn btn-sm btn-outline-primary" onclick="viewDetails(' . $row['id'] . ')" title="View Details"><i class="bi bi-eye"></i></button>';
        $actions .= ' <a href="certificate.php?id=' . $row['id'] . '" class="btn btn-sm btn-outline-info" title="View Certificate"><i class="bi bi-file-earmark-text"></i></a>';
        if ($row['status'] === 'completed' && $row['pdf_path']) {
            $actions .= ' <a href="../' . $row['pdf_path'] . '" target="_blank" class="btn btn-sm btn-outline-success" title="Download PDF"><i class="bi bi-download"></i></a>';
        }
        if (in_array($row['status'], ['draft', 'pending', 'in_progress'])) {
            $actions .= ' <button class="btn btn-sm btn-outline-danger" onclick="cancelRequest(' . $row['id'] . ')" title="Cancel"><i class="bi bi-x-circle"></i></button>';
        }
        $data[] = [
            'clearance_code' => '<code>' . htmlspecialchars($row['clearance_code']) . '</code>',
            'period_name' => htmlspecialchars($row['period_name']),
            'progress' => '<div class="progress" style="height: 6px;"><div class="progress-bar bg-success" style="width: ' . $progress . '%"></div></div><small class="text-muted">' . $row['current_step'] . '/' . $row['total_steps'] . ' steps</small>',
            'status' => '<span class="badge bg-' . ($statusMap[$row['status']] ?? 'secondary') . '">' . $statusLabel . '</span>',
            'submitted_at' => $row['submitted_at'] ? formatDate($row['submitted_at']) : formatDate($row['created_at']),
            'actions' => $actions
        ];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'create_request') {
    $periodId = (int)($_POST['period_id'] ?? 0);
    if (empty($periodId)) {
        echo json_encode(['success' => false, 'message' => 'Please select a clearance period']);
        exit;
    }

    $stmt = $db->prepare("SELECT id FROM clearance_periods WHERE id = ? AND is_active = 1");
    $stmt->bind_param("i", $periodId);
    $stmt->execute();
    $period = $stmt->get_result()->fetch_assoc();
    if (!$period) {
        echo json_encode(['success' => false, 'message' => 'Invalid clearance period']);
        exit;
    }

    $stmt = $db->prepare("SELECT id FROM clearance_requests WHERE employee_id = ? AND period_id = ? AND status NOT IN ('completed', 'revoked')");
    $stmt->bind_param("ii", $empId, $periodId);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'You already have an active clearance request for this period']);
        exit;
    }

    $clearanceCode = generateCode('CLR');

    $stmt = $db->prepare("
        SELECT w.id FROM clearance_workflow w
        WHERE (w.period_id = ? OR w.period_id IS NULL) AND w.is_active = 1
        ORDER BY w.period_id DESC LIMIT 1
    ");
    $stmt->bind_param("i", $periodId);
    $stmt->execute();
    $wf = $stmt->get_result()->fetch_assoc();

    if (!$wf) {
        echo json_encode(['success' => false, 'message' => 'No active workflow found for this period']);
        exit;
    }
    $wfId = (int)$wf['id'];

    $stmt = $db->prepare("SELECT id, step_order, is_dynamic, dynamic_field, office_id FROM workflow_steps WHERE workflow_id = ? ORDER BY step_order ASC");
    $stmt->bind_param("i", $wfId);
    $stmt->execute();
    $stepsResult = $stmt->get_result();
    $totalSteps = $stepsResult->num_rows;
    $minStepOrder = null;

    if ($totalSteps === 0) {
        echo json_encode(['success' => false, 'message' => 'Workflow has no steps configured']);
        exit;
    }

    $db->begin_transaction();
    try {
        $purpose = trim($_POST['purpose'] ?? '');
        $stmt = $db->prepare("INSERT INTO clearance_requests (employee_id, period_id, workflow_id, clearance_code, status, current_step, total_steps, submitted_at, purpose) VALUES (?, ?, ?, ?, 'in_progress', 0, ?, NOW(), ?)");
        $stmt->bind_param("iiisis", $empId, $periodId, $wfId, $clearanceCode, $totalSteps, $purpose);
        $stmt->execute();
        $clearanceId = $db->insert_id;

        $totalSignatures = 0;
        while ($step = $stepsResult->fetch_assoc()) {
            $stepOrder = (int)$step['step_order'];
            if ($minStepOrder === null || $stepOrder < $minStepOrder) {
                $minStepOrder = $stepOrder;
            }
            $stepId = (int)$step['id'];
            $stepOfficeId = (int)($step['office_id'] ?? 0);
            $isDynamic = (int)($step['is_dynamic'] ?? 0);
            $dynamicField = $step['dynamic_field'] ?? '';
            $actionStatus = 'pending';

            if ($isDynamic && (empty($dynamicField) || $dynamicField === 'department_id') && $empDeptId) {
                if ($stepOfficeId === 0) {
                    $sigStmt = $db->prepare("
                        SELECT sp.user_id FROM signatory_profiles sp
                        JOIN offices o ON sp.office_id = o.id
                        WHERE o.office_code LIKE 'DEAN_%' AND sp.department_id = ? AND sp.is_active = 1
                    ");
                    $sigStmt->bind_param("i", $empDeptId);
                } else {
                    $sigStmt = $db->prepare("
                        SELECT sp.user_id FROM signatory_profiles sp
                        JOIN workflow_steps ws ON ws.id = ?
                        WHERE sp.office_id = ws.office_id AND sp.department_id = ? AND sp.is_active = 1
                    ");
                    $sigStmt->bind_param("ii", $stepId, $empDeptId);
                }
            } else {
                $sigStmt = $db->prepare("
                    SELECT sp.user_id FROM signatory_profiles sp
                    JOIN workflow_steps ws ON ws.office_id = sp.office_id
                    WHERE ws.id = ? AND sp.is_active = 1
                ");
                $sigStmt->bind_param("i", $stepId);
            }
            $sigStmt->execute();
            $signatoryIds = $sigStmt->get_result();

            while ($sig = $signatoryIds->fetch_assoc()) {
                $sigUserId = (int)$sig['user_id'];
                $insertStmt = $db->prepare("INSERT INTO clearance_signatures (clearance_id, step_id, signatory_id, action) VALUES (?, ?, ?, ?)");
                $insertStmt->bind_param("iiis", $clearanceId, $stepId, $sigUserId, $actionStatus);
                $insertStmt->execute();
                $totalSignatures++;

                if ($stepOrder === $minStepOrder) {
                    createNotification($sigUserId, 'New Clearance Request', "Clearance $clearanceCode requires your signature", 'info', 'signatory/pending.php?view=' . $clearanceId);
                }
            }
        }

        if ($totalSignatures === 0) {
            throw new Exception('No signatories assigned for this workflow. Contact the administrator.');
        }

        $stmt = $db->prepare("UPDATE clearance_requests SET current_step = 1 WHERE id = ?");
        $stmt->bind_param("i", $clearanceId);
        $stmt->execute();

        logAudit('create', 'clearance', "Employee created clearance request: $clearanceCode");
        $db->commit();
        echo json_encode(['success' => true, 'message' => 'Clearance request submitted successfully']);
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to create clearance request']);
    }
    exit;
}

if ($action === 'view_details') {
    $clearanceId = (int)($_REQUEST['clearance_id'] ?? 0);
    $stmt = $db->prepare("
        SELECT cr.*, cp.period_name
        FROM clearance_requests cr
        JOIN clearance_periods cp ON cr.period_id = cp.id
        WHERE cr.id = ? AND cr.employee_id = ?
    ");
    $stmt->bind_param("ii", $clearanceId, $empId);
    $stmt->execute();
    $cr = $stmt->get_result()->fetch_assoc();

    if (!$cr) {
        echo json_encode(['success' => false, 'message' => 'Clearance request not found']);
        exit;
    }

    $statusMap = [
        'draft' => 'secondary',
        'pending' => 'secondary',
        'in_progress' => 'warning',
        'completed' => 'success',
        'rejected' => 'danger',
        'revoked' => 'danger'
    ];

    $stmt = $db->prepare("
        SELECT cs.*, ws.step_order, ws.office_id, ws.is_dynamic,
               COALESCE(o_ws.office_name, o_sp.office_name) AS office_name,
               COALESCE(o_ws.office_code, o_sp.office_code) AS office_code,
               sp.designation AS profile_designation,
               sd.dept_name AS signatory_dept_name,
               u.first_name, u.middle_name, u.last_name, cs.signed_at, cs.remarks, cs.action AS sig_action
        FROM clearance_signatures cs
        JOIN workflow_steps ws ON cs.step_id = ws.id
        LEFT JOIN signatory_profiles sp ON cs.signatory_id = sp.user_id
            AND sp.is_active = 1
            AND (ws.office_id IS NULL OR sp.office_id = ws.office_id)
        LEFT JOIN offices o_ws ON ws.office_id = o_ws.id
        LEFT JOIN offices o_sp ON sp.office_id = o_sp.id
        LEFT JOIN departments sd ON sp.department_id = sd.id
        LEFT JOIN users u ON cs.signatory_id = u.id
        WHERE cs.clearance_id = ?
        ORDER BY ws.step_order ASC, cs.id ASC
    ");
    $stmt->bind_param("i", $clearanceId);
    $stmt->execute();
    $stepsResult = $stmt->get_result();

    $steps = [];
    $seenSteps = [];
    while ($s = $stepsResult->fetch_assoc()) {
        $key = $s['step_order'] . '_' . $s['office_id'];
        $middleInit = !empty($s['middle_name']) ? ' ' . mb_substr($s['middle_name'], 0, 1) . '.' : '';
        if (!isset($seenSteps[$key])) {
            $seenSteps[$key] = true;
            $isDynamic = (int)($s['is_dynamic'] ?? 0) === 1;
            $accountability = resolveAccountabilityArea(
                $s['office_name'] ?? null,
                $s['office_code'] ?? null,
                $s['signatory_dept_name'] ?? null,
                $isDynamic
            );
            $designation = resolveSignatoryDesignation(
                $s['profile_designation'] ?? null,
                $s['office_name'] ?? null,
                $s['office_code'] ?? null
            );
            $steps[] = [
                'step_order' => $s['step_order'],
                'office_name' => htmlspecialchars($accountability),
                'designation' => htmlspecialchars($designation),
                'signatory_name' => $s['first_name'] ? htmlspecialchars($s['first_name'] . $middleInit . ' ' . $s['last_name']) : null,
                'action' => $s['sig_action'],
                'remarks' => htmlspecialchars($s['remarks'] ?? ''),
                'signed_at' => $s['signed_at'] ? formatDate($s['signed_at']) : null
            ];
        } else {
            $lastIdx = count($steps) - 1;
            if ($s['sig_action'] === 'signed' && $steps[$lastIdx]['action'] !== 'signed') {
                $steps[$lastIdx]['action'] = 'signed';
                $steps[$lastIdx]['signatory_name'] = $s['first_name'] ? htmlspecialchars($s['first_name'] . $middleInit . ' ' . $s['last_name']) : null;
                $steps[$lastIdx]['signed_at'] = $s['signed_at'] ? formatDate($s['signed_at']) : null;
                $steps[$lastIdx]['remarks'] = htmlspecialchars($s['remarks'] ?? '');
            } elseif ($s['sig_action'] === 'pending' && $steps[$lastIdx]['action'] !== 'signed') {
                $steps[$lastIdx]['action'] = 'pending';
            }
        }
    }

    foreach ($steps as $idx => &$step) {
        $allPreviousSigned = true;
        for ($i = 0; $i < $idx; $i++) {
            if ($steps[$i]['action'] !== 'signed') {
                $allPreviousSigned = false;
                break;
            }
        }
        $step['is_current'] = $step['action'] === 'pending' && $allPreviousSigned;
    }
    unset($step);

    $data = [
        'id' => $cr['id'],
        'clearance_code' => htmlspecialchars($cr['clearance_code']),
        'period_name' => htmlspecialchars($cr['period_name']),
        'status' => $cr['status'],
        'status_label' => '<span class="badge bg-' . ($statusMap[$cr['status']] ?? 'secondary') . '">' . ucfirst(str_replace('_', ' ', $cr['status'])) . '</span>',
        'submitted_at' => $cr['submitted_at'] ? formatDate($cr['submitted_at']) : formatDate($cr['created_at']),
        'completed_at' => $cr['completed_at'] ? formatDate($cr['completed_at']) : null,
        'pdf_path' => $cr['pdf_path'],
        'purpose' => htmlspecialchars($cr['purpose'] ?? ''),
        'steps' => $steps,
        'current_step' => $cr['current_step'],
        'total_steps' => $cr['total_steps']
    ];

    echo json_encode(['success' => true, 'data' => $data]);
    exit;
}

if ($action === 'get_certificate') {
    $clearanceId = (int)($_GET['clearance_id'] ?? 0);
    if ($role === 'employee') {
        $stmt = $db->prepare("
            SELECT cr.*, cp.period_name, cp.academic_year, cp.semester,
                   u.first_name, u.middle_name, u.last_name, u.email,
                   e.employee_id, e.position_title, e.employee_type, e.classification,
                   d.dept_name, d.dept_code
            FROM clearance_requests cr
            JOIN clearance_periods cp ON cr.period_id = cp.id
            JOIN employees e ON cr.employee_id = e.id
            JOIN users u ON e.user_id = u.id
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE cr.id = ? AND e.user_id = ?
        ");
        $stmt->bind_param("ii", $clearanceId, $userId);
    } else {
        $stmt = $db->prepare("
            SELECT cr.*, cp.period_name, cp.academic_year, cp.semester,
                   u.first_name, u.middle_name, u.last_name, u.email,
                   e.employee_id, e.position_title, e.employee_type, e.classification,
                   d.dept_name, d.dept_code
            FROM clearance_requests cr
            JOIN clearance_periods cp ON cr.period_id = cp.id
            JOIN employees e ON cr.employee_id = e.id
            JOIN users u ON e.user_id = u.id
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE cr.id = ?
        ");
        $stmt->bind_param("i", $clearanceId);
    }
    $stmt->execute();
    $cr = $stmt->get_result()->fetch_assoc();
    if (!$cr) {
        echo json_encode(['success' => false, 'message' => 'Clearance not found']);
        exit;
    }
    $stmt = $db->prepare("
        SELECT cs.*, ws.step_order, ws.office_id, ws.is_dynamic,
               COALESCE(o_ws.office_name, o_sp.office_name) AS office_name,
               COALESCE(o_ws.office_code, o_sp.office_code) AS office_code,
               sp.designation AS profile_designation,
               COALESCE(NULLIF(cs.signature_image, ''), sp.signature_image) AS signatory_image,
               sd.dept_name AS signatory_dept_name,
               u2.first_name AS signatory_first, u2.middle_name AS signatory_middle, u2.last_name AS signatory_last
        FROM clearance_signatures cs
        JOIN workflow_steps ws ON cs.step_id = ws.id
        LEFT JOIN signatory_profiles sp ON cs.signatory_id = sp.user_id
            AND sp.is_active = 1
            AND (ws.office_id IS NULL OR sp.office_id = ws.office_id)
        LEFT JOIN offices o_ws ON ws.office_id = o_ws.id
        LEFT JOIN offices o_sp ON sp.office_id = o_sp.id
        LEFT JOIN departments sd ON sp.department_id = sd.id
        LEFT JOIN users u2 ON cs.signatory_id = u2.id
        WHERE cs.clearance_id = ?
        ORDER BY ws.step_order ASC, cs.id ASC
    ");
    $stmt->bind_param("i", $clearanceId);
    $stmt->execute();
    $steps = $stmt->get_result();
    $sigList = [];
    while ($s = $steps->fetch_assoc()) {
        $isDynamic = (int)($s['is_dynamic'] ?? 0) === 1;
        $s['accountability_area'] = resolveAccountabilityArea(
            $s['office_name'] ?? null,
            $s['office_code'] ?? null,
            $s['signatory_dept_name'] ?? null,
            $isDynamic
        );
        $s['display_designation'] = resolveSignatoryDesignation(
            $s['profile_designation'] ?? null,
            $s['office_name'] ?? null,
            $s['office_code'] ?? null
        );
        $sigList[] = $s;
    }
    $empTypeMap = [
        'regular_instructor' => 'Regular Instructor',
        'visiting_lecturer' => 'Visiting Lecturer',
        'non_teaching' => 'Non-Teaching Staff'
    ];
    $data = [
        'clearance' => [
            'id' => $cr['id'],
            'clearance_code' => $cr['clearance_code'],
            'status' => $cr['status'],
            'current_step' => $cr['current_step'],
            'total_steps' => $cr['total_steps'],
            'period_name' => $cr['period_name'],
            'academic_year' => $cr['academic_year'],
            'semester' => $cr['semester'],
            'submitted_at' => $cr['submitted_at'] ? formatDate($cr['submitted_at']) : formatDate($cr['created_at']),
            'completed_at' => $cr['completed_at'] ? formatDate($cr['completed_at']) : null,
            'pdf_path' => $cr['pdf_path'],
            'purpose' => $cr['purpose'] ?? '',
        ],
        'employee' => [
            'employee_id' => $cr['employee_id'],
            'first_name' => $cr['first_name'],
            'middle_name' => $cr['middle_name'] ?? '',
            'last_name' => $cr['last_name'],
            'email' => $cr['email'],
            'position_title' => $cr['position_title'] ?? 'N/A',
            'employee_type' => $empTypeMap[$cr['employee_type']] ?? ucfirst(str_replace('_', ' ', $cr['employee_type'])),
            'classification' => $cr['classification'] ?? 'N/A',
            'dept_name' => $cr['dept_name'] ?? 'N/A',
            'dept_code' => $cr['dept_code'] ?? '',
        ],
        'signatures' => $sigList
    ];
    echo json_encode(['success' => true, 'data' => $data]);
    exit;
}

if ($action === 'cancel_request') {
    $clearanceId = (int)($_POST['clearance_id'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');

    $stmt = $db->prepare("SELECT id, clearance_code, status FROM clearance_requests WHERE id = ? AND employee_id = ?");
    $stmt->bind_param("ii", $clearanceId, $empId);
    $stmt->execute();
    $cr = $stmt->get_result()->fetch_assoc();
    if (!$cr) {
        echo json_encode(['success' => false, 'message' => 'Clearance request not found']);
        exit;
    }

    if (!in_array($cr['status'], ['draft', 'pending', 'in_progress'])) {
        echo json_encode(['success' => false, 'message' => 'This clearance cannot be cancelled']);
        exit;
    }

    $stmt = $db->prepare("UPDATE clearance_requests SET status = 'revoked' WHERE id = ?");
    $stmt->bind_param("i", $clearanceId);
    if ($stmt->execute()) {
        $reasonStr = 'Cancelled by employee: ' . substr($reason, 0, 500);
        $stmt2 = $db->prepare("UPDATE clearance_signatures SET action = 'returned', remarks = CONCAT_WS(' | ', remarks, ?) WHERE clearance_id = ? AND action = 'pending'");
        $stmt2->bind_param("si", $reasonStr, $clearanceId);
        $stmt2->execute();
        logAudit('update', 'clearance', "Employee cancelled clearance: {$cr['clearance_code']} - $reason");
        echo json_encode(['success' => true, 'message' => 'Clearance request cancelled']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to cancel clearance request']);
    }
    exit;
}

if ($action === 'update_profile') {
    echo json_encode(['success' => false, 'message' => 'Use the profile page to update your profile']);
    exit;
}

if ($action === 'resubmit_clearance') {
    $clearanceId = (int)($_POST['clearance_id'] ?? 0);
    $stmt = $db->prepare("SELECT id, clearance_code, status FROM clearance_requests WHERE id = ? AND employee_id = ?");
    $stmt->bind_param("ii", $clearanceId, $empId);
    $stmt->execute();
    $cr = $stmt->get_result()->fetch_assoc();
    if (!$cr) {
        echo json_encode(['success' => false, 'message' => 'Clearance request not found']);
        exit;
    }
    if ($cr['status'] !== 'in_progress') {
        echo json_encode(['success' => false, 'message' => 'Only in-progress clearances can be resubmitted']);
        exit;
    }

    $stmt = $db->prepare("SELECT COUNT(*) as c FROM clearance_signatures WHERE clearance_id = ? AND action = 'returned'");
    $stmt->bind_param("i", $clearanceId);
    $stmt->execute();
    if ((int)$stmt->get_result()->fetch_assoc()['c'] === 0) {
        echo json_encode(['success' => false, 'message' => 'No returned signatures to resubmit']);
        exit;
    }

    $stmt = $db->prepare("UPDATE clearance_signatures SET action = 'pending', remarks = CONCAT_WS(' | ', remarks, 'Resubmitted by employee') WHERE clearance_id = ? AND action = 'returned'");
    $stmt->bind_param("i", $clearanceId);
    if ($stmt->execute()) {
        logAudit('update', 'clearance', "Employee resubmitted clearance: {$cr['clearance_code']}");
        echo json_encode(['success' => true, 'message' => 'Clearance resubmitted for review']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to resubmit clearance']);
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
