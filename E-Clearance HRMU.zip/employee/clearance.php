<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('employee');

$db = getDB();
$user = getCurrentUser();
$userId = (int)$user['id'];
$userInitial = strtoupper(substr($user['first_name'],0,1)) . strtoupper(substr($user['last_name'],0,1));
require_once __DIR__ . '/../includes/header.php';
$stmt = $db->prepare("SELECT * FROM employees WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$emp = $stmt->get_result()->fetch_assoc();
if (!$emp) {
    die("Employee record not found. Contact administrator.");
}
$empId = $emp['id'];
$periods = $db->query("SELECT id, period_name FROM clearance_periods WHERE is_active = 1 AND (status = 'active' OR status = 'pending') ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Clearance - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Services</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link active" href="clearance.php"><i class="bi bi-file-earmark-text"></i><span> My Clearance</span></a></li>
                <li class="nav-item"><a class="nav-link" href="profile.php"><i class="bi bi-person-circle"></i><span> Profile</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <div class="main-content">
            <header class="top-header">
                <div class="d-flex align-items-center gap-2">
                    <button class="sidebar-toggle" onclick="document.getElementById('appSidebar').classList.toggle('show')">
                        <i class="bi bi-list"></i>
                    </button>
                    <div class="page-title">
                        <i class="bi bi-file-earmark-text"></i> My Clearance
                    </div>
                </div>
                <div class="header-actions">
                    <a class="position-relative text-decoration-none text-dark me-3" href="<?= $notifLink ?>" title="Notifications">
                        <i class="bi bi-bell fs-5"></i>
                        <?php if ($notifCount > 0): ?>
                        <span class="notif-count"><?= $notifCount > 9 ? '9+' : $notifCount ?></span>
                        <?php endif; ?>
                    </a>
                    <div class="dropdown user-dropdown">
                        <div class="user-avatar" data-bs-toggle="dropdown" role="button" style="overflow: hidden; padding: 0;">
                            <?= getUserAvatarInner($user) ?>
                        </div>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><span class="dropdown-item-text fw-bold"><?= htmlspecialchars($_SESSION['full_name']) ?></span></li>
                            <li><span class="dropdown-item-text text-muted small">Employee</span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../profile.php"><i class="bi bi-person"></i> Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <div class="page-content animate-fade-in-up">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0"><i class="bi bi-file-earmark-text"></i> My Clearance Requests</h4>
                    <button class="btn btn-maroon" data-bs-toggle="modal" data-bs-target="#newClearanceModal">
                        <i class="bi bi-plus-lg"></i> New Clearance Request
                    </button>
                </div>

                <div class="glass-card-static">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="clearanceTable" class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Code</th>
                                        <th>Period</th>
                                        <th>Progress</th>
                                        <th>Status</th>
                                        <th>Submitted</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="newClearanceModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">New Clearance Request</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="newClearanceForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="create_request">
                        <div class="mb-3">
                            <label class="form-label">Clearance Period</label>
                            <select class="form-select" name="period_id" required>
                                <option value="">Select Period</option>
                                <?php while ($p = $periods->fetch_assoc()): ?>
                                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['period_name']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Purpose of Clearance</label>
                            <textarea class="form-control" name="purpose" rows="3" placeholder="e.g., Resignation, Retirement, Transfer, End of Contract, etc."></textarea>
                        </div>
                        <p class="text-muted small mb-0">Submitting a clearance will route it through all required signatory offices.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-maroon" id="submitClearanceBtn">Submit Request</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="viewClearanceModal" tabindex="-1" data-bs-backdrop="static">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Clearance Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="clearanceDetailsBody">
                    <div class="text-center py-5">
                        <div class="spinner-border text-primary" role="status"></div>
                        <p class="mt-2 text-muted">Loading details...</p>
                    </div>
                </div>
                <div class="modal-footer" id="clearanceDetailsFooter">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="cancelModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Cancel Clearance Request</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="cancelForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="cancel_request">
                        <input type="hidden" name="clearance_id" id="cancelClearanceId">
                        <p>Are you sure you want to cancel this clearance request?</p>
                        <div class="mb-3">
                            <label class="form-label">Reason for cancellation</label>
                            <textarea class="form-control" name="reason" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger" id="cancelClearanceBtn">Confirm Cancellation</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
    $(document).ready(function() {
        var table = $('#clearanceTable').DataTable({
            ajax: {
                url: 'clearance_ajax.php',
                data: { action: 'list' }
            },
            columns: [
                { data: 'clearance_code' },
                { data: 'period_name' },
                { data: 'progress' },
                { data: 'status' },
                { data: 'submitted_at' },
                { data: 'actions', orderable: false }
            ],
            order: [[4, 'desc']],
            pageLength: 25,
            lengthChange: false
        });

        $('#newClearanceForm').on('submit', function(e) {
            e.preventDefault();
            var btn = $('#submitClearanceBtn');
            btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Submitting...');
            $.ajax({
                url: 'clearance_ajax.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        $('#newClearanceModal').modal('hide');
                        table.ajax.reload();
                        showToast('success', res.message);
                    } else {
                        showToast('danger', res.message);
                    }
                },
                error: function() {
                    showToast('danger', 'Request failed');
                },
                complete: function() {
                    btn.prop('disabled', false).html('Submit Request');
                }
            });
        });

        $('#cancelForm').on('submit', function(e) {
            e.preventDefault();
            var btn = $('#cancelClearanceBtn');
            btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Cancelling...');
            $.ajax({
                url: 'clearance_ajax.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        $('#cancelModal').modal('hide');
                        table.ajax.reload();
                        showToast('success', res.message);
                    } else {
                        showToast('danger', res.message);
                    }
                },
                error: function() {
                    showToast('danger', 'Request failed');
                },
                complete: function() {
                    btn.prop('disabled', false).html('Confirm Cancellation');
                }
            });
        });

        $('#newClearanceModal').on('hidden.bs.modal', function() {
            $('#newClearanceForm')[0].reset();
        });
    });

    function viewDetails(id) {
        $('#clearanceDetailsBody').html('<div class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><p class="mt-2 text-muted">Loading details...</p></div>');
        $('#clearanceDetailsFooter').html('<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>');
        $('#viewClearanceModal').modal('show');
        $.ajax({
            url: 'clearance_ajax.php',
            data: { action: 'view_details', clearance_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    renderDetails(res.data);
                } else {
                    $('#clearanceDetailsBody').html('<div class="alert alert-danger">' + res.message + '</div>');
                }
            },
            error: function() {
                $('#clearanceDetailsBody').html('<div class="alert alert-danger">Failed to load details</div>');
            }
        });
    }

    function renderDetails(data) {
        var statusClass = data.status === 'completed' ? 'success' : (data.status === 'in_progress' ? 'warning' : (data.status === 'rejected' || data.status === 'revoked' ? 'danger' : 'secondary'));
        var html = '';
        html += '<div class="row mb-4">';
        html += '<div class="col-md-6"><strong>Clearance Code:</strong> <code>' + data.clearance_code + '</code></div>';
        html += '<div class="col-md-6"><strong>Period:</strong> ' + data.period_name + '</div>';
        html += '<div class="col-md-6 mt-2"><strong>Status:</strong> <span class="badge bg-' + statusClass + '">' + data.status_label + '</span></div>';
        html += '<div class="col-md-6 mt-2"><strong>Submitted:</strong> ' + data.submitted_at + '</div>';
        if (data.completed_at) {
            html += '<div class="col-md-6 mt-2"><strong>Completed:</strong> ' + data.completed_at + '</div>';
        }
        html += '</div>';

        if (data.steps && data.steps.length > 0) {
            html += '<h6 class="fw-bold mb-3">Clearance Workflow Progress</h6>';
            html += '<div class="timeline">';
            var total = data.steps.length;
            $.each(data.steps, function(i, step) {
                var isCompleted = step.action === 'signed';
                var isRejected = step.action === 'rejected';
                var isCurrent = step.is_current === true;
                var icon = isCompleted ? 'bi-check-circle-fill text-success' : (isRejected ? 'bi-x-circle-fill text-danger' : (isCurrent ? 'bi-hourglass-split text-warning' : 'bi-circle text-secondary'));
                var bgClass = isCompleted ? 'border-success' : (isRejected ? 'border-danger' : (isCurrent ? 'border-warning' : 'border-secondary'));
                var label = isCompleted ? 'Signed' : (isRejected ? 'Rejected' : (isCurrent ? 'Current Step' : 'Waiting'));
                html += '<div class="d-flex mb-3">';
                html += '<div class="me-3 text-center" style="width: 32px;">';
                html += '<i class="bi ' + icon + ' fs-4"></i>';
                if (i < total - 1) {
                    html += '<div style="width: 2px; height: 30px; background: #dee2e6; margin: 4px auto;"></div>';
                }
                html += '</div>';
                html += '<div class="flex-grow-1 border rounded p-3 ' + bgClass + '" style="border-left-width: 4px !important;">';
                html += '<div class="d-flex justify-content-between align-items-center">';
                html += '<strong>' + step.office_name + '</strong>';
                html += '<span class="badge bg-' + (isCompleted ? 'success' : (isRejected ? 'danger' : 'secondary')) + '">' + label + '</span>';
                html += '</div>';
                if (step.designation) {
                    html += '<small class="text-muted d-block mt-1">Designation: ' + step.designation + '</small>';
                }
                if (step.signatory_name) {
                    html += '<small class="text-muted d-block mt-1">Signed by: ' + step.signatory_name + '</small>';
                }
                if (step.remarks) {
                    html += '<small class="d-block mt-1"><em>Remarks: ' + step.remarks + '</em></small>';
                }
                if (step.signed_at) {
                    html += '<small class="text-muted d-block mt-1">' + step.signed_at + '</small>';
                }
                html += '</div>';
                html += '</div>';
            });
            html += '</div>';
        } else {
            html += '<p class="text-muted">No workflow steps defined for this clearance.</p>';
        }

        var footerHtml = '<a href="certificate.php?id=' + data.id + '" class="btn btn-outline-info"><i class="bi bi-file-earmark-text"></i> View Certificate</a>';
        if (data.status === 'completed' && data.pdf_path) {
            footerHtml += ' <a href="../' + data.pdf_path + '" target="_blank" class="btn btn-gold"><i class="bi bi-download"></i> Download PDF</a>';
        }
        footerHtml += ' <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>';
        $('#clearanceDetailsFooter').html(footerHtml);

        if (data.status === 'draft' || data.status === 'pending' || data.status === 'in_progress') {
            $('#clearanceDetailsFooter').prepend(
                '<button type="button" class="btn btn-danger me-2" onclick="cancelRequest(' + data.id + ')"><i class="bi bi-x-circle"></i> Cancel Request</button>'
            );
        }

        $('#clearanceDetailsBody').html(html);
    }

    function cancelRequest(id) {
        $('#viewClearanceModal').modal('hide');
        $('#cancelClearanceId').val(id);
        $('#cancelModal').modal('show');
    }

    function showToast(type, message) {
        var bg = type === 'success' ? 'bg-success' : 'bg-danger';
        var toast = '<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div class="toast align-items-center text-white ' + bg + ' border-0 show" role="alert"><div class="d-flex"><div class="toast-body">' + message + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>';
        $('body').append(toast);
        setTimeout(function() { $(toast).remove(); }, 3000);
    }
    </script>
    <style>
    .timeline .border-success { border-left: 4px solid #198754 !important; }
    .timeline .border-warning { border-left: 4px solid #ffc107 !important; }
    .timeline .border-danger { border-left: 4px solid #dc3545 !important; }
    .timeline .border-secondary { border-left: 4px solid #6c757d !important; }
    </style>
    <script src="../assets/js/app.js"></script>
</body>
</html>
