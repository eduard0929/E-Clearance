<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireAnyRole(['employee', 'admin', 'signatory']);

$db = getDB();
$user = getCurrentUser();
$userId = (int)$user['id'];
$userInitial = strtoupper(substr($user['first_name'],0,1)) . strtoupper(substr($user['last_name'],0,1));
require_once __DIR__ . '/../includes/header.php';

$clearanceId = (int)($_GET['id'] ?? 0);
$stmt = $db->prepare("SELECT id FROM employees WHERE user_id = ?"); $stmt->bind_param("i", $userId); $stmt->execute(); $employee = $stmt->get_result()->fetch_assoc();
if (!$employee) die("Employee record not found.");

$empId = $employee['id'];
$empTypeMap = [
    'regular_instructor' => 'Regular Instructor',
    'visiting_lecturer' => 'Visiting Lecturer',
    'non_teaching' => 'Non-Teaching Staff'
];
$universityName = getSetting('university_name') ?: 'Zamboanga Peninsula Polytechnic State University';
$universityName = preg_replace('/^HRMU\s*-\s*/', '', $universityName);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate of Clearance - HRMU</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        @media print { .no-print { display: none !important; } }
        .certificate-container { max-width: 900px; margin: 0 auto; }
        .certificate-border { border: 3px solid #800000; border-radius: 12px; padding: 2.5rem; background: white; position: relative; }
        .certificate-border::before { content: ''; position: absolute; top: 6px; left: 6px; right: 6px; bottom: 6px; border: 1px solid #D4AF37; border-radius: 8px; pointer-events: none; }
        .certificate-title { color: #800000; font-weight: 800; font-size: 1.5rem; letter-spacing: 1px; }
        .certificate-subtitle { color: #555; font-size: 0.9rem; }
        .certificate-seal { width: 80px; height: 80px; background: linear-gradient(135deg, #800000, #a52a2a); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto; color: #D4AF37; font-size: 2.5rem; }
        .info-table td { padding: 0.4rem 0.75rem; border: 1px solid #dee2e6; font-size: 0.9rem; }
        .info-table td:first-child { font-weight: 600; background: #f8f9fa; width: 140px; }
        .status-badge-signed { color: #198754; font-weight: 600; }
        .status-badge-pending { color: #856404; font-weight: 600; }
        .status-badge-current { color: #0d6efd; font-weight: 700; }
        .sig-table thead th {
            background: #f8f9fa;
            color: #800000;
            font-weight: 700;
            font-size: 0.8rem;
            vertical-align: middle;
        }
        .sig-table tbody td {
            color: #212529;
            font-size: 0.85rem;
            vertical-align: middle;
            padding: 0.65rem 0.5rem;
        }
        .sig-table .accountability-cell,
        .sig-table .designation-cell {
            color: #800000;
            font-weight: 600;
            text-align: center;
        }
        .sig-table .official-cell {
            font-weight: 600;
            text-align: left;
        }
        .signature-cell {
            min-height: 52px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.25rem;
        }
        .signature-cell img {
            max-height: 52px;
            max-width: 110px;
            width: auto;
            height: auto;
            object-fit: contain;
            filter: contrast(1.35) brightness(0.85);
        }
        .certificate-watermark { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 8rem; color: rgba(128,0,0,0.03); font-weight: 900; pointer-events: none; z-index: 0; white-space: nowrap; }
        .loading-spinner { display: flex; align-items: center; justify-content: center; min-height: 300px; }
        .not-complete-banner { background: #fff3cd; border: 1px solid #ffc107; border-radius: 8px; padding: 0.75rem 1rem; color: #856404; }
        .sig-placeholder { color: #6c757d; font-style: italic; font-size: 0.85rem; font-weight: 500; }
    </style>
</head>
<body>
    <div class="app-layout">
        <aside class="sidebar no-print" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Services</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="clearance.php"><i class="bi bi-file-earmark-text"></i><span> My Clearance</span></a></li>
                <li class="nav-item"><a class="nav-link" href="profile.php"><i class="bi bi-person-circle"></i><span> Profile</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <div class="main-content">
            <header class="top-header no-print">
                <div class="d-flex align-items-center gap-2">
                    <button class="sidebar-toggle" onclick="document.getElementById('appSidebar').classList.toggle('show')">
                        <i class="bi bi-list"></i>
                    </button>
                    <div class="page-title">
                        <i class="bi bi-file-earmark-text"></i> Certificate of Clearance
                    </div>
                </div>
                <div class="header-actions">
                    <a class="position-relative text-decoration-none text-dark me-3" href="<?= $notifLink ?>" title="Notifications">
                        <i class="bi bi-bell fs-5"></i>
                        <?php if ($notifCount > 0): ?>
                        <span class="notif-count"><?= $notifCount > 9 ? '9+' : $notifCount ?></span>
                        <?php endif; ?>
                    </a>
                    <div class="dropdown user-dropdown">
                        <div class="user-avatar" data-bs-toggle="dropdown" role="button" style="overflow: hidden; padding: 0;">
                            <?= getUserAvatarInner($user) ?>
                        </div>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><span class="dropdown-item-text fw-bold"><?= htmlspecialchars($_SESSION['full_name']) ?></span></li>
                            <li><span class="dropdown-item-text text-muted small">Employee</span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../profile.php"><i class="bi bi-person"></i> Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <div class="page-content animate-fade-in-up">
                <div class="container certificate-container py-4" id="certificateApp">
                    <div class="d-flex justify-content-between align-items-center mb-3 no-print">
                        <a href="clearance.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back to Clearance</a>
                        <div>
                            <button class="btn btn-outline-maroon me-2" onclick="window.print()"><i class="bi bi-printer"></i> Print</button>
                            <a id="downloadPdfBtn" class="btn btn-gold d-none" target="_blank"><i class="bi bi-download"></i> Download PDF</a>
                        </div>
                    </div>

                    <div class="loading-spinner" id="loadingSpinner">
                        <div class="text-center">
                            <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
                            <p class="mt-2 text-muted">Loading certificate...</p>
                        </div>
                    </div>

                    <div id="certificateContent" style="display:none;">
                        <div id="notCompleteBanner" class="not-complete-banner mb-3 d-none">
                            <i class="bi bi-info-circle"></i> <strong>Certificate Pending Completion</strong> &mdash; This certificate will be finalized once all signatories have signed. You are viewing a real-time preview.
                        </div>

                        <div class="certificate-border">
                            <div class="certificate-watermark">HRMU</div>
                            <div class="text-center mb-4 position-relative" style="z-index:1;">
                                <div class="certificate-seal mb-2"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPSU" style="width:64px;height:64px;"></div>
                                <h3 class="certificate-title">CERTIFICATE OF CLEARANCE</h4>
                                <p class="certificate-subtitle mb-1" id="univName"></p>
                                <p class="certificate-subtitle" id="periodName"></p>
                            </div>

                            <div class="position-relative" style="z-index:1;">
                                <table class="table table-bordered info-table mb-4">
                                    <tr><td>Employee Name</td><td id="empName"></td></tr>
                                    <tr><td>Employee ID</td><td id="empId"></td></tr>
                                    <tr><td>Department</td><td id="empDept"></td></tr>
                                    <tr><td>Position</td><td id="empPosition"></td></tr>
                                    <tr><td>Employee Type</td><td id="empType"></td></tr>
                                    <tr><td>Classification</td><td id="empClass"></td></tr>
                                </table>

                                <h6 class="fw-bold mb-2" style="color:#800000;">CLEARANCE SIGNATORIES</h6>
                                <div class="table-responsive">
                                    <table class="table table-bordered text-center sig-table" style="font-size:0.85rem;">
                                        <thead class="table-light">
                                            <tr>
                                                <th style="width:40px;">#</th>
                                                <th>Accountability Area</th>
                                                <th>Clearing Official</th>
                                                <th>Designation</th>
                                                <th style="width:120px;">Signature</th>
                                                <th style="width:110px;">Date Signed</th>
                                            </tr>
                                        </thead>
                                        <tbody id="sigTableBody">
                                            <tr id="sigRowTemplate" style="display:none;">
                                                <td class="step-num"></td>
                                                <td class="office-name"></td>
                                                <td class="official-name"></td>
                                                <td class="designation"></td>
                                                <td class="signature-col"></td>
                                                <td class="date-signed"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="text-center mt-4 pt-3 border-top">
                                    <p class="mb-1" style="font-size:0.85rem;font-style:italic;" id="certText"></p>
                                    <div id="qrContainer" class="mb-2"></div>
                                    <p style="font-size:0.75rem;color:#888;" id="verificationCode"></p>
                                    <p style="font-size:0.7rem;color:#aaa;">This document is electronically generated and verified.</p>
                                    <p style="font-size:0.7rem;color:#aaa;" id="generatedOn"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-backdrop fade no-print" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(document).ready(function() {
        var clearanceId = <?= $clearanceId ?: 0 ?>;
        if (!clearanceId) {
            $('#loadingSpinner').html('<div class="alert alert-danger">No clearance ID provided.</div>');
            return;
        }
        $.ajax({
            url: 'clearance_ajax.php',
            data: { action: 'get_certificate', clearance_id: clearanceId },
            dataType: 'json',
            success: function(res) {
                if (!res.success) {
                    $('#loadingSpinner').html('<div class="alert alert-danger">' + res.message + '</div>');
                    return;
                }
                renderCertificate(res.data);
            },
            error: function() {
                $('#loadingSpinner').html('<div class="alert alert-danger">Failed to load certificate data.</div>');
            }
        });
    });

    function renderCertificate(data) {
        var c = data.clearance;
        var e = data.employee;

        $('#loadingSpinner').hide();
        $('#certificateContent').show();

        $('#univName').text(<?= json_encode($universityName) ?>);
        var periodStr = c.period_name;
        if (c.academic_year) {
            periodStr += ' (' + c.academic_year;
            if (c.semester) periodStr += ' - ' + c.semester;
            periodStr += ')';
        }
        $('#periodName').text('Clearance Period: ' + periodStr);
        var middleInit = e.middle_name ? ' ' + e.middle_name.charAt(0).toUpperCase() + '.' : '';
        $('#empName').text(e.last_name + ', ' + e.first_name + middleInit);
        $('#empId').text(e.employee_id);
        $('#empDept').text(e.dept_name);
        $('#empPosition').text(e.position_title);
        $('#empType').text(e.employee_type);
        $('#empClass').text(e.classification);
        $('#generatedOn').text('Generated on: ' + new Date().toLocaleString());

        if (c.status !== 'completed') {
            $('#notCompleteBanner').removeClass('d-none');
            $('#certText').text('This is a preliminary certificate. It will become official once all signatories have signed.');
            $('#verificationCode').html('Certificate code: <strong>' + c.clearance_code + '</strong> (Pending ' + c.current_step + '/' + c.total_steps + ' steps)');
            $('#qrContainer').html('<img src="../qr.php?code=' + c.clearance_code + '" alt="QR Code" style="width:120px;height:120px;" class="border rounded p-1 opacity-50"><br><span class="badge bg-warning text-dark mt-1">Pending ' + c.current_step + '/' + c.total_steps + ' steps</span>');
        } else {
            var certMiddle = e.middle_name ? ' ' + e.middle_name.charAt(0).toUpperCase() + '.' : '';
            $('#certText').text('This is to certify that ' + e.first_name + certMiddle + ' ' + e.last_name + ' has completed the clearance process as of ' + (c.completed_at || 'N/A') + '.');
            $('#verificationCode').html('Verification Code: <strong>' + c.clearance_code + '</strong> &mdash; Scan QR to verify');
            $('#qrContainer').html('<img src="../qr.php?code=' + c.clearance_code + '" alt="QR Code" style="width:120px;height:120px;" class="border rounded p-1">');
            if (c.pdf_path) {
                $('#downloadPdfBtn').attr('href', '../' + c.pdf_path).removeClass('d-none');
            }
        }

        var tbody = $('#sigTableBody');
        tbody.empty();
        $.each(data.signatures, function(i, sig) {
            var num = i + 1;
            var sigMid = sig.signatory_middle || '';
            var sigMidInit = sigMid ? ' ' + sigMid.charAt(0).toUpperCase() + '.' : '';
            var official = (sig.signatory_last || '') + ', ' + (sig.signatory_first || '') + sigMidInit;
            var accountability = sig.accountability_area || sig.office_name || 'N/A';
            var designation = sig.display_designation || sig.designation || sig.office_name || '---';
            var sigHtml = '';
            var dateHtml = '---';
            var sigImage = sig.signatory_image || sig.signature_image || '';

            if (sig.action === 'signed') {
                if (sigImage) {
                    var imgPath = sigImage.indexOf('assets/') === 0 || sigImage.indexOf('uploads/') === 0
                        ? '../' + sigImage
                        : '../' + sigImage.replace(/^\/+/, '');
                    sigHtml = '<div class="signature-cell"><img src="' + imgPath + '" alt="Signature"></div>';
                } else {
                    sigHtml = '<span class="status-badge-signed"><i class="bi bi-check-circle-fill"></i> Signed</span>';
                }
                dateHtml = sig.signed_at ? new Date(sig.signed_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '---';
            } else if (sig.step_order === c.current_step || (c.status === 'in_progress' && sig.step_order === c.current_step + 1)) {
                sigHtml = '<span class="status-badge-current"><i class="bi bi-hourglass-split"></i> Current</span>';
            } else {
                sigHtml = '<span class="sig-placeholder"><i class="bi bi-dash-circle"></i> Pending</span>';
            }

            tbody.append(
                '<tr>' +
                    '<td>' + num + '</td>' +
                    '<td class="accountability-cell">' + $('<div>').text(accountability).html() + '</td>' +
                    '<td class="official-cell">' + $('<div>').text(official.trim() || '---').html() + '</td>' +
                    '<td class="designation-cell">' + $('<div>').text(designation).html() + '</td>' +
                    '<td>' + sigHtml + '</td>' +
                    '<td>' + dateHtml + '</td>' +
                '</tr>'
            );
        });
    }
    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
