<?php
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__) . DIRECTORY_SEPARATOR);
}

if (!defined('BASE_URL')) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '');
    $appRoot = realpath(dirname(__DIR__));
    if ($docRoot && $appRoot) {
        $basePath = str_replace('\\', '/', substr($appRoot, strlen($docRoot)));
        $basePath = '/' . trim($basePath, '/') . '/';
    } else {
        $basePath = '/E-Clearance%20HRMU/';
    }
    define('BASE_URL', $protocol . '://' . $host . $basePath);
}

define('UPLOAD_PATH', ROOT_PATH . 'uploads/');
define('PDF_PATH', ROOT_PATH . 'pdfs/');
define('SIGNATURE_PATH', ROOT_PATH . 'assets/signatures/');
define('QR_PATH', ROOT_PATH . 'assets/qrcodes/');

session_start();
if (!isset($_SESSION['initiated'])) {
    session_regenerate_id(true);
    $_SESSION['initiated'] = true;
}
ob_start();

require_once __DIR__ . '/database.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $stmt = $db->prepare("SELECT u.*, r.role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function getCurrentRole() {
    $user = getCurrentUser();
    return $user ? $user['role_name'] : null;
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . 'login-page.php');
        exit;
    }
}

function requireRole($role) {
    requireLogin();
    if (getCurrentRole() !== $role) {
        header('Location: ' . BASE_URL . 'dashboard.php');
        exit;
    }
}

function requireAnyRole(array $roles) {
    requireLogin();
    if (!in_array(getCurrentRole(), $roles, true)) {
        header('Location: ' . BASE_URL . 'dashboard.php');
        exit;
    }
}

function redirect($url) {
    if (!preg_match('#^https?://#i', $url)) {
        $url = BASE_URL . ltrim($url, '/');
    }
    header("Location: $url");
    exit;
}

function assetUrl($path) {
    if ($path === null || $path === '') {
        return '';
    }
    if (preg_match('#^https?://#i', $path)) {
        return $path;
    }
    return BASE_URL . ltrim(str_replace('\\', '/', $path), '/');
}

function logAudit($action, $module, $description) {
    $db = getDB();
    $user = getCurrentUser();
    $userId = $user['id'] ?? null;
    $username = $user['username'] ?? 'system';
    $roleName = $user['role_name'] ?? 'system';
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $browser = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    $device = php_uname();

    $stmt = $db->prepare("INSERT INTO audit_logs (user_id, username, role_name, action_type, module, description, ip_address, browser_info, device_info) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssssss", $userId, $username, $roleName, $action, $module, $description, $ip, $browser, $device);
    $stmt->execute();
}

function createNotification($userId, $title, $message, $type = 'info', $link = null) {
    $db = getDB();
    if ($link !== null && $link !== '' && !preg_match('#^https?://#i', $link)) {
        $link = ltrim(str_replace('\\', '/', $link), '/');
        $link = preg_replace('#^\.\./#', '', $link);
    }
    $stmt = $db->prepare("INSERT INTO notifications (user_id, title, message, type, link) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $userId, $title, $message, $type, $link);
    $stmt->execute();
}

function generateCode($prefix = 'CLR') {
    return strtoupper($prefix . date('Ymd') . strtoupper(substr(uniqid(), -6)));
}

function hashDocument($content) {
    return hash('sha256', $content . time());
}

function formatDate($date, $format = 'M d, Y h:i A') {
    if (!$date) return 'N/A';
    return date($format, strtotime($date));
}

function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;
    if ($diff < 60) return 'Just now';
    if ($diff < 3600) return floor($diff / 60) . 'm ago';
    if ($diff < 86400) return floor($diff / 3600) . 'h ago';
    return date('M d', $time);
}

function getSetting($key) {
    $db = getDB();
    $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['setting_value'];
    }
    return null;
}

function navIsActive($path) {
    $self = str_replace('\\', '/', $_SERVER['PHP_SELF'] ?? '');
    $path = ltrim(str_replace('\\', '/', $path), '/');
    return strpos($self, $path) !== false;
}

function getUserAvatarInner($user) {
    if (!$user) return '?';
    if (!empty($user['profile_image'])) {
        $avatarUrl = assetUrl($user['profile_image']);
        return '<img src="' . htmlspecialchars($avatarUrl) . '" alt="Avatar" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">';
    }
    return strtoupper(substr($user['first_name'] ?? '', 0, 1)) . strtoupper(substr($user['last_name'] ?? '', 0, 1));
}

/**
 * Returns the first unsigned workflow step blocking the given step order, or null if clear to proceed.
 */
function getUnsignedPreviousStep($db, $clearanceId, $stepOrder) {
    $stmt = $db->prepare("
        SELECT o.office_name, ws.step_order
        FROM clearance_signatures cs
        JOIN workflow_steps ws ON cs.step_id = ws.id
        LEFT JOIN offices o ON ws.office_id = o.id
        WHERE cs.clearance_id = ? AND ws.step_order < ? AND cs.action != 'signed'
        ORDER BY ws.step_order ASC
        LIMIT 1
    ");
    $stmt->bind_param("ii", $clearanceId, $stepOrder);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
}

function canProceedToStep($db, $clearanceId, $stepOrder) {
    return getUnsignedPreviousStep($db, $clearanceId, $stepOrder) === null;
}

