<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
header('Content-Type: application/json');

$db = getDB();
$user = getCurrentUser();
$userId = (int)$user['id'];
$role = $user['role_name'];

$action = $_REQUEST['action'] ?? '';

if ($action === 'update_profile') {
    $contactNumber = trim($_POST['contact_number'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $middleName = trim($_POST['middle_name'] ?? '');
    $designation = trim($_POST['designation'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $gmailAddress = trim($_POST['gmail_address'] ?? '');
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    $db->begin_transaction();
    try {
        // Update users table (email, gmail, middle_name, password)
        $userUpdates = [];
        $userParams = [];
        $userTypes = '';

        // Handle profile picture upload
        $avatarUrl = null;
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['profile_image'];
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            if (!in_array($file['type'], $allowedTypes)) {
                throw new Exception('Invalid image type. Only JPG, PNG, GIF, and WEBP are allowed.');
            }
            if ($file['size'] > 2 * 1024 * 1024) { // 2MB
                throw new Exception('Image size must be less than 2MB.');
            }
            
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            if (empty($ext)) {
                $ext = 'jpg';
            }
            
            $avatarDir = UPLOAD_PATH . 'avatars/';
            if (!is_dir($avatarDir)) {
                mkdir($avatarDir, 0755, true);
            }
            
            $filename = 'avatar_' . $userId . '_' . time() . '.' . $ext;
            $targetPath = $avatarDir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                $dbPath = 'uploads/avatars/' . $filename;
                
                // Get old image to delete it
                $stmtOld = $db->prepare("SELECT profile_image FROM users WHERE id = ?");
                $stmtOld->bind_param("i", $userId);
                $stmtOld->execute();
                $oldImg = $stmtOld->get_result()->fetch_assoc()['profile_image'] ?? null;
                if ($oldImg && file_exists(ROOT_PATH . $oldImg)) {
                    @unlink(ROOT_PATH . $oldImg);
                }
                
                $userUpdates[] = "profile_image = ?";
                $userParams[] = $dbPath;
                $userTypes .= 's';
                $avatarUrl = assetUrl($dbPath);
            } else {
                throw new Exception('Failed to save uploaded image.');
            }
        }

        if ($email !== '') {
            $userUpdates[] = "email = ?";
            $userParams[] = $email;
            $userTypes .= 's';
        }
        if ($gmailAddress !== '') {
            $userUpdates[] = "gmail_address = ?";
            $userParams[] = $gmailAddress;
            $userTypes .= 's';
        }
        if ($middleName !== '') {
            $userUpdates[] = "middle_name = ?";
            $userParams[] = $middleName;
            $userTypes .= 's';
        }
        if ($currentPassword !== '' && $newPassword !== '' && $confirmPassword !== '') {
            // Verify current password
            $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            if (!$row || !password_verify($currentPassword, $row['password'])) {
                throw new Exception('Current password is incorrect');
            }
            if ($newPassword !== $confirmPassword) {
                throw new Exception('New passwords do not match');
            }
            if (strlen($newPassword) < 6) {
                throw new Exception('New password must be at least 6 characters');
            }
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $userUpdates[] = "password = ?";
            $userParams[] = $hashedPassword;
            $userTypes .= 's';
            logAudit('update', 'profile', 'User changed password');
        }

        if (!empty($userUpdates)) {
            $userParams[] = $userId;
            $userTypes .= 'i';
            $stmt = $db->prepare("UPDATE users SET " . implode(', ', $userUpdates) . " WHERE id = ?");
            $stmt->bind_param($userTypes, ...$userParams);
            $stmt->execute();
        }

        // Role-specific updates
        if ($role === 'employee') {
            $stmt = $db->prepare("UPDATE employees SET contact_number = ?, address = ? WHERE user_id = ?");
            $stmt->bind_param("ssi", $contactNumber, $address, $userId);
            $stmt->execute();
            logAudit('update', 'profile', 'Employee updated profile');
        } elseif ($role === 'signatory') {
            $stmt = $db->prepare("UPDATE signatory_profiles SET designation = ? WHERE user_id = ? AND is_active = 1");
            $stmt->bind_param("si", $designation, $userId);
            $stmt->execute();
            logAudit('update', 'profile', 'Signatory updated designation');
        } elseif ($role === 'admin') {
            // Admin can update their own user fields (already done above)
            logAudit('update', 'profile', 'Admin updated profile');
        }

        $db->commit();

        // Refresh session full_name if middle_name changed
        if ($middleName !== '') {
            $midInit = $middleName ? ' ' . strtoupper(substr($middleName, 0, 1)) . '.' : ' ';
            $_SESSION['full_name'] = $user['first_name'] . $midInit . $user['last_name'];
        }

        $responseData = ['success' => true, 'message' => 'Profile updated successfully'];
        if ($avatarUrl) {
            $responseData['avatar_url'] = $avatarUrl;
        }
        echo json_encode($responseData);
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);