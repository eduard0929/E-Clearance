<?php
require_once __DIR__ . '/../config/app.php';

$code = trim($_REQUEST['code'] ?? '');
$format = $_REQUEST['format'] ?? 'html';

if (empty($code)) {
    if ($format === 'json') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Clearance code is required']);
        exit;
    }
    header('Location: index.php');
    exit;
}

$db = getDB();
$stmt = $db->prepare("
    SELECT cr.*, cp.period_name, cp.academic_year, cp.semester
    FROM clearance_requests cr
    JOIN clearance_periods cp ON cr.period_id = cp.id
    WHERE cr.clearance_code = ?
");
$stmt->bind_param("s", $code);
$stmt->execute();
$clearance = $stmt->get_result()->fetch_assoc();

$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$browser = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';

if (!$clearance) {
    $stmt = $db->prepare("INSERT INTO verification_logs (clearance_code, verifier_ip, verifier_browser, verification_result) VALUES (?, ?, ?, 'invalid')");
    $stmt->bind_param("sss", $code, $ip, $browser);
    $stmt->execute();

    if ($format === 'json') {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'verified' => false,
            'status' => 'invalid',
            'message' => 'Clearance code not found in the system',
            'code' => $code
        ]);
        exit;
    }

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verification Result - HRMU</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
        <link href="../assets/css/style.css" rel="stylesheet">
    </head>
    <body class="bg-light">
        <div class="container">
            <div class="row justify-content-center mt-5">
                <div class="col-md-6">
                    <div class="text-center mb-4 animate-fade-in-down">
                        <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #800000, #a52a2a); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; font-size: 1.6rem; color: white; box-shadow: 0 4px 20px rgba(128,0,0,0.3);">
                            <i class="bi bi-shield-check"></i>
                        </div>
                        <h4 class="fw-bold mt-2">Verification Result</h4>
                    </div>
                    <div class="glass-card-static animate-fade-in-up">
                        <div class="card-body text-center p-5">
                            <div class="mb-3">
                                <span class="badge bg-danger" style="font-size: 1.2rem; padding: 10px 25px;">
                                    <i class="bi bi-x-circle"></i> INVALID
                                </span>
                            </div>
                            <h5 class="text-danger">Clearance Code Not Found</h5>
                            <p class="text-muted">The code <strong><?= htmlspecialchars($code) ?></strong> does not exist in our system.</p>
                            <p class="text-muted small">This could mean the code was entered incorrectly or the clearance was never issued.</p>
                            <a href="index.php" class="btn btn-outline-maroon mt-3"><i class="bi bi-arrow-left"></i> Try Again</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

$resultMap = [
    'completed' => 'verified',
    'revoked' => 'revoked',
    'rejected' => 'rejected',
    'in_progress' => 'in_progress',
    'pending' => 'pending',
    'draft' => 'pending',
];
$result = $resultMap[$clearance['status']] ?? 'invalid';
$logResult = in_array($result, ['verified', 'revoked', 'invalid'], true) ? $result : 'invalid';

$stmt = $db->prepare("INSERT INTO verification_logs (clearance_code, verifier_ip, verifier_browser, verification_result) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $code, $ip, $browser, $logResult);
$stmt->execute();

$stmtEmp = $db->prepare("
    SELECT e.*, u.first_name, u.middle_name, u.last_name, u.email, d.dept_name
    FROM employees e
    JOIN users u ON e.user_id = u.id
    LEFT JOIN departments d ON e.department_id = d.id
    WHERE e.id = ?
");
$stmtEmp->bind_param("i", $clearance['employee_id']);
$stmtEmp->execute();
$employee = $stmtEmp->get_result()->fetch_assoc();

$stmtSigs = $db->prepare("
    SELECT cs.*, ws.step_order, o.office_name, u2.first_name as signatory_first, u2.middle_name as signatory_middle, u2.last_name as signatory_last
    FROM clearance_signatures cs
    JOIN workflow_steps ws ON cs.step_id = ws.id
    LEFT JOIN offices o ON ws.office_id = o.id
    LEFT JOIN users u2 ON cs.signatory_id = u2.id
    WHERE cs.clearance_id = ?
    ORDER BY ws.step_order ASC
");
$stmtSigs->bind_param("i", $clearance['id']);
$stmtSigs->execute();
$signatures = $stmtSigs->get_result();

if ($format === 'json') {
    header('Content-Type: application/json');
    $sigList = [];
    while ($sig = $signatures->fetch_assoc()) {
        $sigMid = $sig['signatory_middle'] ?? '';
        $sigMidInit = $sigMid ? ' ' . mb_substr($sigMid, 0, 1) . '.' : '';
        $sigList[] = [
            'step_order' => (int)$sig['step_order'],
            'office' => $sig['office_name'],
            'signatory' => trim(($sig['signatory_first'] ?? '') . $sigMidInit . ' ' . ($sig['signatory_last'] ?? '')),
            'action' => $sig['action'],
            'signed_at' => $sig['signed_at']
        ];
    }
    $empMid = $employee['middle_name'] ?? '';
    $empMidInit = $empMid ? ' ' . mb_substr($empMid, 0, 1) . '.' : '';
    echo json_encode([
        'success' => true,
        'verified' => $result === 'verified',
        'status' => $result,
        'code' => $clearance['clearance_code'],
        'employee_name' => ($employee['first_name'] ?? '') . $empMidInit . ' ' . ($employee['last_name'] ?? ''),
        'department' => $employee['dept_name'] ?? 'N/A',
        'period' => $clearance['period_name'],
        'completed_at' => $clearance['completed_at'],
        'signatures' => $sigList,
        'verification_url' => BASE_URL . 'verification/verify.php?code=' . urlencode($clearance['clearance_code'])
    ]);
    exit;
}

$badgeMap = [
    'verified' => ['bg-success', 'bi-check-circle', 'VERIFIED'],
    'revoked' => ['bg-danger', 'bi-x-circle', 'REVOKED'],
    'rejected' => ['bg-danger', 'bi-x-circle', 'REJECTED'],
    'in_progress' => ['bg-info text-dark', 'bi-hourglass-split', 'IN PROGRESS'],
    'pending' => ['bg-secondary', 'bi-clock', 'PENDING'],
    'invalid' => ['bg-warning text-dark', 'bi-exclamation-triangle', 'INVALID'],
];
[$badgeClass, $badgeIcon, $statusLabel] = $badgeMap[$result] ?? $badgeMap['invalid'];

$empMid = $employee['middle_name'] ?? '';
$empMidInit = $empMid ? ' ' . mb_substr($empMid, 0, 1) . '.' : '';
$empName = htmlspecialchars(($employee['first_name'] ?? '') . $empMidInit . ' ' . ($employee['last_name'] ?? ''));
$deptName = htmlspecialchars($employee['dept_name'] ?? 'N/A');
$code = htmlspecialchars($clearance['clearance_code']);
$completedAt = $clearance['completed_at'] ? formatDate($clearance['completed_at'], 'F d, Y h:i A') : 'N/A';
$period = htmlspecialchars($clearance['period_name']);
$pdfPath = $clearance['pdf_path'] ? assetUrl($clearance['pdf_path']) : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verification Result - HRMU</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center mt-4 mb-4">
            <div class="col-md-7">
                <div class="text-center mb-3 animate-fade-in-down">
                    <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #800000, #a52a2a); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; font-size: 1.6rem; color: white; box-shadow: 0 4px 20px rgba(128,0,0,0.3);">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <h4 class="fw-bold mt-1">Verification Result</h4>
                </div>

                <div class="glass-card-static mb-3 animate-fade-in-up">
                    <div class="card-body text-center p-4">
                        <span class="badge <?= $badgeClass ?>" style="font-size: 1.1rem; padding: 8px 20px;">
                            <i class="bi <?= $badgeIcon ?>"></i> <?= $statusLabel ?>
                        </span>
                        <p class="mt-3 mb-0"><strong>Clearance Code:</strong> <code><?= $code ?></code></p>
                    </div>
                </div>

                <div class="glass-card-static mb-3 animate-fade-in-up">
                    <div class="card-header fw-bold"><i class="bi bi-person"></i> Employee Information</div>
                    <div class="card-body">
                        <table class="table table-sm table-borderless mb-0">
                            <tr><td class="text-muted" style="width:120px;">Name:</td><td class="fw-semibold"><?= $empName ?></td></tr>
                            <tr><td class="text-muted">Department:</td><td><?= $deptName ?></td></tr>
                            <tr><td class="text-muted">Period:</td><td><?= $period ?></td></tr>
                            <tr><td class="text-muted">Completed:</td><td><?= $completedAt ?></td></tr>
                        </table>
                    </div>
                </div>

                <div class="glass-card-static mb-3 animate-fade-in-up">
                    <div class="card-header fw-bold"><i class="bi bi-pen"></i> Signature Chain</div>
                    <div class="card-body p-0">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Office</th>
                                    <th>Signatory</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $sigCount = 0; ?>
                                <?php while ($sig = $signatures->fetch_assoc()): ?>
                                <?php $sigCount++; ?>
                                <tr>
                                    <td><?= $sigCount ?></td>
                                    <td><?= htmlspecialchars($sig['office_name']) ?></td>
                                    <?php $sigMid = $sig['signatory_middle'] ?? ''; $sigMidInit = $sigMid ? ' ' . mb_substr($sigMid, 0, 1) . '.' : ''; ?>
                                    <td><?= htmlspecialchars(trim(($sig['signatory_first'] ?? '') . $sigMidInit . ' ' . ($sig['signatory_last'] ?? ''))) ?: '<span class="text-muted">---</span>' ?></td>
                                    <td>
                                        <?php if ($sig['action'] === 'signed'): ?>
                                        <span class="badge bg-success"><i class="bi bi-check-circle"></i> Signed</span>
                                        <?php elseif ($sig['action'] === 'rejected'): ?>
                                        <span class="badge bg-danger"><i class="bi bi-x-circle"></i> Rejected</span>
                                        <?php elseif ($sig['action'] === 'returned'): ?>
                                        <span class="badge bg-warning text-dark"><i class="bi bi-arrow-return-left"></i> Returned</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary"><i class="bi bi-clock"></i> Pending</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= $sig['signed_at'] ? formatDate($sig['signed_at'], 'M d, Y h:i A') : '---' ?></td>
                                </tr>
                                <?php endwhile; ?>
                                <?php if ($sigCount === 0): ?>
                                <tr><td colspan="5" class="text-center text-muted py-3">No signatures recorded</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="glass-card-static mb-3 animate-fade-in-up">
                    <div class="card-header fw-bold"><i class="bi bi-clock-history"></i> Approval Timeline</div>
                    <div class="card-body p-0">
                        <table class="table table-sm mb-0">
                            <tbody>
                                <tr><td class="text-muted" style="width:130px;">Submitted:</td><td><?= $clearance['submitted_at'] ? formatDate($clearance['submitted_at'], 'M d, Y h:i A') : formatDate($clearance['created_at'], 'M d, Y h:i A') ?></td></tr>
                                <tr><td class="text-muted">Completed:</td><td><?= $clearance['completed_at'] ? formatDate($clearance['completed_at'], 'M d, Y h:i A') : 'N/A' ?></td></tr>
                                <tr><td class="text-muted">Verified At:</td><td><?= date('M d, Y h:i A') ?></td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="text-center mt-3 mb-4 animate-fade-in-up">
                    <?php if ($pdfPath): ?>
                    <a href="<?= htmlspecialchars($pdfPath) ?>" target="_blank" class="btn btn-outline-gold btn-sm"><i class="bi bi-file-earmark-pdf"></i> View Clearance PDF</a>
                    <?php endif; ?>
                    <a href="index.php" class="btn btn-outline-maroon btn-sm"><i class="bi bi-arrow-left"></i> Verify Another</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php
