<?php
require_once __DIR__ . '/../config/app.php';
$code = trim($_GET['code'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Clearance - HRMU</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <div class="text-center mb-4 animate-fade-in-down">
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #800000, #a52a2a); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; font-size: 2.2rem; color: white; box-shadow: 0 4px 20px rgba(128,0,0,0.3);">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <h3 class="fw-bold mt-2">Clearance Verification</h3>
                    <p class="text-muted">Enter the clearance code to verify authenticity</p>
                </div>
                <div class="glass-card-static p-4 animate-fade-in-up">
                    <form method="GET" action="verify.php">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Clearance Code</label>
                            <input type="text" class="form-control form-control-lg text-center" name="code" id="codeInput" value="<?= htmlspecialchars($code) ?>" placeholder="e.g. CLR20240101ABC123" required autofocus>
                        </div>
                        <button type="submit" class="btn btn-maroon btn-lg w-100">
                            <i class="bi bi-search"></i> Verify Now
                        </button>
                    </form>
                </div>
                <div class="text-center mt-3">
                    <a href="../dashboard.php" class="text-decoration-none text-maroon"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>
    <script>
    document.getElementById('codeInput').addEventListener('input', function() {
        this.value = this.value.toUpperCase();
    });
    </script>
</body>
</html>
