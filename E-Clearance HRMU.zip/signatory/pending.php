<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('signatory');

$db = getDB();
$user = getCurrentUser();
$userId = $user['id'];
$stmt = $db->prepare("SELECT sp.*, o.office_name FROM signatory_profiles sp JOIN offices o ON sp.office_id = o.id WHERE sp.user_id = ? AND sp.is_active = 1");
$stmt->bind_param("i", $userId);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();

if (!$profile) {
    die("Signatory profile not found. Contact administrator.");
}

$userInitial = strtoupper(substr($user['first_name'],0,1)) . strtoupper(substr($user['last_name'],0,1));
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Approvals - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Services</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link active" href="pending.php"><i class="bi bi-inbox"></i><span> Pending</span></a></li>
                <li class="nav-item"><a class="nav-link" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link" href="signature.php"><i class="bi bi-pen"></i><span> My Signature</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../profile.php"><i class="bi bi-person-circle"></i><span> Profile</span></a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <div class="main-content">
            <header class="top-header">
                <div class="d-flex align-items-center gap-2">
                    <button class="sidebar-toggle" onclick="document.getElementById('appSidebar').classList.toggle('show')">
                        <i class="bi bi-list"></i>
                    </button>
                    <div class="page-title">
                        <i class="bi bi-inbox"></i> Pending Approvals
                    </div>
                </div>
                <div class="header-actions">
                    <a class="position-relative text-decoration-none text-dark me-3" href="<?= $notifLink ?>" title="Notifications">
                        <i class="bi bi-bell fs-5"></i>
                        <?php if ($notifCount > 0): ?>
                        <span class="notif-count"><?= $notifCount > 9 ? '9+' : $notifCount ?></span>
                        <?php endif; ?>
                    </a>
                    <span class="badge bg-gold fs-6 me-2"><?= htmlspecialchars($profile['office_name']) ?></span>
                    <div class="dropdown user-dropdown">
                        <div class="user-avatar" data-bs-toggle="dropdown" role="button" style="overflow: hidden; padding: 0;">
                            <?= getUserAvatarInner($user) ?>
                        </div>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><span class="dropdown-item-text fw-bold"><?= htmlspecialchars($_SESSION['full_name']) ?></span></li>
                            <li><span class="dropdown-item-text text-muted small">Signatory</span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../profile.php"><i class="bi bi-person"></i> Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <div class="page-content animate-fade-in-up">

                <div class="glass-card-static">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="pendingTable" class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Clearance Code</th>
                                        <th>Employee Name</th>
                                        <th>Office / Step</th>
                                        <th>Status</th>
                                        <th>Submitted</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <div class="modal fade" id="actionModal" tabindex="-1" data-bs-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Clearance Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="actionModalBody">
                    <div class="text-center py-4">
                        <div class="spinner-border text-maroon" role="status"></div>
                        <p class="mt-2 text-muted">Loading...</p>
                    </div>
                </div>
                <div class="modal-footer" id="actionModalFooter">
                    <button type="button" class="btn btn-outline-maroon" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
    $(document).ready(function() {
        var table = $('#pendingTable').DataTable({
            ajax: {
                url: 'sign_ajax.php',
                data: { action: 'list_pending' }
            },
            columns: [
                { data: 'clearance_code' },
                { data: 'employee_name' },
                { data: 'step_info' },
                { data: 'status' },
                { data: 'submitted_at' },
                { data: 'actions', orderable: false }
            ],
            order: [[4, 'desc']],
            pageLength: 25,
            lengthChange: false
        });

        $('#actionModal').on('hidden.bs.modal', function() {
            table.ajax.reload(null, false);
        });
    });

    function viewDetails(id) {
        var body = $('#actionModalBody');
        var footer = $('#actionModalFooter');
        body.html('<div class="text-center py-4"><div class="spinner-border text-maroon" role="status"></div><p class="mt-2 text-muted">Loading details...</p></div>');
        footer.html('<button type="button" class="btn btn-outline-maroon" data-bs-dismiss="modal">Close</button>');
        $('#actionModal').modal('show');

        $.ajax({
            url: 'sign_ajax.php',
            data: { action: 'get_clearance', clearance_id: id },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    var d = res.data;
                    var html = '';
                    html += '<div class="row mb-3">';
                    html += '<div class="col-6"><strong>Code:</strong> <code>' + d.clearance_code + '</code></div>';
                    html += '<div class="col-6"><strong>Period:</strong> ' + d.period_name + '</div>';
                    html += '<div class="col-6 mt-2"><strong>Employee:</strong> ' + d.employee_name + '</div>';
                    html += '<div class="col-6 mt-2"><strong>Submitted:</strong> ' + d.submitted_at + '</div>';
                    html += '<div class="col-6 mt-2"><strong>Step:</strong> Step ' + d.step_order + ' of ' + d.total_steps + '</div>';
                    html += '<div class="col-6 mt-2"><strong>Office:</strong> ' + d.office_name + '</div>';
                    html += '</div>';

                    if (d.remarks) {
                        html += '<div class="mb-3"><strong>Remarks:</strong><p class="mb-0 text-muted">' + d.remarks + '</p></div>';
                    }

                    if (!d.can_sign) {
                        var waitOffice = d.blocking_office || 'the previous office';
                        var waitStep = d.blocking_step_order ? ' (Step ' + d.blocking_step_order + ')' : '';
                        html += '<div class="alert alert-warning mb-0"><i class="bi bi-hourglass-split"></i> Awaiting previous step. <strong>' + waitOffice + waitStep + '</strong> must sign before you can proceed.</div>';
                    }

                    body.html(html);

                    if (d.can_sign) {
                        footer.html(
                            '<button type="button" class="btn btn-gold" onclick="processSign(' + d.id + ')"><i class="bi bi-pen"></i> Sign</button>' +
                            '<button type="button" class="btn btn-warning" onclick="showRemarksForm(' + d.id + ', \'return\')"><i class="bi bi-arrow-return-left"></i> Return</button>' +
                            '<button type="button" class="btn btn-danger" onclick="showRemarksForm(' + d.id + ', \'reject\')"><i class="bi bi-x-circle"></i> Reject</button>' +
                            '<button type="button" class="btn btn-outline-maroon" data-bs-dismiss="modal">Close</button>'
                        );
                    }
                } else {
                    body.html('<div class="alert alert-danger">' + res.message + '</div>');
                }
            },
            error: function() {
                body.html('<div class="alert alert-danger">Failed to load details</div>');
            }
        });
    }

    function showRemarksForm(id, actionType) {
        var label = actionType === 'reject' ? 'Rejection Reason' : 'Return Reason';
        var btnClass = actionType === 'reject' ? 'btn-outline-maroon' : 'btn-outline-gold';
        var btnIcon = actionType === 'reject' ? 'bi-x-circle' : 'bi-arrow-return-left';
        var btnLabel = actionType === 'reject' ? 'Confirm Reject' : 'Confirm Return';
        var html = '';
        html += '<div class="mb-3">';
        html += '<label class="form-label fw-bold">' + label + '</label>';
        html += '<textarea class="form-control" id="remarksText" rows="3" placeholder="Enter remarks..." required></textarea>';
        html += '</div>';
        $('#actionModalBody').html(html);
        $('#actionModalFooter').html(
            '<button type="button" class="btn ' + btnClass + '" onclick="processAction(' + id + ', \'' + actionType + '\')"><i class="bi ' + btnIcon + '"></i> ' + btnLabel + '</button>' +
            '<button type="button" class="btn btn-outline-maroon" onclick="viewDetails(' + id + ')">Back</button>' +
            '<button type="button" class="btn btn-outline-maroon" data-bs-dismiss="modal">Close</button>'
        );
    }

    function processSign(id) {
        if (!confirm('Confirm signing this clearance request?')) return;
        doAction(id, 'process_sign');
    }

    function processAction(id, type) {
        var remarks = $('#remarksText').val().trim();
        if (!remarks) {
            showToast('warning', 'Please provide remarks');
            return;
        }
        var actionType = type === 'reject' ? 'process_reject' : 'process_return';
        doAction(id, actionType, remarks);
    }

    function doAction(id, actionType, remarks) {
        var footer = $('#actionModalFooter');
        footer.find('button').prop('disabled', true);
        $.ajax({
            url: 'sign_ajax.php',
            type: 'POST',
            data: { action: actionType, clearance_id: id, remarks: remarks || '' },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    showToast('success', res.message);
                    $('#actionModal').modal('hide');
                    $('#pendingTable').DataTable().ajax.reload();
                } else {
                    showToast('danger', res.message);
                    footer.find('button').prop('disabled', false);
                }
            },
            error: function() {
                showToast('danger', 'Request failed');
                footer.find('button').prop('disabled', false);
            }
        });
    }

    function showToast(type, message) {
        var bg = type === 'success' ? 'bg-success' : 'bg-danger';
        var toast = '<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div class="toast align-items-center text-white ' + bg + ' border-0 show" role="alert"><div class="d-flex"><div class="toast-body">' + message + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>';
        $('body').append(toast);
        setTimeout(function() { $(toast).remove(); }, 3000);
    }

    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
