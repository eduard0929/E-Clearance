<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('signatory');

$db = getDB();
$user = getCurrentUser();

$depts = $db->query("SELECT id, dept_name, dept_code FROM departments ORDER BY dept_name");
$profile = $db->query("SELECT sp.*, o.office_name FROM signatory_profiles sp JOIN offices o ON sp.office_id = o.id WHERE sp.user_id = " . (int)$user['id'] . " AND sp.is_active = 1")->fetch_assoc();

$userInitial = strtoupper(substr($user['first_name'],0,1)) . strtoupper(substr($user['last_name'],0,1));
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clearance Monitoring - Signatory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Services</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="pending.php"><i class="bi bi-inbox"></i><span> Pending</span></a></li>
                <li class="nav-item"><a class="nav-link active" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link" href="signature.php"><i class="bi bi-pen"></i><span> My Signature</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../profile.php"><i class="bi bi-person-circle"></i><span> Profile</span></a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <div class="main-content">
            <header class="top-header">
                <div class="d-flex align-items-center gap-2">
                    <button class="sidebar-toggle" onclick="document.getElementById('appSidebar').classList.toggle('show')">
                        <i class="bi bi-list"></i>
                    </button>
                    <div class="page-title">
                        <i class="bi bi-bar-chart-steps"></i> Clearance Monitoring
                    </div>
                </div>
                <div class="header-actions">
                    <a class="position-relative text-decoration-none text-dark me-3" href="<?= $notifLink ?>" title="Notifications">
                        <i class="bi bi-bell fs-5"></i>
                        <?php if ($notifCount > 0): ?>
                        <span class="notif-count"><?= $notifCount > 9 ? '9+' : $notifCount ?></span>
                        <?php endif; ?>
                    </a>
                    <?php if ($profile): ?>
                    <span class="badge bg-gold me-2"><?= htmlspecialchars($profile['office_name']) ?></span>
                    <?php endif; ?>
                    <div class="dropdown user-dropdown">
                        <div class="user-avatar" data-bs-toggle="dropdown" role="button" style="overflow: hidden; padding: 0;">
                            <?= getUserAvatarInner($user) ?>
                        </div>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><span class="dropdown-item-text fw-bold"><?= htmlspecialchars($_SESSION['full_name']) ?></span></li>
                            <li><span class="dropdown-item-text text-muted small">Signatory</span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../profile.php"><i class="bi bi-person"></i> Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <div class="page-content animate-fade-in-up">
                <div class="row g-3 mb-4" id="statsCards">
                    <div class="col-md-3 col-6">
                        <div class="glass-card-static text-center py-3">
                            <h5 class="mb-0 text-maroon" id="statTotal">0</h5>
                            <small class="text-muted">Total Employees</small>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="glass-card-static text-center py-3">
                            <h5 class="mb-0 text-maroon" id="statActive">0</h5>
                            <small class="text-muted">With Clearance</small>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="glass-card-static text-center py-3">
                            <h5 class="mb-0 text-warning" id="statInProgress">0</h5>
                            <small class="text-muted">In Progress</small>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="glass-card-static text-center py-3">
                            <h5 class="mb-0 text-success" id="statCompleted">0</h5>
                            <small class="text-muted">Completed</small>
                        </div>
                    </div>
                </div>

                <div class="glass-card-static">
                    <div class="card-header">
                        <div class="row g-2 align-items-center">
                            <div class="col-md-4">
                                <select class="form-select form-select-sm" id="filterDept">
                                    <option value="">All Departments</option>
                                    <?php while ($d = $depts->fetch_assoc()): ?>
                                    <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['dept_name']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select form-select-sm" id="filterType">
                                    <option value="">All Employee Types</option>
                                    <option value="regular_instructor">Regular Instructor</option>
                                    <option value="visiting_lecturer">Visiting Lecturer</option>
                                    <option value="non_teaching">Non-Teaching Staff</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select form-select-sm" id="filterStatus">
                                    <option value="">All Statuses</option>
                                    <option value="in_progress">In Progress</option>
                                    <option value="completed">Completed</option>
                                    <option value="pending">Pending</option>
                                    <option value="rejected">Rejected</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-sm btn-maroon w-100" id="applyFilters"><i class="bi bi-funnel"></i> Filter</button>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover" id="monitoringTable" style="font-size:0.85rem;">
                                <thead class="table-light">
                                    <tr>
                                        <th>Employee</th>
                                        <th>ID</th>
                                        <th>Type</th>
                                        <th>Department</th>
                                        <th>Clearance</th>
                                        <th>Status</th>
                                        <th>Progress</th>
                                        <th>Current Office</th>
                                        <th>Submitted</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
    var table;
    $(document).ready(function() {
        loadStats();
        table = $('#monitoringTable').DataTable({
            processing: true,
            ajax: {
                url: '../admin/monitoring_ajax.php',
                data: function(d) {
                    d.action = 'list_all';
                    d.dept_id = $('#filterDept').val();
                    d.employee_type = $('#filterType').val();
                    d.status = $('#filterStatus').val();
                }
            },
            columns: [
                { data: 'employee_name' },
                { data: 'employee_id' },
                { data: 'employee_type' },
                { data: 'department' },
                { data: 'clearance_code' },
                { data: 'status' },
                { data: 'progress' },
                { data: 'current_office' },
                { data: 'submitted' },
                { data: 'actions', orderable: false }
            ],
            order: [[3, 'asc'], [0, 'asc']],
            pageLength: 25,
            language: { search: 'Search employees:' }
        });

        $('#applyFilters').on('click', function() {
            loadStats();
            table.ajax.reload();
        });

        $('#monitoringTable').on('draw.dt', function() {
            updateAutoRefresh();
        });
    });

    function loadStats() {
        $.get('../admin/monitoring_ajax.php', {
            action: 'stats',
            dept_id: $('#filterDept').val()
        }, function(res) {
            if (res.success) {
                $('#statTotal').text(res.total_employees);
                $('#statActive').text(res.with_clearance);
                $('#statInProgress').text(res.in_progress);
                $('#statCompleted').text(res.completed);
            }
        });
    }

    var refreshTimer;
    function updateAutoRefresh() {
        clearTimeout(refreshTimer);
        refreshTimer = setTimeout(function() {
            loadStats();
            table.ajax.reload(null, false);
        }, 15000);
    }

    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
