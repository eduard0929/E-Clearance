<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('signatory');

$db = getDB();
$user = getCurrentUser();
$userId = (int)$user['id'];
$stmt = $db->prepare("SELECT sp.*, o.office_name FROM signatory_profiles sp JOIN offices o ON sp.office_id = o.id WHERE sp.user_id = ? AND sp.is_active = 1");
$stmt->bind_param("i", $userId);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();

$userInitial = strtoupper(substr($user['first_name'],0,1)) . strtoupper(substr($user['last_name'],0,1));
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Signature - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Services</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="pending.php"><i class="bi bi-inbox"></i><span> Pending</span></a></li>
                <li class="nav-item"><a class="nav-link" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link active" href="signature.php"><i class="bi bi-pen"></i><span> My Signature</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../profile.php"><i class="bi bi-person-circle"></i><span> Profile</span></a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <div class="main-content">
            <header class="top-header">
                <div class="d-flex align-items-center gap-2">
                    <button class="sidebar-toggle" onclick="document.getElementById('appSidebar').classList.toggle('show')">
                        <i class="bi bi-list"></i>
                    </button>
                    <div class="page-title">
                        <i class="bi bi-pen"></i> My Signature
                    </div>
                </div>
                <div class="header-actions">
                    <a class="position-relative text-decoration-none text-dark me-3" href="<?= $notifLink ?>" title="Notifications">
                        <i class="bi bi-bell fs-5"></i>
                        <?php if ($notifCount > 0): ?>
                        <span class="notif-count"><?= $notifCount > 9 ? '9+' : $notifCount ?></span>
                        <?php endif; ?>
                    </a>
                    <div class="dropdown user-dropdown">
                        <div class="user-avatar" data-bs-toggle="dropdown" role="button" style="overflow: hidden; padding: 0;">
                            <?= getUserAvatarInner($user) ?>
                        </div>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><span class="dropdown-item-text fw-bold"><?= htmlspecialchars($_SESSION['full_name']) ?></span></li>
                            <li><span class="dropdown-item-text text-muted small">Signatory</span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../profile.php"><i class="bi bi-person"></i> Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <div class="page-content animate-fade-in-up">
                <div class="row g-4">
                    <div class="col-md-8">
                        <div class="glass-card-static">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span class="fw-bold"><i class="bi bi-pen"></i> Digital Signature Pad</span>
                                <span class="badge bg-gold"><?= htmlspecialchars($profile['office_name'] ?? '') ?></span>
                            </div>
                            <div class="card-body">
                                <div class="row g-3 mb-3">
                                    <div class="col-auto">
                                        <label class="form-label small">Pen Thickness</label>
                                        <input type="range" class="form-range" id="penThickness" min="1" max="5" value="2" style="width: 100px;">
                                        <span class="badge bg-secondary" id="thicknessLabel">2px</span>
                                    </div>
                                    <div class="col-auto">
                                        <label class="form-label small">Color</label>
                                        <div class="d-flex gap-1">
                                            <input type="color" class="form-control form-control-color" id="penColor" value="#000000" style="width: 50px;">
                                        </div>
                                    </div>
                                </div>
                                <div class="border rounded bg-white" style="position: relative;">
                                    <canvas id="signatureCanvas" width="750" height="250" style="width: 100%; height: 250px; cursor: crosshair; touch-action: none;"></canvas>
                                </div>
                                <div class="d-flex gap-2 mt-3">
                                    <button class="btn btn-outline-maroon" id="clearBtn"><i class="bi bi-eraser"></i> Clear</button>
                                    <button class="btn btn-outline-maroon" id="undoBtn"><i class="bi bi-arrow-counterclockwise"></i> Undo</button>
                                    <button class="btn btn-gold ms-auto" id="saveSignatureBtn"><i class="bi bi-check-lg"></i> Save Signature</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="glass-card-static">
                            <div class="card-header fw-bold"><i class="bi bi-image"></i> Current Signature</div>
                            <div class="card-body text-center" id="signaturePreviewContainer">
                                <?php if ($profile && $profile['signature_image']): ?>
                                <img src="<?= assetUrl($profile['signature_image']) ?>" alt="Signature" id="currentSignatureImg" style="max-width: 100%; max-height: 150px;" class="mb-3">
                                <p class="text-success mb-2"><i class="bi bi-check-circle"></i> Signature saved</p>
                                <button class="btn btn-outline-maroon btn-sm" id="clearSignatureBtn"><i class="bi bi-trash"></i> Remove Signature</button>
                                <?php else: ?>
                                <div id="noSignaturePlaceholder">
                                    <i class="bi bi-pen fs-1 text-muted"></i>
                                    <p class="text-muted mt-2">No signature saved yet.<br>Draw your signature on the pad and save.</p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(document).ready(function() {
        var canvas = document.getElementById('signatureCanvas');
        var ctx = canvas.getContext('2d');
        var isDrawing = false;
        var lastX = 0, lastY = 0;
        var undoStack = [];
        var currentThickness = 2;
        var currentColor = '#000000';

        function getPos(e) {
            var rect = canvas.getBoundingClientRect();
            var scaleX = canvas.width / rect.width;
            var scaleY = canvas.height / rect.height;
            var clientX = e.touches ? e.touches[0].clientX : e.clientX;
            var clientY = e.touches ? e.touches[0].clientY : e.clientY;
            return {
                x: (clientX - rect.left) * scaleX,
                y: (clientY - rect.top) * scaleY
            };
        }

        function saveState() {
            undoStack.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
            if (undoStack.length > 50) undoStack.shift();
        }

        function redraw() {
            if (undoStack.length > 0) {
                ctx.putImageData(undoStack[undoStack.length - 1], 0, 0);
            } else {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        }

        function startDraw(e) {
            e.preventDefault();
            isDrawing = true;
            var pos = getPos(e);
            lastX = pos.x;
            lastY = pos.y;
            saveState();
        }

        function draw(e) {
            e.preventDefault();
            if (!isDrawing) return;
            var pos = getPos(e);
            ctx.beginPath();
            ctx.moveTo(lastX, lastY);
            ctx.lineTo(pos.x, pos.y);
            ctx.strokeStyle = currentColor;
            ctx.lineWidth = currentThickness;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.stroke();
            lastX = pos.x;
            lastY = pos.y;
        }

        function endDraw(e) {
            e.preventDefault();
            isDrawing = false;
        }

        canvas.addEventListener('mousedown', startDraw);
        canvas.addEventListener('mousemove', draw);
        canvas.addEventListener('mouseup', endDraw);
        canvas.addEventListener('mouseleave', endDraw);
        canvas.addEventListener('touchstart', startDraw, { passive: false });
        canvas.addEventListener('touchmove', draw, { passive: false });
        canvas.addEventListener('touchend', endDraw, { passive: false });

        $('#penThickness').on('input', function() {
            currentThickness = parseInt($(this).val());
            $('#thicknessLabel').text(currentThickness + 'px');
        });

        $('#penColor').on('input', function() {
            currentColor = $(this).val();
        });

        $('#clearBtn').on('click', function() {
            if (confirm('Clear the signature pad?')) {
                undoStack = [];
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        });

        $('#undoBtn').on('click', function() {
            if (undoStack.length > 0) {
                undoStack.pop();
                redraw();
            }
        });

        $('#saveSignatureBtn').on('click', function() {
            var dataUrl = canvas.toDataURL('image/png');
            var isEmpty = true;
            var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            for (var i = 3; i < imageData.data.length; i += 4) {
                if (imageData.data[i] !== 0) { isEmpty = false; break; }
            }
            if (isEmpty) {
                showToast('warning', 'Please draw your signature first');
                return;
            }
            var btn = $(this);
            btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Saving...');
            $.ajax({
                url: 'signature_ajax.php',
                type: 'POST',
                data: { action: 'save_signature', signature_data: dataUrl },
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        showToast('success', res.message);
                        if (res.signature_url) {
                            $('#currentSignatureImg').attr('src', res.signature_url + '?t=' + Date.now());
                            $('#noSignaturePlaceholder').remove();
                            var container = $('#signaturePreviewContainer');
                            if (!$('#currentSignatureImg').length) {
                                container.prepend('<img src="' + res.signature_url + '?t=' + Date.now() + '" alt="Signature" id="currentSignatureImg" style="max-width: 100%; max-height: 150px;" class="mb-3">');
                            }
                            container.find('.text-success').remove();
                            container.find('#clearSignatureBtn').remove();
                            container.append('<p class="text-success mb-2"><i class="bi bi-check-circle"></i> Signature saved</p><button class="btn btn-outline-maroon btn-sm" id="clearSignatureBtn"><i class="bi bi-trash"></i> Remove Signature</button>');
                            bindClearSignature();
                        }
                    } else {
                        showToast('danger', res.message);
                    }
                },
                error: function() {
                    showToast('danger', 'Request failed');
                },
                complete: function() {
                    btn.prop('disabled', false).html('<i class="bi bi-check-lg"></i> Save Signature');
                }
            });
        });

        function bindClearSignature() {
            $('#clearSignatureBtn').off('click').on('click', function() {
                if (!confirm('Remove your saved signature?')) return;
                var btn = $(this);
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span>');
                $.ajax({
                    url: 'signature_ajax.php',
                    type: 'POST',
                    data: { action: 'clear_signature' },
                    dataType: 'json',
                    success: function(res) {
                        if (res.success) {
                            showToast('success', res.message);
                            $('#currentSignatureImg').remove();
                            $('.text-success').remove();
                            $('#clearSignatureBtn').remove();
                            $('#signaturePreviewContainer').append('<div id="noSignaturePlaceholder"><i class="bi bi-pen fs-1 text-muted"></i><p class="text-muted mt-2">No signature saved yet.<br>Draw your signature on the pad and save.</p></div>');
                        } else {
                            showToast('danger', res.message);
                        }
                    },
                    error: function() {
                        showToast('danger', 'Request failed');
                    },
                    complete: function() {
                        btn.prop('disabled', false).html('<i class="bi bi-trash"></i> Remove Signature');
                    }
                });
            });
        }

        bindClearSignature();

        function showToast(type, message) {
            var bg = type === 'success' ? 'bg-success' : (type === 'warning' ? 'bg-warning text-dark' : 'bg-danger');
            var toast = '<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div class="toast align-items-center text-white ' + bg + ' border-0 show" role="alert"><div class="d-flex"><div class="toast-body">' + message + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>';
            $('body').append(toast);
            setTimeout(function() { $(toast).remove(); }, 3000);
        }
    });

    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
