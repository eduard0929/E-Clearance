<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('signatory');
header('Content-Type: application/json');

$db = getDB();
$user = getCurrentUser();
$userId = $user['id'];
$action = $_POST['action'] ?? '';

if ($action === 'save_signature') {
    $signatureData = $_POST['signature_data'] ?? '';

    if (empty($signatureData)) {
        echo json_encode(['success' => false, 'message' => 'No signature data received']);
        exit;
    }

    $stmt = $db->prepare("SELECT id, signature_image FROM signatory_profiles WHERE user_id = ? AND is_active = 1");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $profile = $stmt->get_result()->fetch_assoc();
    if (!$profile) {
        echo json_encode(['success' => false, 'message' => 'Signatory profile not found']);
        exit;
    }

    $imageParts = explode(';base64,', $signatureData);
    if (count($imageParts) < 2) {
        echo json_encode(['success' => false, 'message' => 'Invalid signature data format']);
        exit;
    }

    $imageBase64 = $imageParts[1];
    $imageData = base64_decode($imageBase64);
    if ($imageData === false) {
        echo json_encode(['success' => false, 'message' => 'Failed to decode signature data']);
        exit;
    }

    $signatureDir = SIGNATURE_PATH;
    if (!is_dir($signatureDir)) {
        mkdir($signatureDir, 0755, true);
    }

    $fileName = 'sig_' . $userId . '_' . time() . '.png';
    $filePath = $signatureDir . $fileName;
    $relativePath = 'assets/signatures/' . $fileName;

    if (file_put_contents($filePath, $imageData) === false) {
        echo json_encode(['success' => false, 'message' => 'Failed to save signature file']);
        exit;
    }

    $signatureHash = hashDocument($imageBase64);

    $stmt = $db->prepare("UPDATE signatory_profiles SET signature_image = ?, signature_hash = ? WHERE user_id = ?");
    $stmt->bind_param("ssi", $relativePath, $signatureHash, $userId);
    if ($stmt->execute()) {
        if (!empty($profile['signature_image'])) {
            $oldFile = ROOT_PATH . $profile['signature_image'];
            if (file_exists($oldFile)) {
                @unlink($oldFile);
            }
        }
        logAudit('update', 'signature', "User {$user['username']} saved digital signature");
        echo json_encode(['success' => true, 'message' => 'Signature saved successfully', 'signature_url' => assetUrl($relativePath)]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update signature record']);
    }
    exit;
}

if ($action === 'clear_signature') {
    $stmt = $db->prepare("SELECT id, signature_image FROM signatory_profiles WHERE user_id = ? AND is_active = 1");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $profile = $stmt->get_result()->fetch_assoc();
    if (!$profile) {
        echo json_encode(['success' => false, 'message' => 'Signatory profile not found']);
        exit;
    }

    if ($profile['signature_image']) {
        $oldFile = ROOT_PATH . $profile['signature_image'];
        if (file_exists($oldFile)) {
            @unlink($oldFile);
        }
    }

    $stmt = $db->prepare("UPDATE signatory_profiles SET signature_image = NULL, signature_hash = NULL WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    if ($stmt->execute()) {
        logAudit('delete', 'signature', "User {$user['username']} removed digital signature");
        echo json_encode(['success' => true, 'message' => 'Signature removed successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to remove signature']);
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
