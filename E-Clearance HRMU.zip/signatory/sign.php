<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('signatory');

$db = getDB();
$user = getCurrentUser();
$userId = (int)$user['id'];

$clearanceId = (int)($_GET['id'] ?? 0);
if (!$clearanceId) {
    die("Invalid clearance request.");
}

$stmt = $db->prepare("SELECT sp.*, o.office_name FROM signatory_profiles sp JOIN offices o ON sp.office_id = o.id WHERE sp.user_id = ? AND sp.is_active = 1");
$stmt->bind_param("i", $userId);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();
if (!$profile) {
    die("Signatory profile not found.");
}

$stmt = $db->prepare("
    SELECT cr.*, cp.period_name, u.first_name, u.last_name, u.email,
           ws.step_order, o.office_name, cs.remarks, cs.id AS sig_id
    FROM clearance_signatures cs
    JOIN clearance_requests cr ON cs.clearance_id = cr.id
    JOIN clearance_periods cp ON cr.period_id = cp.id
    JOIN employees e ON cr.employee_id = e.id
    JOIN users u ON e.user_id = u.id
    JOIN workflow_steps ws ON cs.step_id = ws.id
    LEFT JOIN offices o ON ws.office_id = o.id
    WHERE cr.id = ? AND cs.signatory_id = ? AND cs.action = 'pending'
");
$stmt->bind_param("ii", $clearanceId, $userId);
$stmt->execute();
$clearance = $stmt->get_result()->fetch_assoc();
if (!$clearance) {
    die("Clearance not found or already processed.");
}

$canSign = canProceedToStep($db, $clearanceId, (int)$clearance['step_order']);
$blockingStep = $canSign ? null : getUnsignedPreviousStep($db, $clearanceId, (int)$clearance['step_order']);

$userInitial = strtoupper(substr($user['first_name'],0,1)) . strtoupper(substr($user['last_name'],0,1));
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Clearance - HRMU Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <aside class="sidebar" id="appSidebar">
            <div class="sidebar-brand">
                <div class="brand-icon"><img src="<?= BASE_URL ?>assets/images/zppsu_logo.png" alt="ZPPsu" class="sidebar-logo"></div>
                <div class="brand-text">HRMU <small>Clearance System</small></div>
            </div>
            <div class="sidebar-divider">Main</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../dashboard.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a></li>
            </ul>
            <div class="sidebar-divider">Services</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="pending.php"><i class="bi bi-inbox"></i><span> Pending</span></a></li>
                <li class="nav-item"><a class="nav-link" href="monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
                <li class="nav-item"><a class="nav-link" href="signature.php"><i class="bi bi-pen"></i><span> My Signature</span></a></li>
            </ul>
            <div class="sidebar-divider">Account</div>
            <ul class="sidebar-nav">
                <li class="nav-item"><a class="nav-link" href="../profile.php"><i class="bi bi-person-circle"></i><span> Profile</span></a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
            </ul>
            <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
                <i class="bi bi-chevron-left collapse-toggle-icon"></i>
            </button>
        </aside>

        <div class="main-content">
            <header class="top-header">
                <div class="d-flex align-items-center gap-2">
                    <button class="sidebar-toggle" onclick="document.getElementById('appSidebar').classList.toggle('show')">
                        <i class="bi bi-list"></i>
                    </button>
                    <div class="page-title">
                        <i class="bi bi-pen"></i> Sign Clearance
                    </div>
                </div>
                <div class="header-actions">
                    <a class="position-relative text-decoration-none text-dark me-3" href="<?= $notifLink ?>" title="Notifications">
                        <i class="bi bi-bell fs-5"></i>
                        <?php if ($notifCount > 0): ?>
                        <span class="notif-count"><?= $notifCount > 9 ? '9+' : $notifCount ?></span>
                        <?php endif; ?>
                    </a>
                    <div class="dropdown user-dropdown">
                        <div class="user-avatar" data-bs-toggle="dropdown" role="button" style="overflow: hidden; padding: 0;">
                            <?= getUserAvatarInner($user) ?>
                        </div>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><span class="dropdown-item-text fw-bold"><?= htmlspecialchars($_SESSION['full_name']) ?></span></li>
                            <li><span class="dropdown-item-text text-muted small">Signatory</span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../profile.php"><i class="bi bi-person"></i> Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <div class="page-content animate-fade-in-up">
                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="glass-card-static">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="fw-bold mb-0"><i class="bi bi-file-text"></i> Clearance Details</h5>
                                <span class="badge bg-gold"><?= htmlspecialchars($profile['office_name']) ?></span>
                            </div>
                            <div class="card-body">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted small">Clearance Code</label>
                                        <p class="fw-bold"><?= htmlspecialchars($clearance['clearance_code']) ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted small">Period</label>
                                        <p class="fw-bold"><?= htmlspecialchars($clearance['period_name']) ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted small">Employee Name</label>
                                        <p class="fw-bold"><?= htmlspecialchars($clearance['first_name'] . ' ' . $clearance['last_name']) ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted small">Email</label>
                                        <p class="fw-bold"><?= htmlspecialchars($clearance['email']) ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label text-muted small">Step</label>
                                        <p class="fw-bold"><?= (int)$clearance['step_order'] ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label text-muted small">Office</label>
                                        <p class="fw-bold"><?= htmlspecialchars($clearance['office_name']) ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label text-muted small">Submitted</label>
                                        <p class="fw-bold"><?= formatDate($clearance['submitted_at'] ?: $clearance['created_at']) ?></p>
                                    </div>
                                </div>

                                <hr>

                                <?php if (!$canSign && $blockingStep): ?>
                                <div class="alert alert-warning mb-3">
                                    <i class="bi bi-hourglass-split"></i>
                                    <strong>Awaiting previous step.</strong>
                                    <?= htmlspecialchars($blockingStep['office_name'] ?: 'Step ' . $blockingStep['step_order']) ?>
                                    (Step <?= (int)$blockingStep['step_order'] ?>) must sign before you can proceed.
                                </div>
                                <?php endif; ?>

                                <div class="mb-3">
                                    <label class="form-label text-muted small">Remarks (required for return/reject)</label>
                                    <textarea class="form-control" id="remarksInput" rows="3" placeholder="Optional approval notes..."></textarea>
                                </div>

                                <div class="d-flex gap-2">
                                    <?php if ($canSign): ?>
                                    <button class="btn btn-gold btn-lg" id="approveBtn">
                                        <i class="bi bi-check-lg"></i> Approve & Sign
                                    </button>
                                    <?php else: ?>
                                    <button class="btn btn-secondary btn-lg" type="button" disabled title="Awaiting previous signatures">
                                        <i class="bi bi-hourglass-split"></i> Awaiting Previous Step
                                    </button>
                                    <?php endif; ?>
                                    <?php if ($canSign): ?>
                                    <button class="btn btn-warning" id="returnBtn">
                                        <i class="bi bi-arrow-counterclockwise"></i> Return for Revision
                                    </button>
                                    <button class="btn btn-danger" id="rejectBtn">
                                        <i class="bi bi-x-lg"></i> Reject
                                    </button>
                                    <?php else: ?>
                                    <button class="btn btn-outline-secondary" type="button" disabled title="Awaiting previous signatures">
                                        <i class="bi bi-arrow-counterclockwise"></i> Return for Revision
                                    </button>
                                    <button class="btn btn-outline-secondary" type="button" disabled title="Awaiting previous signatures">
                                        <i class="bi bi-x-lg"></i> Reject
                                    </button>
                                    <?php endif; ?>
                                    <a href="pending.php" class="btn btn-outline-maroon ms-auto">
                                        <i class="bi bi-arrow-left"></i> Back to Pending
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="glass-card-static">
                            <div class="card-header fw-bold"><i class="bi bi-pen"></i> Your Signature</div>
                            <div class="card-body text-center">
                                <?php if ($profile && $profile['signature_image']): ?>
                                <img src="<?= assetUrl($profile['signature_image']) ?>" alt="Signature" style="max-width: 100%; max-height: 100px;" class="mb-2">
                                <p class="text-success small"><i class="bi bi-check-circle"></i> Signature ready</p>
                                <?php else: ?>
                                <i class="bi bi-pen fs-1 text-muted"></i>
                                <p class="text-muted mt-2">No signature saved.</p>
                                <a href="signature.php" class="btn btn-outline-maroon btn-sm"><i class="bi bi-pen"></i> Create Signature</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-backdrop fade" id="sidebarBackdrop" style="display:none;" onclick="document.getElementById('appSidebar').classList.remove('show')"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(document).ready(function() {
        function showToast(type, message) {
            var bg = type === 'success' ? 'bg-success' : (type === 'warning' ? 'bg-warning text-dark' : 'bg-danger');
            var toast = '<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div class="toast align-items-center text-white ' + bg + ' border-0 show" role="alert"><div class="d-flex"><div class="toast-body">' + message + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>';
            $('body').append(toast);
            setTimeout(function() { $(toast).remove(); }, 3000);
        }

        function processAction(action) {
            var btn = action === 'process_sign' ? $('#approveBtn') : (action === 'process_return' ? $('#returnBtn') : $('#rejectBtn'));
            var remarks = $('#remarksInput').val().trim();

            if ((action === 'process_return' || action === 'process_reject') && !remarks) {
                showToast('warning', 'Please provide remarks');
                return;
            }

            var confirmMsg = action === 'process_sign' ? 'Approve and sign this clearance?' :
                             action === 'process_return' ? 'Return this clearance for revision?' :
                             'Reject this clearance?';
            if (!confirm(confirmMsg)) return;

            btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Processing...');

            $.ajax({
                url: 'sign_ajax.php',
                type: 'POST',
                data: {
                    action: action,
                    clearance_id: <?= $clearanceId ?>,
                    remarks: remarks
                },
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        showToast('success', res.message);
                        setTimeout(function() { window.location.href = 'pending.php'; }, 1500);
                    } else {
                        showToast('danger', res.message);
                        btn.prop('disabled', false).html(action === 'process_sign' ? '<i class="bi bi-check-lg"></i> Approve & Sign' : (action === 'process_return' ? '<i class="bi bi-arrow-counterclockwise"></i> Return for Revision' : '<i class="bi bi-x-lg"></i> Reject'));
                    }
                },
                error: function() {
                    showToast('danger', 'Request failed');
                    btn.prop('disabled', false).html(action === 'process_sign' ? '<i class="bi bi-check-lg"></i> Approve & Sign' : (action === 'process_return' ? '<i class="bi bi-arrow-counterclockwise"></i> Return for Revision' : '<i class="bi bi-x-lg"></i> Reject'));
                }
            });
        }

        <?php if ($canSign): ?>
        $('#approveBtn').on('click', function() { processAction('process_sign'); });
        $('#returnBtn').on('click', function() { processAction('process_return'); });
        $('#rejectBtn').on('click', function() { processAction('process_reject'); });
        <?php endif; ?>
    });

    </script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
