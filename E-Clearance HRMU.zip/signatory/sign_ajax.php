<?php
require_once __DIR__ . '/../config/app.php';
requireLogin();
requireRole('signatory');
header('Content-Type: application/json');

$db = getDB();
$user = getCurrentUser();
$userId = (int)$user['id'];

$stmt = $db->prepare("SELECT sp.*, o.office_name FROM signatory_profiles sp JOIN offices o ON sp.office_id = o.id WHERE sp.user_id = ? AND sp.is_active = 1");
$stmt->bind_param("i", $userId);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();
if (!$profile) {
    echo json_encode(['success' => false, 'message' => 'Signatory profile not found']);
    exit;
}

$action = $_REQUEST['action'] ?? '';

if ($action === 'list_pending') {
    $stmt = $db->prepare("
        SELECT cr.*, u.first_name, u.last_name, u.profile_image, ws.step_order, o.office_name, cs.step_id
        FROM clearance_signatures cs
        JOIN clearance_requests cr ON cs.clearance_id = cr.id
        JOIN employees e ON cr.employee_id = e.id
        JOIN users u ON e.user_id = u.id
        JOIN workflow_steps ws ON cs.step_id = ws.id
        LEFT JOIN offices o ON ws.office_id = o.id
        WHERE cs.signatory_id = ? AND cs.action = 'pending'
        ORDER BY cs.created_at DESC
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $isReady = canProceedToStep($db, $row['id'], (int)$row['step_order']);

        $statusBadge = $isReady ? 
            '<span class="badge bg-info">Ready to Sign</span>' : 
            '<span class="badge bg-secondary">Awaiting Previous</span>';

        $actions = '';
        $actions .= '<div class="btn-group btn-group-sm">';
        $actions .= '<button class="btn btn-outline-primary" onclick="viewDetails(' . $row['id'] . ')" title="View"><i class="bi bi-eye"></i></button>';
        if ($isReady) {
            $actions .= '<a href="sign.php?id=' . $row['id'] . '" class="btn btn-success" title="Sign"><i class="bi bi-pen"></i></a>';
        } else {
            $actions .= '<button type="button" class="btn btn-outline-secondary" disabled title="Awaiting previous signatures"><i class="bi bi-pen"></i></button>';
        }
        $actions .= '</div>';

        $empName = htmlspecialchars($row['first_name'] . ' ' . $row['last_name']);
        if (!empty($row['profile_image'])) {
            $avatarUrl = assetUrl($row['profile_image']);
            $avatarHtml = '<img src="' . htmlspecialchars($avatarUrl) . '" alt="Avatar" class="rounded-circle me-2" style="width: 28px; height: 28px; object-fit: cover;">';
        } else {
            $initials = strtoupper(substr($row['first_name'],0,1)) . strtoupper(substr($row['last_name'],0,1));
            $avatarHtml = '<span class="d-inline-flex align-items-center justify-content-center rounded-circle me-2 bg-secondary text-white fw-bold text-center" style="width: 28px; height: 28px; font-size: 0.75rem; vertical-align: middle;">' . htmlspecialchars($initials) . '</span>';
        }
        $employeeNameHtml = '<div class="d-flex align-items-center">' . $avatarHtml . '<span>' . $empName . '</span></div>';

        $data[] = [
            'clearance_code' => '<code>' . htmlspecialchars($row['clearance_code']) . '</code>',
            'employee_name' => $employeeNameHtml,
            'step_info' => htmlspecialchars($row['office_name']) . ' <span class="badge bg-secondary">Step ' . $row['step_order'] . '</span>',
            'status' => $statusBadge,
            'submitted_at' => formatDate($row['submitted_at'] ?: $row['created_at']),
            'actions' => $actions
        ];
    }
    echo json_encode(['data' => $data]);
    exit;
}

if ($action === 'get_clearance') {
    $clearanceId = (int)($_REQUEST['clearance_id'] ?? 0);
    $stmt = $db->prepare("
        SELECT cr.*, cp.period_name, u.first_name, u.last_name, u.profile_image, ws.step_order, o.office_name, cs.remarks
        FROM clearance_signatures cs
        JOIN clearance_requests cr ON cs.clearance_id = cr.id
        JOIN clearance_periods cp ON cr.period_id = cp.id
        JOIN employees e ON cr.employee_id = e.id
        JOIN users u ON e.user_id = u.id
        JOIN workflow_steps ws ON cs.step_id = ws.id
        LEFT JOIN offices o ON ws.office_id = o.id
        WHERE cr.id = ? AND cs.signatory_id = ?
    ");
    $stmt->bind_param("ii", $clearanceId, $userId);
    $stmt->execute();
    $cr = $stmt->get_result()->fetch_assoc();

    if (!$cr) {
        echo json_encode(['success' => false, 'message' => 'Clearance not found']);
        exit;
    }

    $canSign = canProceedToStep($db, $clearanceId, (int)$cr['step_order']);
    $blockingStep = $canSign ? null : getUnsignedPreviousStep($db, $clearanceId, (int)$cr['step_order']);

    echo json_encode([
        'success' => true,
        'data' => [
            'id' => $cr['id'],
            'clearance_code' => htmlspecialchars($cr['clearance_code']),
            'period_name' => htmlspecialchars($cr['period_name']),
            'employee_name' => (function() use ($cr) {
                $empName = htmlspecialchars($cr['first_name'] . ' ' . $cr['last_name']);
                if (!empty($cr['profile_image'])) {
                    $avatarUrl = assetUrl($cr['profile_image']);
                    $avatarHtml = '<img src="' . htmlspecialchars($avatarUrl) . '" alt="Avatar" class="rounded-circle me-2" style="width: 24px; height: 24px; object-fit: cover;">';
                } else {
                    $initials = strtoupper(substr($cr['first_name'],0,1)) . strtoupper(substr($cr['last_name'],0,1));
                    $avatarHtml = '<span class="d-inline-flex align-items-center justify-content-center rounded-circle me-2 bg-secondary text-white fw-bold text-center" style="width: 24px; height: 24px; font-size: 0.7rem; vertical-align: middle;">' . htmlspecialchars($initials) . '</span>';
                }
                return '<span class="d-inline-flex align-items-center">' . $avatarHtml . '<span>' . $empName . '</span></span>';
            })(),
            'office_name' => htmlspecialchars($cr['office_name']),
            'step_order' => $cr['step_order'],
            'total_steps' => $cr['total_steps'],
            'submitted_at' => formatDate($cr['submitted_at'] ?: $cr['created_at']),
            'remarks' => htmlspecialchars($cr['remarks'] ?? ''),
            'can_sign' => $canSign,
            'blocking_office' => $blockingStep ? htmlspecialchars($blockingStep['office_name'] ?: 'Previous step') : null,
            'blocking_step_order' => $blockingStep ? (int)$blockingStep['step_order'] : null
        ]
    ]);
    exit;
}

$clearanceId = (int)($_POST['clearance_id'] ?? 0);
if (!$clearanceId) {
    echo json_encode(['success' => false, 'message' => 'Clearance ID required']);
    exit;
}

$stmt = $db->prepare("SELECT * FROM clearance_requests WHERE id = ?");
$stmt->bind_param("i", $clearanceId);
$stmt->execute();
$clearance = $stmt->get_result()->fetch_assoc();
if (!$clearance) {
    echo json_encode(['success' => false, 'message' => 'Clearance request not found']);
    exit;
}

$stmt = $db->prepare("
    SELECT cs.*, ws.step_order
    FROM clearance_signatures cs
    JOIN workflow_steps ws ON cs.step_id = ws.id
    WHERE cs.clearance_id = ? AND cs.signatory_id = ? AND cs.action = 'pending'
");
$stmt->bind_param("ii", $clearanceId, $userId);
$stmt->execute();
$signature = $stmt->get_result()->fetch_assoc();

if (!$signature) {
    echo json_encode(['success' => false, 'message' => 'No pending signature request found']);
    exit;
}

if ($action === 'process_sign') {
    if (empty($profile['signature_image'])) {
        echo json_encode(['success' => false, 'message' => 'Please save your digital signature first']);
        exit;
    }

    $blockingStep = getUnsignedPreviousStep($db, $clearanceId, (int)$signature['step_order']);
    if ($blockingStep) {
        $officeName = $blockingStep['office_name'] ?: 'Step ' . $blockingStep['step_order'];
        echo json_encode(['success' => false, 'message' => 'Cannot sign yet. ' . $officeName . ' (Step ' . $blockingStep['step_order'] . ') must sign first.']);
        exit;
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $browser = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    $device = php_uname();
    $signedAt = date('Y-m-d H:i:s');
    $signatureHash = hashDocument($profile['signature_image'] . $clearanceId . $signedAt);

    $db->begin_transaction();
    try {
        $stmt = $db->prepare("UPDATE clearance_signatures SET signature_image = ?, signature_hash = ?, action = 'signed', ip_address = ?, browser_info = ?, device_info = ?, signed_at = ? WHERE id = ?");
        $stmt->bind_param("ssssssi", $profile['signature_image'], $signatureHash, $ip, $browser, $device, $signedAt, $signature['id']);
        $stmt->execute();

        $currentStepOrder = (int)$signature['step_order'];
        $stmt = $db->prepare("
            SELECT COUNT(*) as c FROM clearance_signatures cs
            JOIN workflow_steps ws ON cs.step_id = ws.id
            WHERE cs.clearance_id = ? AND ws.step_order = ? AND cs.action != 'signed'
        ");
        $stmt->bind_param("ii", $clearanceId, $currentStepOrder);
        $stmt->execute();
        $remainingAtStep = (int)$stmt->get_result()->fetch_assoc()['c'];

        if ($remainingAtStep === 0) {
            $nextStep = $currentStepOrder + 1;
            $stmt = $db->prepare("UPDATE clearance_requests SET current_step = ? WHERE id = ?");
            $stmt->bind_param("ii", $nextStep, $clearanceId);
            $stmt->execute();

            $stmt = $db->prepare("SELECT cs.id, cs.signatory_id FROM clearance_signatures cs JOIN workflow_steps ws ON cs.step_id = ws.id WHERE cs.clearance_id = ? AND ws.step_order = ? AND cs.action = 'pending'");
            $stmt->bind_param("ii", $clearanceId, $nextStep);
            $stmt->execute();
            $nextSignatures = $stmt->get_result();
            while ($ns = $nextSignatures->fetch_assoc()) {
                createNotification($ns['signatory_id'], 'Clearance Ready for Signature', "Clearance {$clearance['clearance_code']} is ready for your signature", 'info', 'signatory/pending.php?view=' . $clearanceId);
            }
        }

        $stmt = $db->prepare("SELECT COUNT(*) as c FROM clearance_signatures WHERE clearance_id = ? AND action = 'pending'");
        $stmt->bind_param("i", $clearanceId);
        $stmt->execute();
        $remainingPending = (int)$stmt->get_result()->fetch_assoc()['c'];
        $clearanceCompleted = false;
        if ($remainingPending === 0) {
            $stmt = $db->prepare("UPDATE clearance_requests SET status = 'completed', completed_at = NOW() WHERE id = ?");
            $stmt->bind_param("i", $clearanceId);
            $stmt->execute();
            $clearanceCompleted = true;
        }

        $empId = (int)$clearance['employee_id'];
        $stmt = $db->prepare("SELECT e.user_id FROM employees e WHERE e.id = ?");
        $stmt->bind_param("i", $empId);
        $stmt->execute();
        $empUser = $stmt->get_result()->fetch_assoc();
        if ($empUser) {
            createNotification($empUser['user_id'], 'Clearance Signed', "Clearance {$clearance['clearance_code']} has been signed by {$profile['office_name']}", 'success', 'employee/clearance.php?view=' . $clearanceId);
        }

        logAudit('sign', 'clearance', "Signatory signed clearance: {$clearance['clearance_code']} (Step $currentStepOrder)");
        $db->commit();

        if ($clearanceCompleted && file_exists(__DIR__ . '/../includes/generate_pdf.php')) {
            try {
                require_once __DIR__ . '/../includes/generate_pdf.php';
                if (function_exists('generateClearancePDF')) {
                    generateClearancePDF($clearanceId);
                }
            } catch (Throwable $e) {
                error_log('Clearance PDF generation failed for #' . $clearanceId . ': ' . $e->getMessage());
            }
        }

        echo json_encode(['success' => true, 'message' => 'Clearance signed successfully']);
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to process signature']);
    }
    exit;
}

if ($action === 'process_reject' || $action === 'process_return') {
    $remarks = trim($_POST['remarks'] ?? '');
    if (empty($remarks)) {
        echo json_encode(['success' => false, 'message' => 'Remarks are required']);
        exit;
    }

    $blockingStep = getUnsignedPreviousStep($db, $clearanceId, (int)$signature['step_order']);
    if ($blockingStep) {
        $officeName = $blockingStep['office_name'] ?: 'Step ' . $blockingStep['step_order'];
        echo json_encode(['success' => false, 'message' => 'Cannot act on this clearance yet. ' . $officeName . ' (Step ' . $blockingStep['step_order'] . ') must sign first.']);
        exit;
    }

    $newAction = ($action === 'process_reject') ? 'rejected' : 'returned';
    $newStatus = ($action === 'process_reject') ? 'rejected' : 'in_progress';
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $browser = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    $device = php_uname();
    $actionTime = date('Y-m-d H:i:s');

    $db->begin_transaction();
    try {
        $stmt = $db->prepare("UPDATE clearance_signatures SET action = ?, remarks = ?, ip_address = ?, browser_info = ?, device_info = ?, signed_at = ? WHERE id = ?");
        $stmt->bind_param("ssssssi", $newAction, $remarks, $ip, $browser, $device, $actionTime, $signature['id']);
        $stmt->execute();

        $stmt = $db->prepare("UPDATE clearance_requests SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $newStatus, $clearanceId);
        $stmt->execute();

        $empId = (int)$clearance['employee_id'];
        $stmt = $db->prepare("SELECT u.id FROM employees e JOIN users u ON e.user_id = u.id WHERE e.id = ?");
        $stmt->bind_param("i", $empId);
        $stmt->execute();
        $empUser = $stmt->get_result()->fetch_assoc();
        if ($empUser) {
            $notifTitle = ($action === 'process_reject') ? 'Clearance Rejected' : 'Clearance Returned';
            $notifType = ($action === 'process_reject') ? 'danger' : 'warning';
            createNotification($empUser['id'], $notifTitle, "Your clearance {$clearance['clearance_code']} has been $newAction by {$profile['office_name']}. Remarks: $remarks", $notifType, 'employee/clearance.php?view=' . $clearanceId);
        }

        $auditAction = ($action === 'process_reject') ? 'reject' : 'return';
        logAudit($auditAction, 'clearance', "Signatory $auditAction clearance: {$clearance['clearance_code']} - $remarks");
        $db->commit();
        echo json_encode(['success' => true, 'message' => 'Clearance ' . ($action === 'process_reject' ? 'rejected' : 'returned') . ' successfully']);
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to process request']);
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
