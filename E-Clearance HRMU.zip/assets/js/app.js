document.addEventListener('DOMContentLoaded', function() {
    // Password show/hide toggle
    document.querySelectorAll('.password-toggle-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var input = this.parentElement.querySelector('.form-control, input[type="password"], input[type="text"]');
            if (!input) return;
            var icon = this.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                if (icon) { icon.classList.remove('bi-eye'); icon.classList.add('bi-eye-slash'); }
            } else {
                input.type = 'password';
                if (icon) { icon.classList.remove('bi-eye-slash'); icon.classList.add('bi-eye'); }
            }
        });
    });

    // Sidebar collapse toggle
    var collapseBtn = document.getElementById('sidebarCollapseBtn');
    var sidebar = document.getElementById('appSidebar');
    var backdrop = document.getElementById('sidebarBackdrop');
    if (collapseBtn && sidebar) {
        // Load initial state from local storage for better UX
        if (localStorage.getItem('sidebarCollapsed') === 'true') {
            sidebar.classList.add('collapsed');
        }

        collapseBtn.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        });
    }

    // Mobile sidebar toggle (existing)
    var sidebarToggle = document.querySelector('.sidebar-toggle');
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            if (backdrop) {
                if (sidebar.classList.contains('show')) {
                    backdrop.style.display = 'block';
                    setTimeout(function() { backdrop.classList.add('show'); }, 10);
                } else {
                    backdrop.classList.remove('show');
                    setTimeout(function() { backdrop.style.display = 'none'; }, 300);
                }
            }
        });
    }

    // Sidebar backdrop click
    if (backdrop && sidebar) {
        backdrop.addEventListener('click', function() {
            sidebar.classList.remove('show');
            backdrop.classList.remove('show');
            setTimeout(function() { backdrop.style.display = 'none'; }, 300);
        });
    }

    // Escape key for sidebar
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && sidebar && sidebar.classList.contains('show')) {
            sidebar.classList.remove('show');
            if (backdrop) {
                backdrop.classList.remove('show');
                setTimeout(function() { backdrop.style.display = 'none'; }, 300);
            }
        }
    });

});
