<?php

function resolveAccountabilityArea(?string $officeName, ?string $officeCode, ?string $deptName = null, bool $isDynamic = false): string
{
    if ($isDynamic || ($officeCode && strpos($officeCode, 'DEAN_') === 0)) {
        return $deptName ? 'Faculty Reports — ' . $deptName : 'Faculty Reports / College Dean';
    }

    $byCode = [
        'REG' => 'Student Records/Grades',
        'REGISTRAR' => 'Student Records/Grades',
        'ACCT' => 'Financial',
        'ACCOUNTING' => 'Financial',
        'CASH' => 'Cashier',
        'CASHIER' => 'Cashier',
        'LIB' => 'Library',
        'LIBRARY' => 'Library',
        'SPMU' => 'Property/Supply',
        'SUPPLY' => 'Property/Supply',
        'HRMO' => 'HRMO',
        'LEGAL' => 'Legal',
        'CAO' => 'Chief Administrative Officer',
        'CAMPUS_ADMIN' => 'Campus Administration',
        'VPAA' => 'VP for Academic Affairs',
        'VPRE' => 'VP for Research and Extension',
        'VPAF' => 'VP for Admin and Finance',
        'VPSAS' => 'VP for Student Affairs and Services',
        'PRES' => 'President',
        'PRESIDENT' => 'President',
    ];

    $code = strtoupper(trim($officeCode ?? ''));
    if ($code && isset($byCode[$code])) {
        return $byCode[$code];
    }

    if ($officeName) {
        $name = $officeName;
        if (stripos($name, 'Registrar') !== false) return 'Student Records/Grades';
        if (stripos($name, 'Accountant') !== false) return 'Financial';
        if (stripos($name, 'Cashier') !== false) return 'Cashier';
        if (stripos($name, 'Library') !== false || stripos($name, 'Learning Commons') !== false) return 'Library';
        if (stripos($name, 'Supply') !== false || stripos($name, 'Property') !== false) return 'Property/Supply';
        if (stripos($name, 'Dean') !== false || stripos($name, 'Director') !== false || stripos($name, 'Principal') !== false) {
            return $deptName ? 'Faculty Reports — ' . $deptName : 'Faculty Reports / College Dean';
        }
        if (stripos($name, 'President') !== false) return 'President';
        if (stripos($name, 'VP for Academic') !== false) return 'VP for Academic Affairs';
        if (stripos($name, 'VP for Research') !== false) return 'VP for Research and Extension';
        if (stripos($name, 'VP for Admin') !== false) return 'VP for Admin and Finance';
        if (stripos($name, 'VP for Student') !== false) return 'VP for Student Affairs and Services';
        if (stripos($name, 'HRMO') !== false) return 'HRMO';
        if (stripos($name, 'Legal') !== false) return 'Legal';
        return $name;
    }

    return 'N/A';
}

function resolveSignatoryDesignation(?string $designation, ?string $officeName, ?string $officeCode): string
{
    $designation = trim($designation ?? '');
    if ($designation !== '' && $designation !== '---') {
        return $designation;
    }

    $byCode = [
        'REG' => 'University Registrar',
        'REGISTRAR' => 'University Registrar',
        'ACCT' => 'Accountant IV',
        'ACCOUNTING' => 'Accountant IV',
        'CASH' => 'Cashier III',
        'CASHIER' => 'Cashier III',
        'LIB' => 'Librarian IV',
        'LIBRARY' => 'Librarian IV',
        'SPMU' => 'Supply Officer IV',
        'SUPPLY' => 'Supply Officer IV',
        'HRMO' => 'HRMO IV',
        'LEGAL' => 'Legal Officer IV',
        'VPAA' => 'VP for Academic Affairs',
        'VPRE' => 'VP for Research and Extension',
        'VPAF' => 'VP for Admin and Finance',
        'VPSAS' => 'VP for Student Affairs and Services',
        'PRES' => 'President',
        'PRESIDENT' => 'President',
    ];

    $code = strtoupper(trim($officeCode ?? ''));
    if ($code && isset($byCode[$code])) {
        return $byCode[$code];
    }
    if ($code && strpos($code, 'DEAN_') === 0) {
        return 'College Dean';
    }

    return $officeName ?: '---';
}
