<?php
/**
 * Shared sidebar navigation. Requires $role or logged-in user context.
 */
$role = $role ?? getCurrentRole();
$self = str_replace('\\', '/', $_SERVER['PHP_SELF'] ?? '');

$isActive = function ($path) use ($self) {
    return strpos($self, ltrim($path, '/')) !== false;
};
?>
<aside class="sidebar" id="appSidebar">
    <div class="sidebar-brand">
        <div class="brand-icon">
            <img src="<?= assetUrl('assets/images/zppsu_logo.png') ?>" alt="HRMU" class="sidebar-logo">
        </div>
        <div class="brand-text">
            HRMU
            <small>Clearance System</small>
        </div>
    </div>

    <div class="sidebar-divider">Main</div>
    <ul class="sidebar-nav">
        <li class="nav-item">
            <a class="nav-link <?= basename($self) === 'dashboard.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>dashboard.php">
                <i class="bi bi-speedometer2"></i><span> Dashboard</span>
            </a>
        </li>
    </ul>

    <?php if ($role === 'admin'): ?>
    <div class="sidebar-divider">Administration</div>
    <ul class="sidebar-nav">
        <li class="nav-item"><a class="nav-link <?= $isActive('admin/users.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>admin/users.php"><i class="bi bi-people"></i><span> Users</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $isActive('admin/departments.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>admin/departments.php"><i class="bi bi-building"></i><span> College Departments</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $isActive('admin/offices.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>admin/offices.php"><i class="bi bi-door-open"></i><span> College Offices</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $isActive('admin/workflow.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>admin/workflow.php"><i class="bi bi-diagram-3"></i><span> Workflow</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $isActive('admin/clearance_periods.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>admin/clearance_periods.php"><i class="bi bi-calendar-event"></i><span> Periods</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $isActive('admin/monitoring.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>admin/monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $isActive('admin/settings.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>admin/settings.php"><i class="bi bi-toggles"></i><span> Settings</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $isActive('admin/audit_logs.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>admin/audit_logs.php"><i class="bi bi-journal-text"></i><span> Audit Logs</span></a></li>
    </ul>
    <?php elseif ($role === 'employee'): ?>
    <div class="sidebar-divider">Services</div>
    <ul class="sidebar-nav">
        <li class="nav-item"><a class="nav-link <?= $isActive('employee/clearance.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>employee/clearance.php"><i class="bi bi-file-earmark-text"></i><span> My Clearance</span></a></li>
    </ul>
    <?php elseif ($role === 'signatory'): ?>
    <div class="sidebar-divider">Services</div>
    <ul class="sidebar-nav">
        <li class="nav-item"><a class="nav-link <?= $isActive('signatory/pending.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>signatory/pending.php"><i class="bi bi-inbox"></i><span> Pending</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $isActive('signatory/monitoring.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>signatory/monitoring.php"><i class="bi bi-bar-chart-steps"></i><span> Monitoring</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $isActive('signatory/signature.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>signatory/signature.php"><i class="bi bi-pen"></i><span> My Signature</span></a></li>
    </ul>
    <?php endif; ?>

    <div class="sidebar-divider">Public</div>
    <ul class="sidebar-nav">
        <li class="nav-item"><a class="nav-link <?= $isActive('verification/') ? 'active' : '' ?>" href="<?= BASE_URL ?>verification/index.php"><i class="bi bi-check-circle"></i><span> Verify</span></a></li>
    </ul>

    <div class="sidebar-divider">Account</div>
    <ul class="sidebar-nav">
        <li class="nav-item"><a class="nav-link <?= $isActive('profile.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>profile.php"><i class="bi bi-person-circle"></i><span> Profile</span></a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></li>
    </ul>

    <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Toggle sidebar">
        <i class="bi bi-chevron-left collapse-toggle-icon"></i>
    </button>
</aside>
