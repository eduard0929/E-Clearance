<?php
if (file_exists(ROOT_PATH . 'vendor/fpdf.php')) {
    require_once ROOT_PATH . 'vendor/fpdf.php';
}
if (file_exists(ROOT_PATH . 'vendor/phpqrcode.php')) {
    require_once ROOT_PATH . 'vendor/phpqrcode.php';
}

$tcpdfAvailable = false;
if (file_exists(ROOT_PATH . 'vendor/autoload.php')) {
    require_once ROOT_PATH . 'vendor/autoload.php';
    if (class_exists('TCPDF')) {
        $tcpdfAvailable = true;
    }
}

function generateVerificationQR($code)
{
    $qrDir = ROOT_PATH . 'assets/qrcodes/';
    if (!is_dir($qrDir)) {
        @mkdir($qrDir, 0777, true);
    }

    $qrFile = $qrDir . strtolower($code) . '.png';

    if (file_exists($qrFile) && filesize($qrFile) > 0) {
        return 'assets/qrcodes/' . strtolower($code) . '.png';
    }

    $qrContent = BASE_URL . 'verification/verify.php?code=' . urlencode($code);

    if (class_exists('QRcode') && function_exists('imagecreate')) {
        try {
            QRcode::png($qrContent, $qrFile, QR_ECLEVEL_M, 6, 2);
            if (file_exists($qrFile) && filesize($qrFile) > 0) {
                return 'assets/qrcodes/' . strtolower($code) . '.png';
            }
        } catch (Throwable $e) {
            // Fall through to GD fallback or skip QR on this PDF.
        }
    }

    if (function_exists('imagecreate')) {
        $size = 300;
        $img = imagecreatetruecolor($size, $size);
        $bg = imagecolorallocate($img, 255, 255, 255);
        $black = imagecolorallocate($img, 0, 0, 0);
        imagefill($img, 0, 0, $bg);

        $modules = 25;
        $moduleSize = floor($size / $modules);
        $offset = floor(($size - $moduleSize * $modules) / 2);

        $seed = 0;
        for ($i = 0; $i < strlen($qrContent); $i++) {
            $seed += ord($qrContent[$i]);
        }
        mt_srand($seed);
        for ($row = 0; $row < $modules; $row++) {
            for ($col = 0; $col < $modules; $col++) {
                $isFinder = ($row < 7 && $col < 7) ||
                    ($row < 7 && $col >= $modules - 7) ||
                    ($row >= $modules - 7 && $col < 7);
                if ($isFinder) {
                    $inInner = ($row >= 2 && $row <= 4 && $col >= 2 && $col <= 4);
                    $inOuter = ($row == 0 || $row == 6 || $col == 0 || $col == 6);
                    $val = $inOuter || $inInner;
                } else {
                    $val = mt_rand(0, 1) == 0;
                }
                if ($val) {
                    imagefilledrectangle($img,
                        $offset + $col * $moduleSize,
                        $offset + $row * $moduleSize,
                        $offset + ($col + 1) * $moduleSize - 1,
                        $offset + ($row + 1) * $moduleSize - 1,
                        $black);
                }
            }
        }
        mt_srand();

        imagepng($img, $qrFile);
        imagedestroy($img);

        if (file_exists($qrFile)) {
            return 'assets/qrcodes/' . strtolower($code) . '.png';
        }
    }

    return null;
}

class ZPPSUClearancePDF extends FPDF
{
    private $clearance;
    private $employee;
    private $signatures;
    private $clearanceType;
    private $recommendingOfficials;
    private $presidentData;

    public function __construct($clearance, $employee, $signatures, $recommendingOfficials = [], $presidentData = null)
    {
        parent::__construct('P', 'mm', 'A4');
        $this->clearance  = $clearance;
        $this->employee   = $employee;
        $this->signatures = $signatures;
        $this->clearanceType = $this->determineClearanceType();
        $this->recommendingOfficials = $recommendingOfficials;
        $this->presidentData = $presidentData;

        $this->SetMargins(20, 15, 20);
        $this->SetAutoPageBreak(true, 25);
        $this->AddPage();
        $this->render();
    }

    private function determineClearanceType()
    {
        $type = $this->employee['employee_type'] ?? '';
        return ($type === 'regular_instructor' || $type === 'visiting_lecturer') ? 'faculty' : 'non_teaching';
    }

    private function render()
    {
        $this->headerSection();
        $this->titleSection();
        $this->introParagraph();
        $this->clearanceMatrix();
        $this->purposeSection();
        $this->recommendingApproval();
        $this->approvedSection();
        $this->footerQR();
    }

    private function headerSection()
    {
        $logoPath = ROOT_PATH . 'assets/images/zppsu_logo.png';
        if (file_exists($logoPath)) {
            $this->Image($logoPath, 20, 12, 25);
        }

        $this->SetFont('Helvetica', 'B', 9);
        $this->SetTextColor(0, 0, 0);
        $this->SetXY(130, 12);
        
        $typeLabel = $this->clearanceType === 'faculty' ? 'FC' : 'NTC';
        $empType = $this->employee['employee_type'] ?? '';
        $typeSuffix = ($empType === 'visiting_lecturer') ? ' (VL)' : '';
        $ctrlNo = 'ZPPSU-RU-' . $typeLabel . $typeSuffix . ' No. ' . $this->clearance['id'];
        $this->Cell(60, 5, $ctrlNo, 0, 1, 'R');

        $sem = $this->clearance['semester'] ?? '';
        $year = $this->clearance['academic_year'] ?? '';
        $term = $sem . ' S.Y. ' . $year;
        $this->SetX(130);
        $this->SetFont('Helvetica', '', 9);
        $this->Cell(60, 5, $term, 0, 1, 'R');
        $this->Ln(10);
    }

    private function titleSection()
    {
        $title = $this->clearanceType === 'faculty' ? 'FACULTY CLEARANCE' : 'NON-TEACHING CLEARANCE';

        $this->SetFont('Helvetica', 'BI', 16);
        $this->SetTextColor(0, 51, 102);
        $this->Cell(0, 10, $title, 0, 1, 'C');
        $this->Ln(3);

        $first = $this->employee['first_name'] ?? '';
        $middle = $this->employee['middle_name'] ?? '';
        $last = $this->employee['last_name'] ?? '';
        $middleInitial = $middle ? ' ' . mb_substr($middle, 0, 1) . '.' : '';
        $name = mb_strtoupper($last . ', ' . $first . $middleInitial);
        
        $this->SetFont('Helvetica', '', 11);
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 6, 'Issued to: ' . $name, 0, 1, 'C');

        $pos = $this->employee['position_title'] ?? ($this->clearanceType === 'faculty' ? 'Visiting Lecturer' : 'Non-Teaching Staff');
        $this->SetFont('Helvetica', 'I', 10);
        $this->Cell(0, 6, $pos, 0, 1, 'C');
        $this->Ln(6);
    }

    private function introParagraph()
    {
        $this->SetFont('Helvetica', '', 10);
        $this->SetTextColor(0, 0, 0);

        $first = $this->employee['first_name'] ?? '';
        $middle = $this->employee['middle_name'] ?? '';
        $last = $this->employee['last_name'] ?? '';
        $middleInitial = $middle ? ' ' . mb_substr($middle, 0, 1) . '.' : '';
        $name = $first . $middleInitial . ' ' . $last;
        $dept = $this->employee['dept_name'] ?? 'the College';
        $date = $this->clearance['completed_at'] ? date('F d, Y', strtotime($this->clearance['completed_at'])) : 'the dates indicated';

        $text = "This is to certify that $name from $dept has been cleared of all money, property, " .
                "and other accountabilities within the College as of $date.";

        $this->MultiCell(0, 5, $text, 0, 'J');
        $this->Ln(4);
    }

    private function clearanceMatrix()
    {
        $sections = $this->getClearanceSections();
        $colW = [55, 45, 40, 25, 25];
        $header = ['ACCOUNTABILITIES', 'CLEARING OFFICIAL', 'DESIGNATION', 'SIGNATURE', 'DATE SIGNED'];

        $this->SetFont('Helvetica', 'B', 8);
        $this->SetFillColor(0, 51, 102);
        $this->SetTextColor(255, 255, 255);
        $this->SetDrawColor(0, 51, 102);
        foreach ($header as $i => $h) {
            $this->Cell($colW[$i], 7, $h, 1, 0, 'C', true);
        }
        $this->Ln();

        $this->SetTextColor(0, 0, 0);
        $fill = false;

        foreach ($sections as $sectionName => $items) {
            $this->SetFont('Helvetica', 'B', 8);
            $this->SetFillColor($fill ? 230 : 255, $fill ? 238 : 255, $fill ? 248 : 255);
            $this->Cell(array_sum($colW), 6.5, '  ' . $sectionName, 1, 1, 'L', $fill);
            $fill = !$fill;

            foreach ($items as $item) {
                $this->SetFont('Helvetica', '', 7.5);
                $this->SetFillColor($fill ? 245 : 255, $fill ? 248 : 255, $fill ? 252 : 255);

                $sigData = $this->findSignature($item['office_code']);
                $designation = $item['designation'];
                if ($sigData && !empty($sigData['designation'])) {
                    $designation = $sigData['designation'];
                }

                $this->Cell($colW[0], 6, '  ' . $item['accountability'], 1, 0, 'L', $fill);
                $this->Cell($colW[1], 6, $item['official'], 1, 0, 'L', $fill);
                $this->Cell($colW[2], 6, $designation, 1, 0, 'L', $fill);
                if ($sigData && $sigData['action'] === 'signed') {
                    $sigPath = ROOT_PATH . ($sigData['signature_image'] ?? '');
                    if (!empty($sigData['signature_image']) && file_exists($sigPath)) {
                        $x = $this->GetX();
                        $y = $this->GetY();
                        $this->Cell($colW[3], 6, '', 1, 0, 'C', $fill);
                        $this->Image($sigPath, $x + 2, $y + 1, 21, 4);
                    } else {
                        $this->SetTextColor(0, 100, 0);
                        $this->Cell($colW[3], 6, 'Signed', 1, 0, 'C', $fill);
                        $this->SetTextColor(0, 0, 0);
                    }
                } else {
                    $this->Cell($colW[3], 6, '', 1, 0, 'C', $fill);
                }

                $date = ($sigData && $sigData['action'] === 'signed' && $sigData['signed_at'])
                    ? date('M d, Y', strtotime($sigData['signed_at'])) : '';
                $this->Cell($colW[4], 6, $date, 1, 1, 'C', $fill);

                $fill = !$fill;
            }
        }
        $this->Ln(6);
    }

    private function getClearanceSections()
    {
        return [
            'Student Records/Grades Accountability' => [
                ['accountability' => 'Student Records/Grades', 'official' => $this->signatoryName('REGISTRAR', 'Registrar'), 'designation' => 'University Registrar', 'office_code' => 'REGISTRAR'],
            ],
            'Financial Accountability' => [
                ['accountability' => 'Financial', 'official' => $this->signatoryName('ACCOUNTING', 'University Accountant'), 'designation' => 'Accountant IV', 'office_code' => 'ACCOUNTING'],
                ['accountability' => 'Cashier', 'official' => $this->signatoryName('CASHIER', 'Cashier'), 'designation' => 'Cashier III', 'office_code' => 'CASHIER'],
            ],
            'Library Accountability' => [
                ['accountability' => 'Library', 'official' => $this->signatoryName('LIBRARY', 'University Librarian'), 'designation' => 'Librarian IV', 'office_code' => 'LIBRARY'],
            ],
            'Property Accountability' => [
                ['accountability' => 'Property/Supply', 'official' => $this->signatoryName('SUPPLY', 'Supply Officer'), 'designation' => 'Supply Officer IV', 'office_code' => 'SUPPLY'],
            ],
            'Faculty Report Accountability' => [
                ['accountability' => 'Faculty Reports', 'official' => $this->signatoryName('DEAN', 'College Dean'), 'designation' => 'College Dean', 'office_code' => 'DEAN'],
            ],
            'Administrative Accountability' => [
                ['accountability' => 'HRMO', 'official' => $this->signatoryName('HRMO', 'HRMO'), 'designation' => 'HRMO IV', 'office_code' => 'HRMO'],
                ['accountability' => 'Legal', 'official' => $this->signatoryName('LEGAL', 'Legal Officer'), 'designation' => 'Legal Officer IV', 'office_code' => 'LEGAL'],
                ['accountability' => 'Campus Admin', 'official' => $this->signatoryName('CAMPUS_ADMIN', 'Campus Administrator'), 'designation' => 'Campus Director', 'office_code' => 'CAMPUS_ADMIN'],
            ],
        ];
    }

    private function signatoryName($officeCode, $fallback)
    {
        foreach ($this->signatures as $s) {
            $match = false;
            if (isset($s['office_code']) && $s['office_code'] === $officeCode) $match = true;
            if (isset($s['office_name']) && stripos($s['office_name'], $officeCode) !== false) $match = true;

            if (isset($s['office_code']) && $officeCode === 'DEAN' && strpos($s['office_code'], 'DEAN_') === 0) $match = true;

            if ($match) {
                $first = $s['signatory_first'] ?? '';
                $middle = $s['signatory_middle'] ?? '';
                $last = $s['signatory_last'] ?? '';
                $middleInitial = $middle ? ' ' . mb_substr($middle, 0, 1) . '.' : '';
                $name = mb_strtoupper($last . ', ' . $first . $middleInitial);
                if (!empty($name)) return $name;
            }
        }
        return $fallback;
    }

    private function officeCodeMatches($storedCode, $searchCode)
    {
        if ($storedCode === $searchCode) {
            return true;
        }
        $aliases = [
            'REGISTRAR' => ['REG'],
            'ACCOUNTING' => ['ACCT'],
            'CASHIER' => ['CASH'],
            'LIBRARY' => ['LIB'],
            'SUPPLY' => ['SPMU'],
            'PRESIDENT' => ['PRES'],
            'PRES' => ['PRESIDENT'],
            'VP_ACAD' => ['VPAA'],
            'VP_ADMIN' => ['VPAF'],
            'VP_RESEARCH' => ['VPRE'],
        ];
        foreach ($aliases as $canonical => $codes) {
            $all = array_merge([$canonical], $codes);
            if (in_array($searchCode, $all, true) && in_array($storedCode, $all, true)) {
                return true;
            }
        }
        return false;
    }

    private function findSignature($officeCode)
    {
        foreach ($this->signatures as $s) {
            if (isset($s['office_code'])) {
                if ($this->officeCodeMatches($s['office_code'], $officeCode)) {
                    return $s;
                }
                if ($officeCode === 'DEAN' && strpos($s['office_code'], 'DEAN_') === 0) {
                    return $s;
                }
            }
            if (isset($s['office_name']) && stripos($s['office_name'], $officeCode) !== false) {
                return $s;
            }
        }
        return null;
    }

    private function purposeSection()
    {
        $this->SetFont('Helvetica', '', 10);
        $this->SetTextColor(0, 0, 0);

        $purpose = trim($this->clearance['purpose'] ?? '');
        if (empty($purpose) || $purpose === '---') {
            $purpose = '________________________________________________________';
        }

        $this->MultiCell(0, 5, 'This clearance is being issued for the purpose of: ' . $purpose, 0, 'J');
        $this->Ln(8);
    }

    private function recommendingApproval()
    {
        $this->SetFont('Helvetica', 'B', 11);
        $this->SetTextColor(0, 51, 102);
        $this->Cell(0, 7, 'RECOMMENDING APPROVAL', 0, 1, 'L');
        $this->Ln(3);

        $this->SetFont('Helvetica', '', 9);
        $this->SetTextColor(0, 0, 0);
        foreach ($this->recommendingOfficials as $r) {
            $name = $r['full_name'] !== $r['office_name'] ? $r['full_name'] : '';
            $this->Cell(90, 5, $name, 0, 0, 'L');
            $this->Cell(0, 5, $r['office_name'], 0, 1, 'L');
        }
        $this->Ln(6);
    }

    private function approvedSection()
    {
        $this->SetFont('Helvetica', 'B', 12);
        $this->SetTextColor(0, 51, 102);
        $this->Cell(0, 8, 'APPROVED', 0, 1, 'C');
        $this->Ln(4);

        $presSig = $this->findSignature('PRES');
        if ($presSig && $presSig['action'] === 'signed') {
            $sigPath = ROOT_PATH . ($presSig['signature_image'] ?? '');
            if (!empty($presSig['signature_image']) && file_exists($sigPath)) {
                $this->Image($sigPath, 65, $this->GetY() - 6, 80, 14);
                $this->Ln(16);
            }
        } else {
            $y = $this->GetY();
            $this->SetDrawColor(0, 0, 0);
            $this->SetLineWidth(0.4);
            $this->Line(65, $y, 145, $y);
            $this->Ln(6);
        }

        $presName = $this->presidentData['full_name'] ?? 'University President';
        $presTitle = $this->presidentData['designation'] ?? 'University President';

        $this->SetFont('Helvetica', 'B', 10);
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 6, $presName, 0, 1, 'C');
        $this->SetFont('Helvetica', '', 9);
        $this->Cell(0, 5, $presTitle, 0, 1, 'C');
        $this->Ln(8);
    }

    private function footerQR()
    {
        $qrPath = generateVerificationQR($this->clearance['clearance_code']);
        if ($qrPath && file_exists(ROOT_PATH . $qrPath)) {
            $this->Image(ROOT_PATH . $qrPath, 85, $this->GetY(), 20, 20);
            $this->Ln(22);
        }

        $this->SetFont('Helvetica', 'B', 7);
        $this->SetTextColor(0, 51, 102);
        $this->Cell(0, 4, 'Verification Code: ' . $this->clearance['clearance_code'], 0, 1, 'C');

        $this->SetFont('Helvetica', '', 6.5);
        $this->SetTextColor(120, 120, 120);
        $this->Cell(0, 4, 'Verify at: ' . BASE_URL . 'verification/', 0, 1, 'C');
        $this->Cell(0, 4, 'Generated: ' . date('F d, Y h:i A'), 0, 1, 'C');
    }
}

function generateClearancePDF($clearance_id)
{
    try {
        return generateClearancePDFInternal($clearance_id);
    } catch (Throwable $e) {
        error_log('generateClearancePDF error: ' . $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

function generateClearancePDFInternal($clearance_id)
{
    $db = getDB();
    $cid = (int)$clearance_id;

    $stmt = $db->prepare("SELECT cr.*, cp.period_name, cp.academic_year, cp.semester 
                          FROM clearance_requests cr 
                          JOIN clearance_periods cp ON cr.period_id = cp.id 
                          WHERE cr.id = ?");
    $stmt->bind_param("i", $cid);
    $stmt->execute();
    $clearance = $stmt->get_result()->fetch_assoc();
    if (!$clearance) return ['success' => false, 'message' => 'Clearance not found'];

    $eid = (int)$clearance['employee_id'];
    $stmt = $db->prepare("SELECT e.*, u.first_name, u.middle_name, u.last_name, u.email, d.dept_name, d.dept_code 
                          FROM employees e 
                          JOIN users u ON e.user_id = u.id 
                          LEFT JOIN departments d ON e.department_id = d.id 
                          WHERE e.id = ?");
    $stmt->bind_param("i", $eid);
    $stmt->execute();
    $employee = $stmt->get_result()->fetch_assoc();

    $stmt = $db->prepare("SELECT cs.*, ws.step_order, o.office_name, o.office_code, sp.designation, sp.signature_image, 
                                  u2.first_name as signatory_first, u2.middle_name as signatory_middle, u2.last_name as signatory_last
                           FROM clearance_signatures cs
                           JOIN workflow_steps ws ON cs.step_id = ws.id
                           LEFT JOIN offices o ON ws.office_id = o.id
                           LEFT JOIN signatory_profiles sp ON cs.signatory_id = sp.user_id AND sp.office_id = ws.office_id
                           LEFT JOIN users u2 ON cs.signatory_id = u2.id
                           WHERE cs.clearance_id = ?
                           ORDER BY ws.step_order ASC");
    $stmt->bind_param("i", $cid);
    $stmt->execute();
    $signatures = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $recommendCodes = ['VPAA', 'VPAF', 'VPRE', 'LEGAL'];
    $recommendingOfficials = [];
    foreach ($recommendCodes as $rc) {
        $stmt = $db->prepare("
            SELECT u.first_name, u.middle_name, u.last_name, o.office_name, sp.designation, sp.signature_image
            FROM signatory_profiles sp
            JOIN users u ON sp.user_id = u.id
            JOIN offices o ON sp.office_id = o.id
            WHERE o.office_code = ? AND sp.is_active = 1
            LIMIT 1");
        $stmt->bind_param("s", $rc);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        if ($res) {
            $first = $res['first_name'] ?? '';
            $middle = $res['middle_name'] ?? '';
            $last = $res['last_name'] ?? '';
            $middleInitial = $middle ? ' ' . mb_substr($middle, 0, 1) . '.' : '';
            $res['full_name'] = mb_strtoupper($last . ', ' . $first . $middleInitial);
            $res['office_code'] = $rc;
        } else {
            $stmt2 = $db->prepare("SELECT office_name FROM offices WHERE office_code = ? LIMIT 1");
            $stmt2->bind_param("s", $rc);
            $stmt2->execute();
            $oRes = $stmt2->get_result()->fetch_assoc();
            $officeName = $oRes ? $oRes['office_name'] : $rc;
            $res = ['full_name' => '', 'office_name' => $officeName, 'designation' => '', 'signature_image' => null, 'office_code' => $rc];
        }
        $recommendingOfficials[] = $res;
    }

    $presidentData = null;
    $stmt = $db->prepare("
        SELECT u.first_name, u.middle_name, u.last_name, o.office_name, sp.designation, sp.signature_image
        FROM signatory_profiles sp
        JOIN users u ON sp.user_id = u.id
        JOIN offices o ON sp.office_id = o.id
        WHERE o.office_code IN ('PRES', 'PRESIDENT') AND sp.is_active = 1
        LIMIT 1");
    $stmt->execute();
    $presRes = $stmt->get_result()->fetch_assoc();
    if ($presRes) {
        $first = $presRes['first_name'] ?? '';
        $middle = $presRes['middle_name'] ?? '';
        $last = $presRes['last_name'] ?? '';
        $middleInitial = $middle ? ' ' . mb_substr($middle, 0, 1) . '.' : '';
        $presRes['full_name'] = mb_strtoupper($last . ', ' . $first . $middleInitial);
        $presidentData = $presRes;
    }

    if (!defined('FPDF_FONTPATH') && is_dir(ROOT_PATH . 'vendor/fpdf/font/')) {
        define('FPDF_FONTPATH', ROOT_PATH . 'vendor/fpdf/font/');
    }
    if (!class_exists('FPDF')) {
        require_once ROOT_PATH . 'vendor/fpdf.php';
    }

    if (!is_dir(PDF_PATH)) {
        @mkdir(PDF_PATH, 0777, true);
    }

    $pdf = new ZPPSUClearancePDF($clearance, $employee, $signatures, $recommendingOfficials, $presidentData);

    $filename = 'clearance_' . strtolower($clearance['clearance_code']) . '.pdf';
    $filepath = PDF_PATH . $filename;
    $pdf->Output('F', $filepath);

    $hash = hashDocument(file_get_contents($filepath));

    $pdfRelPath = 'pdfs/' . $filename;
    $stmt = $db->prepare("UPDATE clearance_requests SET pdf_path = ?, hash_validation = ? WHERE id = ?");
    $stmt->bind_param("ssi", $pdfRelPath, $hash, $cid);
    $stmt->execute();

    logAudit('generate_pdf', 'clearance', "PDF generated for clearance: {$clearance['clearance_code']}");

    return ['success' => true, 'path' => $pdfRelPath, 'hash' => $hash, 'filename' => $filename];
}
