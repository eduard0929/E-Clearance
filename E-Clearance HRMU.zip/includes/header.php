<?php
/**
 * Notification count query - used by all pages' header
 * Requires $db and $user to be defined in calling scope
 */
$notifCount = 0;
$notifLink = BASE_URL . 'notifications.php';
if (isset($db) && isset($user)) {
    $stmt = $db->prepare("SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->bind_param("i", $user['id']);
    $stmt->execute();
    $notifCount = $stmt->get_result()->fetch_assoc()['c'];
}
