<?php
/**
 * Shared top header. Set $pageTitle and optional $pageIcon before including.
 */
$pageTitle = $pageTitle ?? 'Dashboard';
$pageIcon = $pageIcon ?? 'bi-speedometer2';
$userInitial = $userInitial ?? (isset($user) ? strtoupper(substr($user['first_name'], 0, 1)) . strtoupper(substr($user['last_name'], 0, 1)) : '?');
$roleLabel = isset($role) ? ucfirst($role) : (isset($user['role_name']) ? ucfirst($user['role_name']) : '');
$notifLink = BASE_URL . 'notifications.php';
if (!isset($notifCount) && isset($db, $user)) {
    $stmt = $db->prepare("SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->bind_param("i", $user['id']);
    $stmt->execute();
    $notifCount = $stmt->get_result()->fetch_assoc()['c'];
}
$notifCount = $notifCount ?? 0;
?>
<header class="top-header">
    <div class="d-flex align-items-center gap-2">
        <button class="sidebar-toggle" type="button" onclick="document.getElementById('appSidebar').classList.toggle('show')">
            <i class="bi bi-list"></i>
        </button>
        <div class="page-title">
            <i class="bi <?= htmlspecialchars($pageIcon) ?>"></i> <?= htmlspecialchars($pageTitle) ?>
        </div>
    </div>
    <div class="header-actions">
        <a class="position-relative text-decoration-none text-dark" href="<?= $notifLink ?>" title="All Notifications">
            <i class="bi bi-bell fs-5"></i>
            <?php if ($notifCount > 0): ?>
            <span class="notif-count"><?= $notifCount > 9 ? '9+' : $notifCount ?></span>
            <?php endif; ?>
        </a>
        <div class="dropdown user-dropdown">
            <div class="user-avatar" data-bs-toggle="dropdown" role="button" title="<?= htmlspecialchars($_SESSION['full_name'] ?? '') ?>" style="overflow: hidden; padding: 0;">
                <?= getUserAvatarInner($user ?? null) ?>
            </div>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><span class="dropdown-item-text fw-bold"><?= htmlspecialchars($_SESSION['full_name'] ?? '') ?></span></li>
                <li><span class="dropdown-item-text text-muted small"><?= htmlspecialchars($roleLabel) ?></span></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>profile.php"><i class="bi bi-person"></i> Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</header>
