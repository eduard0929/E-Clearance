<?php

function getDeanOfficePrefix(string $name, ?string $code = ''): string
{
    $prefix = 'Dean';
    if (strpos($name, 'Department') !== false || strpos($name, 'NSTP') !== false || strtoupper($code ?? '') === 'NSTP') {
        $prefix = 'Director';
    }
    if (strpos($name, 'Senior High School') !== false || strtoupper($code ?? '') === 'SHS') {
        $prefix = 'Principal';
    }
    if (strpos($name, 'School of Business') !== false || strtoupper($code ?? '') === 'SBA') {
        $prefix = 'OIC-Dean';
    }
    return $prefix;
}

function isDeanCollegeOffice(?string $officeName, ?string $officeCode = null): bool
{
    if ($officeCode && strpos($officeCode, 'DEAN_') === 0) {
        return true;
    }
    if (!$officeName) {
        return false;
    }
    return strpos($officeName, 'Dean, ') === 0
        || strpos($officeName, 'Director, ') === 0
        || strpos($officeName, 'Principal, ') === 0
        || strpos($officeName, 'OIC-Dean, ') === 0;
}

function findDeanOfficeForDepartment(mysqli $db, int $deptId): ?array
{
    $stmt = $db->prepare("
        SELECT o.id, o.office_name, o.office_code
        FROM offices o
        WHERE o.department_id = ? AND o.is_active = 1
          AND (
              o.office_code LIKE 'DEAN_%'
              OR o.office_name LIKE 'Dean, %'
              OR o.office_name LIKE 'Director, %'
              OR o.office_name LIKE 'Principal, %'
              OR o.office_name LIKE 'OIC-Dean, %'
          )
        ORDER BY o.id ASC
        LIMIT 1
    ");
    $stmt->bind_param('i', $deptId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    return $row ?: null;
}

function ensureDeanOfficeForDepartment(mysqli $db, int $deptId): ?int
{
    $existing = findDeanOfficeForDepartment($db, $deptId);
    if ($existing) {
        return (int)$existing['id'];
    }

    $deptStmt = $db->prepare("SELECT dept_name, dept_code FROM departments WHERE id = ? AND dept_type = 'college'");
    $deptStmt->bind_param('i', $deptId);
    $deptStmt->execute();
    $dept = $deptStmt->get_result()->fetch_assoc();
    if (!$dept) {
        return null;
    }

    $name = $dept['dept_name'];
    $code = $dept['dept_code'] ?? '';
    $prefix = getDeanOfficePrefix($name, $code);
    $officeName = $prefix . ', ' . $name;
    $isDeanType = !in_array($prefix, ['Director', 'Principal', 'OIC-Dean'], true);
    $officeCode = $isDeanType
        ? 'DEAN_' . ($code ?: strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $name), 0, 6)))
        : strtoupper($code ?: substr(preg_replace('/[^a-zA-Z0-9]/', '', $name), 0, 6)) . '_HEAD';

    $offStmt = $db->prepare("INSERT INTO offices (office_name, office_code, department_id) VALUES (?, ?, ?)");
    $offStmt->bind_param('ssi', $officeName, $officeCode, $deptId);
    if ($offStmt->execute()) {
        return (int)$db->insert_id;
    }

    $existing = findDeanOfficeForDepartment($db, $deptId);
    return $existing ? (int)$existing['id'] : null;
}

function resolveSignatoryOfficeId(mysqli $db, int $officeId, ?int $deanDeptId): int
{
    if ($deanDeptId) {
        $resolved = ensureDeanOfficeForDepartment($db, $deanDeptId);
        if ($resolved) {
            return $resolved;
        }
    }
    return $officeId;
}
