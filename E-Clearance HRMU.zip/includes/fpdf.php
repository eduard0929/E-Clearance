<?php
if (!class_exists('TCPDF', false)) {
    if (!is_dir(ROOT_PATH . 'vendor') || !file_exists(ROOT_PATH . 'vendor/autoload.php')) {
        if (!is_dir(dirname(__DIR__) . '/vendor')) {
            @mkdir(ROOT_PATH . 'vendor', 0777, true);
        }
    }
}

if (!is_dir(ROOT_PATH . 'pdfs')) {
    @mkdir(ROOT_PATH . 'pdfs', 0777, true);
}

if (!is_dir(ROOT_PATH . 'assets/qrcodes')) {
    @mkdir(ROOT_PATH . 'assets/qrcodes', 0777, true);
}
